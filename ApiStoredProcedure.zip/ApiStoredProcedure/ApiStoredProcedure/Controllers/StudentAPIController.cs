﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApiStoredProcedure.Models;
using ApiStoredProcedure.Repositories;

namespace ApiStoredProcedure.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAPIController : ControllerBase
    {
        private readonly IRepository<Student, int> repository;
        public StudentAPIController(IRepository<Student, int> repository)
        {
            this.repository = repository;
        }


        [HttpGet]
        public IActionResult Get()
        {
            var res = repository.GetAsync().Result;
            return Ok(res);
        }

        [HttpPost]
        public IActionResult Post(Student student)
        {
            try
            {
                var res = repository.CreateAsync(student);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[HttpPost]
        //public IActionResult Post(MJobTitleRequisites data)
        //{
        //    try
        //    {
        //        var res = repository.DoTitleOperation(data);
        //        return Ok(res);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}
    }
}