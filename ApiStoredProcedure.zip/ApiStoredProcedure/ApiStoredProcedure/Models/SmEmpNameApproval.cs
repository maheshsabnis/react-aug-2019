﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpNameApproval
    {
        public decimal EmpNameApprovalId { get; set; }
        public decimal? EmpNameId { get; set; }
        public string Remark { get; set; }
        public bool? ReviewFlag { get; set; }
        public bool? ApproveFlag { get; set; }
        public bool? RejectedFlag { get; set; }
        public decimal? ApprovalBy { get; set; }
        public DateTime? ApprovalByDateTime { get; set; }
        public string ApprovalSign { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEmpName EmpName { get; set; }
    }
}
