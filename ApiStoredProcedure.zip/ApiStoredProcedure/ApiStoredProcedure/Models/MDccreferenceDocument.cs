﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDccreferenceDocument
    {
        public MDccreferenceDocument()
        {
            SmDccreferenceDocumentDetail = new HashSet<SmDccreferenceDocumentDetail>();
        }

        public decimal DccrefDocId { get; set; }
        public decimal? DocRevId { get; set; }
        public string RefDocNo { get; set; }
        public bool? SubmitFlag { get; set; }
        public decimal? SubmittedBy { get; set; }
        public string SubmittedSign { get; set; }
        public bool? SubmittedIncorrectPassword { get; set; }
        public DateTime? SubmittedByDateTime { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public string ApprovedSign { get; set; }
        public bool? ApprovedIncorrectPassword { get; set; }
        public DateTime? ApprovedByDateTime { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmDocRevision DocRev { get; set; }
        public virtual ICollection<SmDccreferenceDocumentDetail> SmDccreferenceDocumentDetail { get; set; }
    }
}
