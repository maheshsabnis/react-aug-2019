﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MNationality
    {
        public decimal NationalityId { get; set; }
        public string Nationality { get; set; }
        public decimal? CountryId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MCountry Country { get; set; }
    }
}
