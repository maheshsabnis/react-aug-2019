﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MCycle
    {
        public MCycle()
        {
            SmPmcycle = new HashSet<SmPmcycle>();
        }

        public decimal CycleId { get; set; }
        public string CycleName { get; set; }
        public string Day { get; set; }
        public decimal? DayofWeek { get; set; }
        public string Months { get; set; }
        public string MailPriortoDays { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual ICollection<SmPmcycle> SmPmcycle { get; set; }
    }
}
