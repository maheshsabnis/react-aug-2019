﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAbsencePolicy
    {
        public MAbsencePolicy()
        {
            MAbsenceRequest = new HashSet<MAbsenceRequest>();
            MEmpAbsencePolicy = new HashSet<MEmpAbsencePolicy>();
            SmAbsencePolicyApproval = new HashSet<SmAbsencePolicyApproval>();
            SmAbsencePolicyDocument = new HashSet<SmAbsencePolicyDocument>();
            SmAbsenceRequestDetail = new HashSet<SmAbsenceRequestDetail>();
        }

        public decimal AbsencePolicyId { get; set; }
        public decimal? ReasonLeaveId { get; set; }
        public string AbsencePolicyCode { get; set; }
        public bool? NoLimitFlag { get; set; }
        public bool? CarryFlag { get; set; }
        public double? CarryForwardDays { get; set; }
        public bool? EligibilityCriteriaFlag { get; set; }
        public double? TotalNoOfLeave { get; set; }
        public double? NoOfLeave { get; set; }
        public string NoOfLeaveUnit { get; set; }
        public double? PerWorkingDayHrs { get; set; }
        public string PerWorkingDayHrsUnit { get; set; }
        public DateTime? EffectiveFromDate { get; set; }
        public DateTime? EffectiveToDate { get; set; }
        public bool? ObsoleteBybtn { get; set; }
        public bool? HrrequestFlag { get; set; }
        public bool? UnutilizedFlag { get; set; }
        public bool? CreditFlag { get; set; }
        public double? CreditValidity { get; set; }
        public string Revision { get; set; }
        public decimal? AbsencePolicyStatusId { get; set; }
        public string DeactivationFlag { get; set; }
        public string Remark { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MAbsencePolicyStatus AbsencePolicyStatus { get; set; }
        public virtual MReasonLeave ReasonLeave { get; set; }
        public virtual ICollection<MAbsenceRequest> MAbsenceRequest { get; set; }
        public virtual ICollection<MEmpAbsencePolicy> MEmpAbsencePolicy { get; set; }
        public virtual ICollection<SmAbsencePolicyApproval> SmAbsencePolicyApproval { get; set; }
        public virtual ICollection<SmAbsencePolicyDocument> SmAbsencePolicyDocument { get; set; }
        public virtual ICollection<SmAbsenceRequestDetail> SmAbsenceRequestDetail { get; set; }
    }
}
