﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmConditionalReleaseDocument
    {
        public decimal ConditionalReleaseDocumentId { get; set; }
        public decimal? ConditionalReleaseId { get; set; }
        public string DocFileName { get; set; }
        public byte[] DocFile { get; set; }
        public string Type { get; set; }
        public decimal? DocTypeId { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }

        public virtual SmConditionalRelease ConditionalRelease { get; set; }
    }
}
