﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MMaterialState
    {
        public MMaterialState()
        {
            SmMaterialStateApproval = new HashSet<SmMaterialStateApproval>();
        }

        public decimal MaterialStateId { get; set; }
        public string MaterialState { get; set; }
        public string Comment { get; set; }
        public decimal? AddedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<SmMaterialStateApproval> SmMaterialStateApproval { get; set; }
    }
}
