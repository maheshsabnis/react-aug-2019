﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBulk
    {
        public SmBulk()
        {
            SmBulkInspection = new HashSet<SmBulkInspection>();
        }

        public decimal BulkId { get; set; }
        public string BulkInfoId { get; set; }
        public decimal? ReceivalId { get; set; }
        public bool? InspectionVisual { get; set; }
        public bool? InspectionQuantitative { get; set; }
        public string SamplingPlan { get; set; }
        public decimal? NocontainersSampled { get; set; }
        public decimal? NosamplesWithdrawn { get; set; }
        public bool? CertificateOfAnalysis { get; set; }
        public string SamplingThief { get; set; }
        public double? TotalQuantity { get; set; }
        public decimal? UnitId { get; set; }
        public decimal? CleanedBy { get; set; }
        public decimal? InspectedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? InspectedDate { get; set; }
        public DateTime? EfectiveDate { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmBulkInspection> SmBulkInspection { get; set; }
    }
}
