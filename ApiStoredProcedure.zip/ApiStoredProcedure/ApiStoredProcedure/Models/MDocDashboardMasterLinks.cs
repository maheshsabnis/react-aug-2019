﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDocDashboardMasterLinks
    {
        public MDocDashboardMasterLinks()
        {
            SmDocumentDashboardLinks = new HashSet<SmDocumentDashboardLinks>();
        }

        public decimal DocDashboardMasterLinksId { get; set; }
        public string MasterLink { get; set; }
        public decimal? Order { get; set; }
        public string LoadImageName { get; set; }
        public byte[] LoadImage { get; set; }
        public string MouseOverImageName { get; set; }
        public byte[] MouseOverImage { get; set; }
        public string ShowImage { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmDocumentDashboardLinks> SmDocumentDashboardLinks { get; set; }
    }
}
