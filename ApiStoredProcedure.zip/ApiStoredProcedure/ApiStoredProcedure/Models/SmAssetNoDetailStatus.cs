﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetNoDetailStatus
    {
        public SmAssetNoDetailStatus()
        {
            SmAssetNoDetailStatusApproval = new HashSet<SmAssetNoDetailStatusApproval>();
            SmAssetNoDetailStatusDocument = new HashSet<SmAssetNoDetailStatusDocument>();
        }

        public decimal AssetNoDetailStatusId { get; set; }
        public decimal? AssetReceivalId { get; set; }
        public decimal? AssetReceivalDetailId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<SmAssetNoDetailStatusApproval> SmAssetNoDetailStatusApproval { get; set; }
        public virtual ICollection<SmAssetNoDetailStatusDocument> SmAssetNoDetailStatusDocument { get; set; }
    }
}
