﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTempTrainingEvent
    {
        public decimal TrainingId { get; set; }
        public string Description { get; set; }
        public string TrnCourseCode { get; set; }
        public string DocNumNewRev { get; set; }
        public double? Duration { get; set; }
        public DateTime? DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal? TrnTrxnId { get; set; }
        public string EmpFirstName { get; set; }
        public string EmpLastName { get; set; }
        public string DepartmentName { get; set; }
        public string Comments { get; set; }
        public string HostName { get; set; }
        public string Ipaddresses { get; set; }
        public decimal? UserId { get; set; }
    }
}
