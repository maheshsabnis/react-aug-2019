﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MFormulaBom
    {
        public MFormulaBom()
        {
            MBom = new HashSet<MBom>();
            SmFormulaBomdetails = new HashSet<SmFormulaBomdetails>();
            SmMrtoWareHouse = new HashSet<SmMrtoWareHouse>();
        }

        public decimal FormulaBomid { get; set; }
        public decimal? FormulaId { get; set; }
        public string Bomcode { get; set; }
        public string SubCode { get; set; }
        public string FormType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ReferenceBomid { get; set; }
        public double? MultiplierFactor { get; set; }
        public string IsTransferFlag { get; set; }

        public virtual MFormula Formula { get; set; }
        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual ICollection<MBom> MBom { get; set; }
        public virtual ICollection<SmFormulaBomdetails> SmFormulaBomdetails { get; set; }
        public virtual ICollection<SmMrtoWareHouse> SmMrtoWareHouse { get; set; }
    }
}
