﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpEducation
    {
        public MEmpEducation()
        {
            SmEmpEducationDocument = new HashSet<SmEmpEducationDocument>();
            SmEmpEducationHistory = new HashSet<SmEmpEducationHistory>();
        }

        public decimal EmpEducationId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? EducationLevelId { get; set; }
        public decimal? EducationId { get; set; }
        public string Institute { get; set; }
        public string Major { get; set; }
        public string Minor { get; set; }
        public string PassOutYear { get; set; }
        public string Score { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string CourseDuration { get; set; }
        public string Comment { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEducation Education { get; set; }
        public virtual MEducationLevel EducationLevel { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual ICollection<SmEmpEducationDocument> SmEmpEducationDocument { get; set; }
        public virtual ICollection<SmEmpEducationHistory> SmEmpEducationHistory { get; set; }
    }
}
