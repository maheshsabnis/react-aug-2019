﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDissolutionSample
    {
        public decimal DissolutionSampleId { get; set; }
        public int? DissolutionSampleNo { get; set; }
        public string DissolutionSample { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
