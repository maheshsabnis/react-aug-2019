﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MFormula
    {
        public MFormula()
        {
            InverseSupercedesFormula = new HashSet<MFormula>();
            MBom = new HashSet<MBom>();
            MFormulaBom = new HashSet<MFormulaBom>();
            SmCustomerProductSpecification = new HashSet<SmCustomerProductSpecification>();
            SmFormulaApproval = new HashSet<SmFormulaApproval>();
            SmFormulaAsset = new HashSet<SmFormulaAsset>();
            SmFormulaDetail = new HashSet<SmFormulaDetail>();
            SmFormulaDocuments = new HashSet<SmFormulaDocuments>();
            SmMrtoWareHouse = new HashSet<SmMrtoWareHouse>();
            SmProductionYearlyProjectionDetail = new HashSet<SmProductionYearlyProjectionDetail>();
            SmSalesOrderDetail = new HashSet<SmSalesOrderDetail>();
        }

        public decimal FormulaId { get; set; }
        public string FormulaCode { get; set; }
        public decimal? SupercedesFormulaId { get; set; }
        public string SupercedesFormulaCode { get; set; }
        public decimal? MasterFormulaId { get; set; }
        public string MasterFormulaCode { get; set; }
        public decimal? ProductId { get; set; }
        public string Description { get; set; }
        public string CapsuleSize { get; set; }
        public decimal? BatchSize { get; set; }
        public decimal? BatchSizeUnitId { get; set; }
        public double? BatchQuantity { get; set; }
        public decimal? BatchQuantityUnitId { get; set; }
        public double? WeightPerDosageForm { get; set; }
        public decimal? SubBatches { get; set; }
        public decimal? WpdfunitId { get; set; }
        public decimal? ExpiryInMonths { get; set; }
        public string FormType { get; set; }
        public bool? PrepareFlag { get; set; }
        public string PreparedByRemark { get; set; }
        public bool? ReviewFlag { get; set; }
        public decimal? ReviewedBy { get; set; }
        public DateTime? ReviewedByDateTime { get; set; }
        public string ReviewedByRemark { get; set; }
        public bool? ReviewCorrection { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public DateTime? ApprovedByDatetime { get; set; }
        public string ApprovedByRemark { get; set; }
        public bool? ApprovalCorrection { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductFamilyId { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public decimal? PreparedBy { get; set; }
        public decimal? FormulaStatusId { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ReferenceFormulaId { get; set; }
        public double? MultiplierFactor { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public double? SpecificGravity { get; set; }
        public decimal? RequestedBy { get; set; }

        public virtual MProduct Product { get; set; }
        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual MFormula SupercedesFormula { get; set; }
        public virtual ICollection<MFormula> InverseSupercedesFormula { get; set; }
        public virtual ICollection<MBom> MBom { get; set; }
        public virtual ICollection<MFormulaBom> MFormulaBom { get; set; }
        public virtual ICollection<SmCustomerProductSpecification> SmCustomerProductSpecification { get; set; }
        public virtual ICollection<SmFormulaApproval> SmFormulaApproval { get; set; }
        public virtual ICollection<SmFormulaAsset> SmFormulaAsset { get; set; }
        public virtual ICollection<SmFormulaDetail> SmFormulaDetail { get; set; }
        public virtual ICollection<SmFormulaDocuments> SmFormulaDocuments { get; set; }
        public virtual ICollection<SmMrtoWareHouse> SmMrtoWareHouse { get; set; }
        public virtual ICollection<SmProductionYearlyProjectionDetail> SmProductionYearlyProjectionDetail { get; set; }
        public virtual ICollection<SmSalesOrderDetail> SmSalesOrderDetail { get; set; }
    }
}
