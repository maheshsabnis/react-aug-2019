﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MMacAddress
    {
        public MMacAddress()
        {
            MMacAddressUser = new HashSet<MMacAddressUser>();
            SmMacAddressApproval = new HashSet<SmMacAddressApproval>();
            SmMacAddressHistory = new HashSet<SmMacAddressHistory>();
        }

        public decimal MacAddressId { get; set; }
        public string MacAddress { get; set; }
        public string DeviceType { get; set; }
        public decimal? UserId { get; set; }
        public string MacAddressType { get; set; }
        public decimal? NetworkTypeId { get; set; }
        public string MachineName { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MNetworkType NetworkType { get; set; }
        public virtual ICollection<MMacAddressUser> MMacAddressUser { get; set; }
        public virtual ICollection<SmMacAddressApproval> SmMacAddressApproval { get; set; }
        public virtual ICollection<SmMacAddressHistory> SmMacAddressHistory { get; set; }
    }
}
