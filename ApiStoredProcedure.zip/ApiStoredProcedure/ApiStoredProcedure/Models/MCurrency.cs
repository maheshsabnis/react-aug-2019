﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MCurrency
    {
        public MCurrency()
        {
            MEmpMembership = new HashSet<MEmpMembership>();
        }

        public decimal CurrencyId { get; set; }
        public string Currency { get; set; }
        public string AlphabeticCode { get; set; }
        public string NumericCode { get; set; }
        public string Description { get; set; }
        public string Symbol { get; set; }
        public bool? DefaultFlag { get; set; }
        public decimal? DigitsBeforeDecimalPoint { get; set; }
        public decimal? DigitsAfterDecimalPoint { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<MEmpMembership> MEmpMembership { get; set; }
    }
}
