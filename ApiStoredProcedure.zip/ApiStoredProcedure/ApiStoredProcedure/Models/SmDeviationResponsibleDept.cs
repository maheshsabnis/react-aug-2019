﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDeviationResponsibleDept
    {
        public decimal DevResponsibleDeptId { get; set; }
        public decimal? DeviationId { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? EmployeeDeptId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmDeviation Deviation { get; set; }
    }
}
