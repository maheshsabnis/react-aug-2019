﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPendingTaskUser
    {
        public decimal PendingTaskUserId { get; set; }
        public decimal? UserId { get; set; }
        public string Comments { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
