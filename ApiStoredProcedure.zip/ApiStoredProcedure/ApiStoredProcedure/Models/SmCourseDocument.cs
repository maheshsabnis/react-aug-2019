﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCourseDocument
    {
        public decimal CourseDocumentId { get; set; }
        public decimal? TrnClassId { get; set; }
        public string DocumentName { get; set; }
        public string DocumentNo { get; set; }
        public string Revision { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmTrnClass TrnClass { get; set; }
    }
}
