﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampIngrdsBom
    {
        public decimal CampIngrdsBomid { get; set; }
        public string Bomcode { get; set; }
        public decimal? CampaignId { get; set; }
        public decimal? FormulaId { get; set; }
        public decimal? TotalQty { get; set; }
        public decimal? NoofBatches { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmCampaign Campaign { get; set; }
    }
}
