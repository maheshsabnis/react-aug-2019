﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBlanketOrderDetail
    {
        public decimal BlanketOrderDetailId { get; set; }
        public decimal? MaterialRequisitionDetailId { get; set; }
        public DateTime? NeedByDate { get; set; }
        public double? Quantity { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? SiQty { get; set; }
        public decimal? SiUnitId { get; set; }
        public byte[] RecordVersion { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? UnitId { get; set; }

        public virtual SmMaterialRequizitionDetail MaterialRequisitionDetail { get; set; }
    }
}
