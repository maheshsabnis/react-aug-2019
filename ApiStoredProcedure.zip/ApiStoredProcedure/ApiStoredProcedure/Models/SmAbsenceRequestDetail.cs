﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAbsenceRequestDetail
    {
        public decimal AbsenceRequestDetailId { get; set; }
        public decimal? AbsenceRequestId { get; set; }
        public decimal? AbsencePolicyId { get; set; }
        public DateTime? AbsenceDate { get; set; }
        public decimal? AbsenceDayTypeId { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public double? AbsenceHours { get; set; }
        public decimal? CreditAbsenceId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MAbsencePolicy AbsencePolicy { get; set; }
    }
}
