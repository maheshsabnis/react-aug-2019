﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPackageType
    {
        public MPackageType()
        {
            MPackageComp = new HashSet<MPackageComp>();
        }

        public decimal PackageTypeId { get; set; }
        public string PackageType { get; set; }
        public decimal? PackageLevel { get; set; }
        public string BasicPackageLevel { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual ICollection<MPackageComp> MPackageComp { get; set; }
    }
}
