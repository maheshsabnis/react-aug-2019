﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeTrainingDetails
    {
        public decimal EmployeeTrainingDetailId { get; set; }
        public decimal? TrainingEventId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? DocRevId { get; set; }
        public decimal? TrnCourseExternalDocumentId { get; set; }
        public decimal? TrainingCourseRevId { get; set; }
        public decimal? TrainingModuleRevId { get; set; }
        public decimal? EmployeeDesigId { get; set; }
        public decimal? EmployeeDeptId { get; set; }
        public decimal? ContractWorkId { get; set; }
        public decimal? DccrequestId { get; set; }
        public decimal? SelfStudyId { get; set; }
        public DateTime? AttendanceDateTime { get; set; }
        public DateTime? ResultDateTime { get; set; }
        public DateTime? ApprovedDateTime { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public bool? OldRecord { get; set; }

        public virtual MEmployeeDept EmployeeDept { get; set; }
        public virtual MEmployeeDesig EmployeeDesig { get; set; }
        public virtual SmSelfStudy SelfStudy { get; set; }
        public virtual SmTrainingCourseRevision TrainingCourseRev { get; set; }
        public virtual SmTrainingEvent TrainingEvent { get; set; }
        public virtual SmTrainingModuleRevision TrainingModuleRev { get; set; }
        public virtual SmTrainingCourseExternalDocuments TrnCourseExternalDocument { get; set; }
    }
}
