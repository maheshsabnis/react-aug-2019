﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdtemplateDetails
    {
        public SmEctdtemplateDetails()
        {
            SmEctddocTemplate = new HashSet<SmEctddocTemplate>();
        }

        public decimal FolderId { get; set; }
        public string FolderName { get; set; }
        public string ECtdsection { get; set; }
        public decimal? TemplateId { get; set; }
        public decimal? ProjectId { get; set; }
        public decimal? ParentFolderId { get; set; }
        public string FolderTagName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEctdtemplate Template { get; set; }
        public virtual ICollection<SmEctddocTemplate> SmEctddocTemplate { get; set; }
    }
}
