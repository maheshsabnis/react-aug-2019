﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class AuditStoredProcedures
    {
        public decimal Idno { get; set; }
        public string DatabaseName { get; set; }
        public string ObjectName { get; set; }
        public string LoginName { get; set; }
        public DateTime? ChangeDate { get; set; }
        public string EventType { get; set; }
        public string EventDataXml { get; set; }
        public string HostName { get; set; }
        public string Ipaddress { get; set; }
    }
}
