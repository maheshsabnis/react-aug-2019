﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDepartmentActivity
    {
        public decimal DepartmentActivityId { get; set; }
        public decimal? ActivityId { get; set; }
        public decimal? DepartmentId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? Addedby { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
