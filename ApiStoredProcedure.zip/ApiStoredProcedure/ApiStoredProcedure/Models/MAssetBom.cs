﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAssetBom
    {
        public decimal AssetBomid { get; set; }
        public string Bomcode { get; set; }
        public decimal? FormulaId { get; set; }
        public decimal? ProductId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ReferenceAssetBomid { get; set; }
        public double? MultiplierFactor { get; set; }
        public string IsTransferFlag { get; set; }

        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
    }
}
