﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctddownloadDirUserDetail
    {
        public decimal DownloadDirDetailId { get; set; }
        public decimal? ProjectId { get; set; }
        public string HostName { get; set; }
        public string Ipaddresses { get; set; }
        public decimal? DownloadedBy { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
