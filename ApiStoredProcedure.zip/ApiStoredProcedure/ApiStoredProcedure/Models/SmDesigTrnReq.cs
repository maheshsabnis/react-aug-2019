﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDesigTrnReq
    {
        public decimal DesigTrnReq { get; set; }
        public decimal? DesignationId { get; set; }
        public decimal? TrnClassId { get; set; }

        public virtual MDesignation Designation { get; set; }
    }
}
