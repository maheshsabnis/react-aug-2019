﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MReleaseNote
    {
        public decimal ReleaseNoteId { get; set; }
        public string Rversion { get; set; }
        public DateTime? Rdate { get; set; }
        public byte[] VersionNote { get; set; }
        public string VersionFileName { get; set; }
    }
}
