﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmployeePhoneDocument
    {
        public decimal EmpPhoneDocumentId { get; set; }
        public decimal? EmpPhoneNumberId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MDocType DocType { get; set; }
        public virtual MEmployeePhoneNumber EmpPhoneNumber { get; set; }
    }
}
