﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetRequisitionApproval
    {
        public SmAssetRequisitionApproval()
        {
            SmAssetPurchaseOrderDetail = new HashSet<SmAssetPurchaseOrderDetail>();
        }

        public decimal AssetRequisitionApprovalId { get; set; }
        public decimal? AssetRequisitionId { get; set; }
        public string ApprovalType { get; set; }
        public bool? ReviewFlag { get; set; }
        public decimal? ReviewedBy { get; set; }
        public string ReviewedSign { get; set; }
        public bool? ReviewedIncorrectPassword { get; set; }
        public DateTime? ReviewedByDateTime { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public string ApprovedSign { get; set; }
        public bool? ApproveIncorrectPassword { get; set; }
        public DateTime? ApprovedByDatetime { get; set; }
        public string ApprovedByRemark { get; set; }
        public bool? RejectedFlag { get; set; }
        public decimal? RejectedBy { get; set; }
        public string RejectedSign { get; set; }
        public bool? RejectedIncorrectPassword { get; set; }
        public DateTime? RejectedByDateTime { get; set; }
        public bool? ReReviewFlag { get; set; }
        public bool? UpdateFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string Remark { get; set; }
        public decimal? ApprovalBy { get; set; }
        public bool? HoldFlag { get; set; }

        public virtual SmAssetRequisition AssetRequisition { get; set; }
        public virtual ICollection<SmAssetPurchaseOrderDetail> SmAssetPurchaseOrderDetail { get; set; }
    }
}
