﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MMultiplierFactor
    {
        public decimal MultiplierFactorId { get; set; }
        public decimal? MultiplierFactor { get; set; }
    }
}
