﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpTrainingModuleDetails
    {
        public decimal EmpTrainingModuleDetailId { get; set; }
        public decimal? EmployeeTrnModuleId { get; set; }
        public decimal? TrainingModuleDetailId { get; set; }
        public decimal? DocumentId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEmpTrainingModule EmployeeTrnModule { get; set; }
    }
}
