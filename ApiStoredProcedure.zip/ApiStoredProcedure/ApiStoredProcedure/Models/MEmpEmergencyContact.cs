﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpEmergencyContact
    {
        public MEmpEmergencyContact()
        {
            SmEmpEmergencyContactHistory = new HashSet<SmEmpEmergencyContactHistory>();
        }

        public decimal EmpEmergencyContactId { get; set; }
        public decimal? EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public decimal? RelationShipId { get; set; }
        public decimal? CountryId { get; set; }
        public string CountryCode { get; set; }
        public string Stdcode { get; set; }
        public string Number { get; set; }
        public decimal? CountryIdadditional { get; set; }
        public string CountryCodeAdditional { get; set; }
        public string StdcodeAdditional { get; set; }
        public string NumberAdditional { get; set; }
        public string Extension { get; set; }
        public string Mobile { get; set; }
        public string EmailId { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual MRelationShip RelationShip { get; set; }
        public virtual ICollection<SmEmpEmergencyContactHistory> SmEmpEmergencyContactHistory { get; set; }
    }
}
