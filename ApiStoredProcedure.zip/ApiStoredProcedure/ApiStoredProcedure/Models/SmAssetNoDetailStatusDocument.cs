﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetNoDetailStatusDocument
    {
        public decimal AssetNoDetailStatusDocumentId { get; set; }
        public decimal? AssetNoDetailStatusId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual SmAssetNoDetailStatus AssetNoDetailStatus { get; set; }
    }
}
