﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPackage
    {
        public decimal PackageId { get; set; }
        public decimal? PackageTypeId { get; set; }
        public decimal? SubPackageTypeId { get; set; }
        public decimal? SubPackageTypeQty { get; set; }
        public decimal? SubPackageTypeUnitId { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MUnit SubPackageTypeUnit { get; set; }
    }
}
