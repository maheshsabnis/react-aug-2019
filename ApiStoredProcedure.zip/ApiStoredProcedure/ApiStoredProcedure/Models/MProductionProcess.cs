﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProductionProcess
    {
        public MProductionProcess()
        {
            SmProductionProcessVersion = new HashSet<SmProductionProcessVersion>();
        }

        public decimal ProductionProcessId { get; set; }
        public string ProductionProcess { get; set; }
        public decimal? ProductFamilyId { get; set; }
        public decimal? ProductTypeId { get; set; }
        public string ShortDescription { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? ReferenceProductionProcessId { get; set; }

        public virtual MProductType ProductType { get; set; }
        public virtual ICollection<SmProductionProcessVersion> SmProductionProcessVersion { get; set; }
    }
}
