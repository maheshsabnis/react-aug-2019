﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSiteEmployee
    {
        public MSiteEmployee()
        {
            MEmployeeDept = new HashSet<MEmployeeDept>();
            MEmployeeDesig = new HashSet<MEmployeeDesig>();
            SmShiftDetail = new HashSet<SmShiftDetail>();
            SmSiteContact = new HashSet<SmSiteContact>();
            SmSiteEmployeeDocument = new HashSet<SmSiteEmployeeDocument>();
            SmSiteEmployeeLeave = new HashSet<SmSiteEmployeeLeave>();
        }

        public decimal SiteEmployeeId { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? EmployeeId { get; set; }
        public string Remark { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Reason { get; set; }
        public string Phone { get; set; }
        public string Ext { get; set; }
        public string MobilePhone { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId1 { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual MSite Site { get; set; }
        public virtual ICollection<MEmployeeDept> MEmployeeDept { get; set; }
        public virtual ICollection<MEmployeeDesig> MEmployeeDesig { get; set; }
        public virtual ICollection<SmShiftDetail> SmShiftDetail { get; set; }
        public virtual ICollection<SmSiteContact> SmSiteContact { get; set; }
        public virtual ICollection<SmSiteEmployeeDocument> SmSiteEmployeeDocument { get; set; }
        public virtual ICollection<SmSiteEmployeeLeave> SmSiteEmployeeLeave { get; set; }
    }
}
