﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCancelWeighLabelHistory
    {
        public decimal CancelWeighlabelHistoryId { get; set; }
        public decimal? WeighingId { get; set; }
        public decimal? CancelBy { get; set; }
        public DateTime? CancelDate { get; set; }
        public string CancelComment { get; set; }
        public string ApproveSign { get; set; }
        public decimal? ApproveBy { get; set; }
        public DateTime? ApproveDate { get; set; }
        public bool? ApproveFlag { get; set; }
        public string RejectSign { get; set; }
        public decimal? RejectBy { get; set; }
        public DateTime? RejectDate { get; set; }
        public bool? RejectFlag { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
