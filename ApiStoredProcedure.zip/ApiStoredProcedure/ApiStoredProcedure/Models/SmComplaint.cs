﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmComplaint
    {
        public decimal ComplaintId { get; set; }
        public string ComplaintNo { get; set; }
        public DateTime? ComplaintDate { get; set; }
        public decimal? TitleId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Company { get; set; }
        public string StreetAddress { get; set; }
        public string AddressContinued { get; set; }
        public string City { get; set; }
        public decimal? StateId { get; set; }
        public string Zip { get; set; }
        public decimal? CountryId { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string EmailId { get; set; }
        public decimal? ProductId { get; set; }
        public decimal? SubBatchId { get; set; }
        public string BatchNo { get; set; }
        public DateTime? Expdate { get; set; }
        public string HealthcareProvider { get; set; }
        public string Comment { get; set; }
        public decimal? DeterminationById { get; set; }
        public DateTime? DeterminationByDate { get; set; }
        public string DeterminationComment { get; set; }
        public string InquiryType { get; set; }
        public decimal? ReviewBy { get; set; }
        public DateTime? ReviewbyDate { get; set; }
        public string ReviewComment { get; set; }
        public decimal? ContactRouteId { get; set; }
        public decimal? AffiliationId { get; set; }
        public string OtherContactRoute { get; set; }
        public string OtherAffiliation { get; set; }
        public string DeterminationFlag { get; set; }
        public string ReviewFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MAffiliation Affiliation { get; set; }
        public virtual MContactRoute ContactRoute { get; set; }
        public virtual MCountry Country { get; set; }
        public virtual MProduct Product { get; set; }
        public virtual MState State { get; set; }
        public virtual MSubBatch SubBatch { get; set; }
        public virtual MTitle Title { get; set; }
    }
}
