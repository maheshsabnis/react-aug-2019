﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBomversionHr
    {
        public decimal BomversionHrid { get; set; }
        public decimal? BomversionId { get; set; }
        public decimal? RoleId { get; set; }
        public decimal? NoOfPersons { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual SmBomversion Bomversion { get; set; }
        public virtual MDesignation Role { get; set; }
    }
}
