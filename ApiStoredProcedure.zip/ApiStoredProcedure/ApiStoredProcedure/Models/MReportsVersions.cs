﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MReportsVersions
    {
        public decimal ReportsVersionsId { get; set; }
        public decimal ReportId { get; set; }
        public string ReportName { get; set; }
        public string FileName { get; set; }
        public byte[] ReportFile { get; set; }
        public string MenuLinkName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual MReports Report { get; set; }
    }
}
