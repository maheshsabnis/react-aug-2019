﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpGrade
    {
        public decimal EmpGradeId { get; set; }
        public string EmpGrade { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
    }
}
