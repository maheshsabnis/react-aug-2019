﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAssetModel
    {
        public MAssetModel()
        {
            MAssetModelFixParam = new HashSet<MAssetModelFixParam>();
            SmAssetModelApproval = new HashSet<SmAssetModelApproval>();
            SmAssetModelDocument = new HashSet<SmAssetModelDocument>();
            SmAssetPurchaseOrderDetail = new HashSet<SmAssetPurchaseOrderDetail>();
            SmAssetReceival = new HashSet<SmAssetReceival>();
            SmAssetRequisitionDetail = new HashSet<SmAssetRequisitionDetail>();
            SmAssetSop = new HashSet<SmAssetSop>();
            SmBomversionAsset = new HashSet<SmBomversionAsset>();
            SmBomversionAssetPart = new HashSet<SmBomversionAssetPart>();
            SmFormulaAsset = new HashSet<SmFormulaAsset>();
            SmWorkDocumentEquipmentOriginalAssetModel = new HashSet<SmWorkDocumentEquipment>();
            SmWorkDocumentEquipmentReplacedAssetModel = new HashSet<SmWorkDocumentEquipment>();
        }

        public decimal AssetModelId { get; set; }
        public string AssetModelName { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? ManufacturerId { get; set; }
        public string Remark { get; set; }
        public decimal? AddedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }
        public string Description { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MAsset Asset { get; set; }
        public virtual ICollection<MAssetModelFixParam> MAssetModelFixParam { get; set; }
        public virtual ICollection<SmAssetModelApproval> SmAssetModelApproval { get; set; }
        public virtual ICollection<SmAssetModelDocument> SmAssetModelDocument { get; set; }
        public virtual ICollection<SmAssetPurchaseOrderDetail> SmAssetPurchaseOrderDetail { get; set; }
        public virtual ICollection<SmAssetReceival> SmAssetReceival { get; set; }
        public virtual ICollection<SmAssetRequisitionDetail> SmAssetRequisitionDetail { get; set; }
        public virtual ICollection<SmAssetSop> SmAssetSop { get; set; }
        public virtual ICollection<SmBomversionAsset> SmBomversionAsset { get; set; }
        public virtual ICollection<SmBomversionAssetPart> SmBomversionAssetPart { get; set; }
        public virtual ICollection<SmFormulaAsset> SmFormulaAsset { get; set; }
        public virtual ICollection<SmWorkDocumentEquipment> SmWorkDocumentEquipmentOriginalAssetModel { get; set; }
        public virtual ICollection<SmWorkDocumentEquipment> SmWorkDocumentEquipmentReplacedAssetModel { get; set; }
    }
}
