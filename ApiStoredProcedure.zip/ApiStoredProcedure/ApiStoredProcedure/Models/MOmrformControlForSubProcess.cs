﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrformControlForSubProcess
    {
        public decimal FormControlForSubProcessId { get; set; }
        public decimal? FormControlId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
