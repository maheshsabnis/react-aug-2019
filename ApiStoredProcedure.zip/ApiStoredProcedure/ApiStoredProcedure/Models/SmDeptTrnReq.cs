﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDeptTrnReq
    {
        public decimal DeptTrnReq { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? TrnClassId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual MDepartment Department { get; set; }
    }
}
