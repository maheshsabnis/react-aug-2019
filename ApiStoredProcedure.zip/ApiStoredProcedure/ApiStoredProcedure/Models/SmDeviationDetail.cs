﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDeviationDetail
    {
        public decimal DeviationDetailId { get; set; }
        public decimal? DeviationId { get; set; }
        public decimal? RawMaterialPartyId { get; set; }
        public decimal? RawMaterialReceivedId { get; set; }
        public decimal? ProductPartyId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ProductTypeId { get; set; }
        public decimal? SubBatchId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmDeviation Deviation { get; set; }
        public virtual SmProductParty ProductParty { get; set; }
        public virtual MProductType ProductType { get; set; }
        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual SmRawMaterialParty RawMaterialParty { get; set; }
        public virtual SmRawMaterialReceived RawMaterialReceived { get; set; }
        public virtual MSubBatch SubBatch { get; set; }
    }
}
