﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MUnit
    {
        public MUnit()
        {
            MAssetModelFixParam = new HashSet<MAssetModelFixParam>();
            MPackage = new HashSet<MPackage>();
            MUnitConversionFactorInUnit = new HashSet<MUnitConversionFactor>();
            MUnitConversionFactorOutUnit = new HashSet<MUnitConversionFactor>();
            SmAssetPurchaseOrderDetail = new HashSet<SmAssetPurchaseOrderDetail>();
            SmAssetReceival = new HashSet<SmAssetReceival>();
            SmBatchDetail = new HashSet<SmBatchDetail>();
            SmBomversionMaterial = new HashSet<SmBomversionMaterial>();
            SmBomversionProduct = new HashSet<SmBomversionProduct>();
            SmBomversionProductionSupplies = new HashSet<SmBomversionProductionSupplies>();
            SmFormulaBomdetails = new HashSet<SmFormulaBomdetails>();
            SmFormulaDetailQpbunit = new HashSet<SmFormulaDetail>();
            SmFormulaDetailQpdfunit = new HashSet<SmFormulaDetail>();
            SmMaterialRequizitionDetail = new HashSet<SmMaterialRequizitionDetail>();
            SmMrtoWareHouseDetail = new HashSet<SmMrtoWareHouseDetail>();
            SmMrtoWareHouseProductDetail = new HashSet<SmMrtoWareHouseProductDetail>();
            SmPackageMaterial = new HashSet<SmPackageMaterial>();
            SmPickingTicketDetail = new HashSet<SmPickingTicketDetail>();
            SmProductBomDetail = new HashSet<SmProductBomDetail>();
            SmPurchaseOrderDetail = new HashSet<SmPurchaseOrderDetail>();
            SmRawMaterialContainerDetail = new HashSet<SmRawMaterialContainerDetail>();
            SmRawMaterialIssued = new HashSet<SmRawMaterialIssued>();
            SmRawMaterialReceivedOutUnit = new HashSet<SmRawMaterialReceived>();
            SmRawMaterialReceivedRawMaterialUnit = new HashSet<SmRawMaterialReceived>();
            SmSalesOrderDetail = new HashSet<SmSalesOrderDetail>();
            SmSolutionPreparation = new HashSet<SmSolutionPreparation>();
            SmSolutionPreparationAssetDetail = new HashSet<SmSolutionPreparationAssetDetail>();
            SmSolutionPreparationMaterialDetail = new HashSet<SmSolutionPreparationMaterialDetail>();
            SmSolutionPreparationMaterialReceivalDetail = new HashSet<SmSolutionPreparationMaterialReceivalDetail>();
            SmStmtestTemplate = new HashSet<SmStmtestTemplate>();
            SmStmtestTemplateAssetMaterial = new HashSet<SmStmtestTemplateAssetMaterial>();
            SmStmtestTemplateMaterial = new HashSet<SmStmtestTemplateMaterial>();
            SmStmtestTemplateSolution = new HashSet<SmStmtestTemplateSolution>();
            SmStmtestTemplateSolutionMaterial = new HashSet<SmStmtestTemplateSolutionMaterial>();
            SmStorageIntimation = new HashSet<SmStorageIntimation>();
            SmStorageIntimationContainerDetail = new HashSet<SmStorageIntimationContainerDetail>();
            SmTestExecution = new HashSet<SmTestExecution>();
            SmTestExecutionAssetDetail = new HashSet<SmTestExecutionAssetDetail>();
            SmTestExecutionAssetMaterialDetail = new HashSet<SmTestExecutionAssetMaterialDetail>();
            SmTestExecutionMaterialDetail = new HashSet<SmTestExecutionMaterialDetail>();
            SmTestPlanAssetDetail = new HashSet<SmTestPlanAssetDetail>();
            SmTestPlanDetail = new HashSet<SmTestPlanDetail>();
            SmTestPlanEmployeeDetail = new HashSet<SmTestPlanEmployeeDetail>();
        }

        public decimal UnitId { get; set; }
        public string Unit { get; set; }
        public string Type { get; set; }
        public decimal? AddedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? DimensionId { get; set; }
        public string UnitText { get; set; }
        public string Siflag { get; set; }

        public virtual ICollection<MAssetModelFixParam> MAssetModelFixParam { get; set; }
        public virtual ICollection<MPackage> MPackage { get; set; }
        public virtual ICollection<MUnitConversionFactor> MUnitConversionFactorInUnit { get; set; }
        public virtual ICollection<MUnitConversionFactor> MUnitConversionFactorOutUnit { get; set; }
        public virtual ICollection<SmAssetPurchaseOrderDetail> SmAssetPurchaseOrderDetail { get; set; }
        public virtual ICollection<SmAssetReceival> SmAssetReceival { get; set; }
        public virtual ICollection<SmBatchDetail> SmBatchDetail { get; set; }
        public virtual ICollection<SmBomversionMaterial> SmBomversionMaterial { get; set; }
        public virtual ICollection<SmBomversionProduct> SmBomversionProduct { get; set; }
        public virtual ICollection<SmBomversionProductionSupplies> SmBomversionProductionSupplies { get; set; }
        public virtual ICollection<SmFormulaBomdetails> SmFormulaBomdetails { get; set; }
        public virtual ICollection<SmFormulaDetail> SmFormulaDetailQpbunit { get; set; }
        public virtual ICollection<SmFormulaDetail> SmFormulaDetailQpdfunit { get; set; }
        public virtual ICollection<SmMaterialRequizitionDetail> SmMaterialRequizitionDetail { get; set; }
        public virtual ICollection<SmMrtoWareHouseDetail> SmMrtoWareHouseDetail { get; set; }
        public virtual ICollection<SmMrtoWareHouseProductDetail> SmMrtoWareHouseProductDetail { get; set; }
        public virtual ICollection<SmPackageMaterial> SmPackageMaterial { get; set; }
        public virtual ICollection<SmPickingTicketDetail> SmPickingTicketDetail { get; set; }
        public virtual ICollection<SmProductBomDetail> SmProductBomDetail { get; set; }
        public virtual ICollection<SmPurchaseOrderDetail> SmPurchaseOrderDetail { get; set; }
        public virtual ICollection<SmRawMaterialContainerDetail> SmRawMaterialContainerDetail { get; set; }
        public virtual ICollection<SmRawMaterialIssued> SmRawMaterialIssued { get; set; }
        public virtual ICollection<SmRawMaterialReceived> SmRawMaterialReceivedOutUnit { get; set; }
        public virtual ICollection<SmRawMaterialReceived> SmRawMaterialReceivedRawMaterialUnit { get; set; }
        public virtual ICollection<SmSalesOrderDetail> SmSalesOrderDetail { get; set; }
        public virtual ICollection<SmSolutionPreparation> SmSolutionPreparation { get; set; }
        public virtual ICollection<SmSolutionPreparationAssetDetail> SmSolutionPreparationAssetDetail { get; set; }
        public virtual ICollection<SmSolutionPreparationMaterialDetail> SmSolutionPreparationMaterialDetail { get; set; }
        public virtual ICollection<SmSolutionPreparationMaterialReceivalDetail> SmSolutionPreparationMaterialReceivalDetail { get; set; }
        public virtual ICollection<SmStmtestTemplate> SmStmtestTemplate { get; set; }
        public virtual ICollection<SmStmtestTemplateAssetMaterial> SmStmtestTemplateAssetMaterial { get; set; }
        public virtual ICollection<SmStmtestTemplateMaterial> SmStmtestTemplateMaterial { get; set; }
        public virtual ICollection<SmStmtestTemplateSolution> SmStmtestTemplateSolution { get; set; }
        public virtual ICollection<SmStmtestTemplateSolutionMaterial> SmStmtestTemplateSolutionMaterial { get; set; }
        public virtual ICollection<SmStorageIntimation> SmStorageIntimation { get; set; }
        public virtual ICollection<SmStorageIntimationContainerDetail> SmStorageIntimationContainerDetail { get; set; }
        public virtual ICollection<SmTestExecution> SmTestExecution { get; set; }
        public virtual ICollection<SmTestExecutionAssetDetail> SmTestExecutionAssetDetail { get; set; }
        public virtual ICollection<SmTestExecutionAssetMaterialDetail> SmTestExecutionAssetMaterialDetail { get; set; }
        public virtual ICollection<SmTestExecutionMaterialDetail> SmTestExecutionMaterialDetail { get; set; }
        public virtual ICollection<SmTestPlanAssetDetail> SmTestPlanAssetDetail { get; set; }
        public virtual ICollection<SmTestPlanDetail> SmTestPlanDetail { get; set; }
        public virtual ICollection<SmTestPlanEmployeeDetail> SmTestPlanEmployeeDetail { get; set; }
    }
}
