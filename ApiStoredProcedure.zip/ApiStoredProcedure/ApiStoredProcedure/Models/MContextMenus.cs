﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MContextMenus
    {
        public decimal ContextMenuId { get; set; }
        public string MenuName { get; set; }
        public string FormName { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string Dbname { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
