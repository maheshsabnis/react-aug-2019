﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetPoexpectedDetailHistory
    {
        public decimal AssetPoexpectedDetailHistoryId { get; set; }
        public decimal? AssetPurchaseOrderDetailHistoryId { get; set; }
        public decimal? AssetPoexpectedDetailId { get; set; }
        public decimal? AssetPurchaseOrderDetailId { get; set; }
        public string ExptdLotNo { get; set; }
        public double? ExptdQuantity { get; set; }
        public DateTime? ExptdDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmAssetPurchaseOrderDetailHistory AssetPurchaseOrderDetailHistory { get; set; }
    }
}
