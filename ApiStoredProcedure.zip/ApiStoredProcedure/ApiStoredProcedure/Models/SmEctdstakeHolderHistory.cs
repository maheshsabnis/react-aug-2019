﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdstakeHolderHistory
    {
        public decimal StakeHolderHistoryId { get; set; }
        public decimal? EctdstakeHolderId { get; set; }
        public decimal? EctdprojectDetailId { get; set; }
        public decimal? EmployeeId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmEctdstakeHolder EctdstakeHolder { get; set; }
    }
}
