﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBomversionAssetPart
    {
        public decimal BomversionAssetPartId { get; set; }
        public decimal? BomversionAssetId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal AssetModelId { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MAsset Asset { get; set; }
        public virtual MAssetModel AssetModel { get; set; }
        public virtual SmBomversionAsset BomversionAsset { get; set; }
    }
}
