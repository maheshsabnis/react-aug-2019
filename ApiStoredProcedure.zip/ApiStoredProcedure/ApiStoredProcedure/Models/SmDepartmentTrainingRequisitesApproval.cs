﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDepartmentTrainingRequisitesApproval
    {
        public decimal DepartmentTrainingRequisitesApprovalId { get; set; }
        public decimal? DepartmentTrainingRequisitesRevId { get; set; }
        public string Remark { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public DateTime? ApprovedByDateTime { get; set; }
        public bool? ReviewFlag { get; set; }
        public bool? RejectFlag { get; set; }
        public string ApprovalSign { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual SmDepartmentTrainingRequisitesRevision DepartmentTrainingRequisitesRev { get; set; }
    }
}
