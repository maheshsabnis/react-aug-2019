﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEgcapsuleAttachDocumentW
    {
        public decimal EgcapsuleDocId { get; set; }
        public decimal? EgcapsuleId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmSiEgcapsules Egcapsule { get; set; }
    }
}
