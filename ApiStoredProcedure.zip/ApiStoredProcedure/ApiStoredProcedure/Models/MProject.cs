﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProject
    {
        public MProject()
        {
            SmEctdprojectTemplate = new HashSet<SmEctdprojectTemplate>();
            SmVProjectTemplate = new HashSet<SmVProjectTemplate>();
        }

        public decimal ProjectId { get; set; }
        public decimal? ProductId { get; set; }
        public string ProjectCode { get; set; }
        public string ProjectName { get; set; }
        public decimal? ProjectFor { get; set; }
        public string ProjectAim { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? EstEndDate { get; set; }
        public string Status { get; set; }
        public string Other { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? ProjectStatusId { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivationDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MProduct Product { get; set; }
        public virtual SmPartyCategoryDetail ProjectForNavigation { get; set; }
        public virtual MProjectStatus ProjectStatus { get; set; }
        public virtual ICollection<SmEctdprojectTemplate> SmEctdprojectTemplate { get; set; }
        public virtual ICollection<SmVProjectTemplate> SmVProjectTemplate { get; set; }
    }
}
