﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessValidationRuleWoscriptForSubProcess
    {
        public decimal OmrvalidationRuleWoscriptForSubProcessId { get; set; }
        public decimal? OmrprocessValidationRuleWoscriptId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
