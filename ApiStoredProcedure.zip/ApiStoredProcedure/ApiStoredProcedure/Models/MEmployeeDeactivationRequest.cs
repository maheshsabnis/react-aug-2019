﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeDeactivationRequest
    {
        public decimal RequestId { get; set; }
        public string RequestNo { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? DeactivationReasonId { get; set; }
        public string RequestComments { get; set; }
        public DateTime? RequestDate { get; set; }
        public DateTime? RelievingDate { get; set; }
        public string NoOfDays { get; set; }
        public bool? SubmitFlag { get; set; }
        public decimal? SubmittedBy { get; set; }
        public DateTime? SubmittedDate { get; set; }
        public bool? ReqReviewFlag { get; set; }
        public string ReqReviewedSign { get; set; }
        public bool? ReqReviewedIncorrectPassword { get; set; }
        public decimal? ReqReviewedBy { get; set; }
        public DateTime? ReqReviewedByDateTime { get; set; }
        public bool? ReqApproveFlag { get; set; }
        public string ReqApprovedSign { get; set; }
        public bool? ReqApproveIncorrectPassword { get; set; }
        public decimal? ReqApprovedBy { get; set; }
        public DateTime? ReqApprovedByDatetime { get; set; }
        public bool? ReqRejectedFlag { get; set; }
        public string ReqRejectedSign { get; set; }
        public bool? ReqRejectedIncorrectPassword { get; set; }
        public decimal? ReqRejectedBy { get; set; }
        public DateTime? ReqRejectedByDateTime { get; set; }
        public string ReqRemark { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
