﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MResourceTypeMaster
    {
        public decimal ResourceTypeId { get; set; }
        public string ResourceTypeName { get; set; }
        public bool? ResourceActivationFlag { get; set; }
    }
}
