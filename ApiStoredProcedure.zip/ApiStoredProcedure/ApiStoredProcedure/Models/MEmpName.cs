﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpName
    {
        public MEmpName()
        {
            SmEmpNameApproval = new HashSet<SmEmpNameApproval>();
            SmEmpNameDocument = new HashSet<SmEmpNameDocument>();
        }

        public decimal EmpNameId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? TitleId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public decimal? SuffixId { get; set; }
        public string EmailId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Reason { get; set; }
        public decimal? OldTitleId { get; set; }
        public string OldFirstName { get; set; }
        public string OldMiddleName { get; set; }
        public string OldLastName { get; set; }
        public decimal? OldSuffixId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual ICollection<SmEmpNameApproval> SmEmpNameApproval { get; set; }
        public virtual ICollection<SmEmpNameDocument> SmEmpNameDocument { get; set; }
    }
}
