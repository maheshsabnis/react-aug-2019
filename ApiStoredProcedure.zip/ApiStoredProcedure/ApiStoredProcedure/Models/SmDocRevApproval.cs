﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDocRevApproval
    {
        public SmDocRevApproval()
        {
            SmDocRevApprovalHistory = new HashSet<SmDocRevApprovalHistory>();
        }

        public decimal DocRevApprovalId { get; set; }
        public string DocRevId { get; set; }
        public decimal? ApprovedBy { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DesignationId { get; set; }
        public decimal? SequenceNo { get; set; }
        public bool? InProcess { get; set; }
        public bool? DocSubmitFlag { get; set; }
        public decimal? DocSubmittedBy { get; set; }
        public string DocSubmittedSign { get; set; }
        public bool? DocSubmittedIncorrectPassword { get; set; }
        public DateTime? DocSubmittedByDateTime { get; set; }
        public bool? QueueSubmitFlag { get; set; }
        public decimal? QueueSubmittedBy { get; set; }
        public string QueueSubmittedSign { get; set; }
        public bool? QueueSubmittedIncorrectPassword { get; set; }
        public DateTime? QueueSubmittedByDateTime { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? DccstakeHolderRoleId { get; set; }
        public bool? DccSubmitFlag { get; set; }
        public decimal? DccSubmittedBy { get; set; }
        public string DccSubmittedSign { get; set; }
        public bool? DccSubmittedIncorrectPassword { get; set; }
        public DateTime? DccSubmittedByDateTime { get; set; }
        public bool? DccReSubmitFlag { get; set; }
        public bool? ReqReviewFlag { get; set; }
        public decimal? ReqReviewedBy { get; set; }
        public DateTime? ReqReviewedByDateTime { get; set; }
        public bool? ReqReceiveFlag { get; set; }
        public decimal? ReqReceivedBy { get; set; }
        public DateTime? ReqReceivedByDateTime { get; set; }
        public string ReqReceiveComment { get; set; }
        public bool? ReqSubmitFlag { get; set; }
        public decimal? ReqSubmittedBy { get; set; }
        public string ReqSubmittedSign { get; set; }
        public bool? ReqSubmittedIncorrectPassword { get; set; }
        public DateTime? ReqSubmittedByDateTime { get; set; }
        public bool? ReqReSubmitFlag { get; set; }
        public bool? HoDReviewFlag { get; set; }
        public decimal? HoDReviewedBy { get; set; }
        public string HoDReviewedSign { get; set; }
        public bool? HoDReviewedIncorrectPassword { get; set; }
        public DateTime? HoDReviewedByDateTime { get; set; }
        public bool? HoDApproveFlag { get; set; }
        public decimal? HoDApprovedBy { get; set; }
        public string HoDApprovedSign { get; set; }
        public bool? HoDApprovedIncorrectPassword { get; set; }
        public DateTime? HoDApprovedByDateTime { get; set; }
        public string HoDApproveComment { get; set; }
        public bool? HoDReSubmitFlag { get; set; }
        public bool? DccReviewFlag { get; set; }
        public decimal? DccReviewedBy { get; set; }
        public string DccReviewedSign { get; set; }
        public bool? DccReviewedIncorrectPassword { get; set; }
        public DateTime? DccReviewedByDateTime { get; set; }
        public bool? DccApproveFlag { get; set; }
        public decimal? DccApprovedBy { get; set; }
        public string DccApprovedSign { get; set; }
        public bool? DccApprovedIncorrectPassword { get; set; }
        public DateTime? DccApprovedByDateTime { get; set; }
        public string DccApproveComment { get; set; }
        public bool? CcnReviewFlag { get; set; }
        public decimal? CcnReviewedBy { get; set; }
        public string CcnReviewedSign { get; set; }
        public bool? CcnReviewedIncorrectPassword { get; set; }
        public DateTime? CcnReviewedByDateTime { get; set; }
        public string CcnReviewComment { get; set; }
        public bool? CcnApproveFlag { get; set; }
        public decimal? CcnApprovedBy { get; set; }
        public string CcnApprovedSign { get; set; }
        public bool? CcnApprovedIncorrectPassword { get; set; }
        public DateTime? CcnApprovedByDateTime { get; set; }
        public string CcnApproveComment { get; set; }
        public bool? CcnReSubmitFlag { get; set; }
        public bool? EffReviewFlag { get; set; }
        public decimal? EffReviewedBy { get; set; }
        public string EffReviewedSign { get; set; }
        public bool? EffReviewedIncorrectPassword { get; set; }
        public DateTime? EffReviewedByDateTime { get; set; }
        public string EffReviewComment { get; set; }
        public bool? EffApproveFlag { get; set; }
        public decimal? EffApprovedBy { get; set; }
        public string EffApprovedSign { get; set; }
        public bool? EffApprovedIncorrectPassword { get; set; }
        public DateTime? EffApprovedByDateTime { get; set; }
        public string EffApproveComment { get; set; }
        public bool? IsSignatory { get; set; }

        public virtual MDccrequestAssessmentRole DccstakeHolderRole { get; set; }
        public virtual MDepartment Department { get; set; }
        public virtual MDesignation Designation { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual ICollection<SmDocRevApprovalHistory> SmDocRevApprovalHistory { get; set; }
    }
}
