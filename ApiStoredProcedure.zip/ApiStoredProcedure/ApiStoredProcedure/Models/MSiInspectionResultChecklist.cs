﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSiInspectionResultChecklist
    {
        public MSiInspectionResultChecklist()
        {
            SmSiBottleSpecification = new HashSet<SmSiBottleSpecification>();
            SmSiBulkInspection = new HashSet<SmSiBulkInspection>();
            SmSiLabelInspection = new HashSet<SmSiLabelInspection>();
        }

        public decimal InspectionResultChecklistId { get; set; }
        public string InspectionResultChecklist { get; set; }
        public decimal? InspectionForId { get; set; }
        public decimal? OrderNo { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MSiInspectionFor InspectionFor { get; set; }
        public virtual ICollection<SmSiBottleSpecification> SmSiBottleSpecification { get; set; }
        public virtual ICollection<SmSiBulkInspection> SmSiBulkInspection { get; set; }
        public virtual ICollection<SmSiLabelInspection> SmSiLabelInspection { get; set; }
    }
}
