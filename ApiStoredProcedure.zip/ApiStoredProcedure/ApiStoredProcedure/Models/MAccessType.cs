﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAccessType
    {
        public MAccessType()
        {
            SmUserPermission = new HashSet<SmUserPermission>();
        }

        public decimal AccessTypeId { get; set; }
        public string AccessType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OrderSrNo { get; set; }

        public virtual ICollection<SmUserPermission> SmUserPermission { get; set; }
    }
}
