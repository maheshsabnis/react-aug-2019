﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MQueryString
    {
        public decimal QueryStringId { get; set; }
        public string MReportString { get; set; }
        public string Querystring { get; set; }
        public string HostName { get; set; }
        public string Ipaddresses { get; set; }
        public decimal? UserId { get; set; }
        public decimal? Id { get; set; }
    }
}
