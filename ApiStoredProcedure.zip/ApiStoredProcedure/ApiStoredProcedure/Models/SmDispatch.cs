﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDispatch
    {
        public decimal DispatchId { get; set; }
        public decimal? PickingTicketId { get; set; }
        public string DispatchNo { get; set; }
        public string DispatchedBy { get; set; }
        public string VehicleNo { get; set; }
        public string Comment { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual SmPickingTicket PickingTicket { get; set; }
    }
}
