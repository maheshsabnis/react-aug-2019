﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MJobTitleRequisites
    {
        public MJobTitleRequisites()
        {
            SmJobTitleRequisitesRevision = new HashSet<SmJobTitleRequisitesRevision>();
        }

        public decimal JobTitleRequisitesId { get; set; }
        public decimal? DesignationId { get; set; }
        public string RequisitesCode { get; set; }
        public string OldRev { get; set; }
        public string NewRev { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public DateTime? DateTime { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual ICollection<SmJobTitleRequisitesRevision> SmJobTitleRequisitesRevision { get; set; }
    }
}
