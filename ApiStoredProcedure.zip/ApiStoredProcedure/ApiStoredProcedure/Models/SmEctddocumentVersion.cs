﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctddocumentVersion
    {
        public decimal FileVersionId { get; set; }
        public decimal? FileId { get; set; }
        public string FileName { get; set; }
        public byte[] Fle { get; set; }
        public string Type { get; set; }
        public string VersionNo { get; set; }
        public decimal? CreatedBy { get; set; }
        public DateTime? CreationDate { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public bool? DocumentDeleteFlag { get; set; }

        public virtual SmEctddocument File { get; set; }
    }
}
