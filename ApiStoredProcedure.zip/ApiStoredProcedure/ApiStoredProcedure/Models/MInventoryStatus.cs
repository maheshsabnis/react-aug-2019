﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MInventoryStatus
    {
        public MInventoryStatus()
        {
            SmSalesInventoryDetail = new HashSet<SmSalesInventoryDetail>();
        }

        public decimal InventoryStatusId { get; set; }
        public string InventoryStatus { get; set; }
        public bool? ActiveFlag { get; set; }
        public string Deactivationflag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmSalesInventoryDetail> SmSalesInventoryDetail { get; set; }
    }
}
