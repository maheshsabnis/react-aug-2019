﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MContactRoute
    {
        public MContactRoute()
        {
            SmComplaint = new HashSet<SmComplaint>();
        }

        public decimal ContactRouteId { get; set; }
        public string CotactRoute { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual ICollection<SmComplaint> SmComplaint { get; set; }
    }
}
