﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOrderStatus
    {
        public MOrderStatus()
        {
            SmSalesOrderStatus = new HashSet<SmSalesOrderStatus>();
        }

        public decimal OrderStatusId { get; set; }
        public string OrderStatus { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MDocType DocType { get; set; }
        public virtual ICollection<SmSalesOrderStatus> SmSalesOrderStatus { get; set; }
    }
}
