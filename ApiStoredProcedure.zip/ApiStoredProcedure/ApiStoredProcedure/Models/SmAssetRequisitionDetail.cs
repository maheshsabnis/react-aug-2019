﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetRequisitionDetail
    {
        public SmAssetRequisitionDetail()
        {
            SmAssetPurchaseOrderDetail = new HashSet<SmAssetPurchaseOrderDetail>();
        }

        public decimal AssetRequisitionDetailId { get; set; }
        public decimal? AssetRequisitionId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? AssetModelId { get; set; }
        public decimal? AssetManufacturerId { get; set; }
        public decimal? AssetSupplierId { get; set; }
        public string CatelogueNo { get; set; }
        public string Specifications { get; set; }
        public double? Quantity { get; set; }
        public decimal? UnitId { get; set; }
        public double? EstPricePerUnit { get; set; }
        public string Remark { get; set; }
        public bool? AssetModelFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal SiteId { get; set; }
        public double? Tax { get; set; }
        public decimal? CurrencyId1 { get; set; }
        public decimal? CurrencyId2 { get; set; }
        public double? CurReferenceRate { get; set; }
        public DateTime? CurReferenceRateDate { get; set; }
        public decimal? ParentAssetReqDetailId { get; set; }
        public bool? PorejectedFlag { get; set; }
        public decimal? PorejectedBy { get; set; }
        public string PorejectedByRemark { get; set; }
        public DateTime? PorejectedByDateTime { get; set; }
        public decimal? RequestTypeId { get; set; }
        public DateTime? NeedByDate { get; set; }

        public virtual MAssetModel AssetModel { get; set; }
        public virtual SmAssetRequisition AssetRequisition { get; set; }
        public virtual ICollection<SmAssetPurchaseOrderDetail> SmAssetPurchaseOrderDetail { get; set; }
    }
}
