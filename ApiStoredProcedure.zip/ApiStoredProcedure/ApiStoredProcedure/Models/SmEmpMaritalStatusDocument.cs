﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpMaritalStatusDocument
    {
        public decimal EmpMaritalStatusDocumentId { get; set; }
        public decimal? EmpMaritalStatusId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MDocType DocType { get; set; }
        public virtual MEmpMaritalStatus EmpMaritalStatus { get; set; }
    }
}
