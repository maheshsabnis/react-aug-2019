﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MVendorTaxOld
    {
        public decimal VendorTaxId { get; set; }
        public decimal? VendorId { get; set; }
        public string VendorTaxNo { get; set; }
        public bool? Flag1099 { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MVendorOld Vendor { get; set; }
    }
}
