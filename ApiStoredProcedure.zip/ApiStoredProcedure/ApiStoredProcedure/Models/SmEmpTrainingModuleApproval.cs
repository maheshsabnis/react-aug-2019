﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpTrainingModuleApproval
    {
        public decimal EmployeeTrainingMatrixApprovalId { get; set; }
        public decimal? EmployeeTrnModuleId { get; set; }
        public string Remark { get; set; }
        public bool? ReviewFlag { get; set; }
        public bool? ApproveFlag { get; set; }
        public bool? RejectedFlag { get; set; }
        public string Sign { get; set; }
        public decimal? ApprovalBy { get; set; }
        public DateTime? ApprovalByDateTime { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEmpTrainingModule EmployeeTrnModule { get; set; }
    }
}
