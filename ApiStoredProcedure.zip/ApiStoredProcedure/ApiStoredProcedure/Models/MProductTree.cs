﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProductTree
    {
        public MProductTree()
        {
            SmProductTreeApproval = new HashSet<SmProductTreeApproval>();
            SmProductTreeDetail = new HashSet<SmProductTreeDetail>();
        }

        public decimal ProductTreeId { get; set; }
        public decimal? ProductFamilyId { get; set; }
        public string ProductTreeName { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public string Remark { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<SmProductTreeApproval> SmProductTreeApproval { get; set; }
        public virtual ICollection<SmProductTreeDetail> SmProductTreeDetail { get; set; }
    }
}
