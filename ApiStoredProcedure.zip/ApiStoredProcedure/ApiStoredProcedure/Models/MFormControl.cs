﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MFormControl
    {
        public decimal FormControlId { get; set; }
        public decimal? FormId { get; set; }
        public string ControlName { get; set; }
        public string ControlType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
