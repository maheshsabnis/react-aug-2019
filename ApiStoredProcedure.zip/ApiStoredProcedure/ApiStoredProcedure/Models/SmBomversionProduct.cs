﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBomversionProduct
    {
        public decimal BomversionProductId { get; set; }
        public decimal? BomversionId { get; set; }
        public decimal? ProductId { get; set; }
        public double? Quantity { get; set; }
        public decimal QuantityUnitId { get; set; }
        public string Comment { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual SmBomversion Bomversion { get; set; }
        public virtual MProduct Product { get; set; }
        public virtual MUnit QuantityUnit { get; set; }
    }
}
