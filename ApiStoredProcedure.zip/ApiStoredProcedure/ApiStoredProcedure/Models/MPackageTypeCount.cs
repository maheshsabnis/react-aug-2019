﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPackageTypeCount
    {
        public decimal PackageTypeCountId { get; set; }
        public string PackageTypeCount { get; set; }
        public string PackageCodes { get; set; }
        public string BasicPackageType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
