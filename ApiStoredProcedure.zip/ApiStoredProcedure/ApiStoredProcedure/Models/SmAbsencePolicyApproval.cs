﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAbsencePolicyApproval
    {
        public decimal AbsencePolicyApprovalId { get; set; }
        public decimal? AbsencePolicyId { get; set; }
        public string Remark { get; set; }
        public bool? ReviewFlag { get; set; }
        public bool? ApproveFlag { get; set; }
        public bool? RejectedFlag { get; set; }
        public decimal? ApprovalBy { get; set; }
        public DateTime? ApprovalByDateTime { get; set; }
        public string ApprovalSign { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MAbsencePolicy AbsencePolicy { get; set; }
    }
}
