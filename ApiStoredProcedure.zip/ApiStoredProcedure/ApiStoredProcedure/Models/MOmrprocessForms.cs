﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessForms
    {
        public decimal OmrprocessFormId { get; set; }
        public decimal? OmrprocessId { get; set; }
        public decimal? SubMenuId { get; set; }
    }
}
