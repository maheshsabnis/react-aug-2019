﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessGroupDetail
    {
        public decimal OmrprocessGroupDetail { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? GradeId { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DesignationId { get; set; }
        public decimal? UserId { get; set; }
    }
}
