﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSection
    {
        public decimal SectionId { get; set; }
        public string Section { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DisplayOrder { get; set; }
        public bool? ShowInadminPanel { get; set; }
        public bool? DefaultSection { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
