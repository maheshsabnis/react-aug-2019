﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDesignation
    {
        public MDesignation()
        {
            MEmpWorkExperience = new HashSet<MEmpWorkExperience>();
            MEmployee = new HashSet<MEmployee>();
            MEmployeeDesig = new HashSet<MEmployeeDesig>();
            MPartyContact = new HashSet<MPartyContact>();
            SmBomversionHr = new HashSet<SmBomversionHr>();
            SmDesigTrnReq = new HashSet<SmDesigTrnReq>();
            SmDesignationApproval = new HashSet<SmDesignationApproval>();
            SmDocRevApproval = new HashSet<SmDocRevApproval>();
        }

        public decimal DesignationId { get; set; }
        public string Designation { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MDesigPreRequisites MDesigPreRequisites { get; set; }
        public virtual ICollection<MEmpWorkExperience> MEmpWorkExperience { get; set; }
        public virtual ICollection<MEmployee> MEmployee { get; set; }
        public virtual ICollection<MEmployeeDesig> MEmployeeDesig { get; set; }
        public virtual ICollection<MPartyContact> MPartyContact { get; set; }
        public virtual ICollection<SmBomversionHr> SmBomversionHr { get; set; }
        public virtual ICollection<SmDesigTrnReq> SmDesigTrnReq { get; set; }
        public virtual ICollection<SmDesignationApproval> SmDesignationApproval { get; set; }
        public virtual ICollection<SmDocRevApproval> SmDocRevApproval { get; set; }
    }
}
