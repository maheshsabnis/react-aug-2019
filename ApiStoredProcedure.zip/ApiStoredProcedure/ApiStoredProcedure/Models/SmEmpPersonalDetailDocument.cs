﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpPersonalDetailDocument
    {
        public decimal EmpPersonalDetailDocumentId { get; set; }
        public decimal? EmpPersonalDetailId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? DocTypeId { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MDocType DocType { get; set; }
        public virtual MEmpPersonalDetail EmpPersonalDetail { get; set; }
    }
}
