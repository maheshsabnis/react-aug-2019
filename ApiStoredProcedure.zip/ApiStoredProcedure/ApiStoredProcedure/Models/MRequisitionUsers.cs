﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRequisitionUsers
    {
        public decimal RequisitionUserId { get; set; }
        public decimal? UserId { get; set; }
        public decimal? SectionId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
