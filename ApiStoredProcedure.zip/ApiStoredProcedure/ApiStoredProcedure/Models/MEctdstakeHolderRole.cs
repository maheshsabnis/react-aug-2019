﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEctdstakeHolderRole
    {
        public MEctdstakeHolderRole()
        {
            SmECtdprojectApproverHistory = new HashSet<SmECtdprojectApproverHistory>();
        }

        public decimal EctdstakeHolderRoleId { get; set; }
        public decimal? SequenceNo { get; set; }
        public string EctdstakeHolderRole { get; set; }
        public string Ectd { get; set; }
        public string Dcc { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmECtdprojectApproverHistory> SmECtdprojectApproverHistory { get; set; }
    }
}
