﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MConfigurationCodes
    {
        public decimal ConfigurationCodeId { get; set; }
        public string ConfigurationCode { get; set; }
        public string Description { get; set; }
    }
}
