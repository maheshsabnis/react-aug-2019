﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTrainingCourseRevisionStatus
    {
        public MTrainingCourseRevisionStatus()
        {
            SmTrainingCourseRevision = new HashSet<SmTrainingCourseRevision>();
        }

        public decimal TrainingCourseRevisionStatusId { get; set; }
        public string Status { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmTrainingCourseRevision> SmTrainingCourseRevision { get; set; }
    }
}
