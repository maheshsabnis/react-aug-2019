﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrinchargeRightsTransfer
    {
        public decimal OmrinchargeRightsTransfer { get; set; }
        public string TableName { get; set; }
        public string DeptColumnName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public bool? IsParentApproval { get; set; }
        public bool? IsPurchaseApproval { get; set; }
        public bool? IsFinanceApproval { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
