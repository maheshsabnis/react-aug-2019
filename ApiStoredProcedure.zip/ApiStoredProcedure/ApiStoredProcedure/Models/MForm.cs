﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MForm
    {
        public decimal FormId { get; set; }
        public string FormName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
