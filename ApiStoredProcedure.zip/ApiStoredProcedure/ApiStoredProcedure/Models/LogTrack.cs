﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class LogTrack
    {
        public decimal LogTrackId { get; set; }
        public decimal UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public DateTime? LoginDateTime { get; set; }
        public DateTime? ClientDateTime { get; set; }
        public string TimeZone { get; set; }
        public string Ipaddress { get; set; }
        public string HostName { get; set; }
        public string MacAddress { get; set; }
        public string Status { get; set; }
    }
}
