﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCustProdPackSpecification
    {
        public decimal CustProdPackSpecificationId { get; set; }
        public decimal? CustomerProductSpecificationId { get; set; }
        public decimal? PackCompParameterId { get; set; }
        public string ParameterValue { get; set; }
        public decimal? UnitId { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
