﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSalesWarehouse
    {
        public MSalesWarehouse()
        {
            SmSalesInventory = new HashSet<SmSalesInventory>();
        }

        public decimal SalesWarehouseId { get; set; }
        public string Warehouse { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmSalesInventory> SmSalesInventory { get; set; }
    }
}
