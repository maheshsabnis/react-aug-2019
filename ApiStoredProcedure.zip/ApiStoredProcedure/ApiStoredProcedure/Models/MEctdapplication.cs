﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEctdapplication
    {
        public MEctdapplication()
        {
            MEctdsubmission = new HashSet<MEctdsubmission>();
        }

        public decimal ApplicationId { get; set; }
        public string ApplicationType { get; set; }
        public string ApplicationNumber { get; set; }
        public decimal? ProductId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MProduct Product { get; set; }
        public virtual ICollection<MEctdsubmission> MEctdsubmission { get; set; }
    }
}
