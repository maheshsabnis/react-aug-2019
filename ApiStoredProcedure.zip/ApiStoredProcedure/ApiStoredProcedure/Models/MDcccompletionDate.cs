﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDcccompletionDate
    {
        public MDcccompletionDate()
        {
            SmDcccompletionDateHistory = new HashSet<SmDcccompletionDateHistory>();
        }

        public decimal DcccompletionDateId { get; set; }
        public decimal? DccrequestId { get; set; }
        public double? Duration { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public bool? RushFlag { get; set; }

        public virtual MDccrequest Dccrequest { get; set; }
        public virtual ICollection<SmDcccompletionDateHistory> SmDcccompletionDateHistory { get; set; }
    }
}
