﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDMaterial
    {
        public SmDMaterial()
        {
            SmDMaterialApproval = new HashSet<SmDMaterialApproval>();
            SmDMaterialDetail = new HashSet<SmDMaterialDetail>();
            SmMaterialDispositionDocument = new HashSet<SmMaterialDispositionDocument>();
        }

        public decimal DMaterialId { get; set; }
        public decimal? RawMaterialReceivedId { get; set; }
        public decimal? SamplingId { get; set; }
        public decimal? QasampleId { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public DateTime? RetestDate { get; set; }
        public string ReviewComment { get; set; }
        public decimal? ReviewedBy { get; set; }
        public DateTime? ReviewedDate { get; set; }
        public decimal? ProdReviewedBy { get; set; }
        public DateTime? ProdReviewedDate { get; set; }
        public decimal? DevReviewedBy { get; set; }
        public DateTime? DevReviewedDate { get; set; }
        public string Status { get; set; }
        public decimal? MaterialStatusId { get; set; }
        public string Comment { get; set; }
        public string FormName { get; set; }
        public decimal? ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string LabReviewComment { get; set; }
        public string ProdReviewComment { get; set; }
        public decimal? ProductTypeId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public string DeviationOoscomment { get; set; }
        public decimal? MaterialRetestAlertId { get; set; }

        public virtual SmMaterialRetestAlert MaterialRetestAlert { get; set; }
        public virtual MProductType ProductType { get; set; }
        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual SmQasample Qasample { get; set; }
        public virtual SmRawMaterialReceived RawMaterialReceived { get; set; }
        public virtual ICollection<SmDMaterialApproval> SmDMaterialApproval { get; set; }
        public virtual ICollection<SmDMaterialDetail> SmDMaterialDetail { get; set; }
        public virtual ICollection<SmMaterialDispositionDocument> SmMaterialDispositionDocument { get; set; }
    }
}
