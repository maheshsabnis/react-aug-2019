﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDccrequestType
    {
        public MDccrequestType()
        {
            MDccrequest = new HashSet<MDccrequest>();
        }

        public decimal DccrequestTypeId { get; set; }
        public string DccrequestType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual ICollection<MDccrequest> MDccrequest { get; set; }
    }
}
