﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPartyContact
    {
        public MPartyContact()
        {
            SmPartyContactAddressType = new HashSet<SmPartyContactAddressType>();
            SmPartyContactApproval = new HashSet<SmPartyContactApproval>();
            SmPartyContactDocument = new HashSet<SmPartyContactDocument>();
        }

        public decimal PartyContactId { get; set; }
        public decimal? PartyLocationId { get; set; }
        public decimal? TitleId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public decimal? SuffixId { get; set; }
        public string Email { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DesignationId { get; set; }
        public string Functionality { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MDepartment Department { get; set; }
        public virtual MDesignation Designation { get; set; }
        public virtual MPartyLocation PartyLocation { get; set; }
        public virtual MSuffix Suffix { get; set; }
        public virtual MTitle Title { get; set; }
        public virtual ICollection<SmPartyContactAddressType> SmPartyContactAddressType { get; set; }
        public virtual ICollection<SmPartyContactApproval> SmPartyContactApproval { get; set; }
        public virtual ICollection<SmPartyContactDocument> SmPartyContactDocument { get; set; }
    }
}
