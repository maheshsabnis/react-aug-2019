﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MBatch
    {
        public MBatch()
        {
            MSubBatch = new HashSet<MSubBatch>();
            SmBatchDetail = new HashSet<SmBatchDetail>();
            SmDeactivateBatch = new HashSet<SmDeactivateBatch>();
            SmMrtoWareHouse = new HashSet<SmMrtoWareHouse>();
            SmQasample = new HashSet<SmQasample>();
            SmRawMaterialIssued = new HashSet<SmRawMaterialIssued>();
            SmRawMaterialReceived = new HashSet<SmRawMaterialReceived>();
            SmTimeCardHourDetail = new HashSet<SmTimeCardHourDetail>();
        }

        public decimal BatchId { get; set; }
        public string BatchNo { get; set; }
        public string DummyBatchNo { get; set; }
        public decimal? BatchSequenceNo { get; set; }
        public decimal? CampaignId { get; set; }
        public decimal? ProductId { get; set; }
        public decimal? ProductPartyId { get; set; }
        public decimal? ProductionProcessVersionId { get; set; }
        public double? BatchSize { get; set; }
        public decimal? UnitId { get; set; }
        public double? BatchQuantity { get; set; }
        public decimal? QuantityUnit { get; set; }
        public bool? SplitBatch { get; set; }
        public DateTime? ManufacturedDate { get; set; }
        public DateTime? BatchExpiryDate { get; set; }
        public DateTime? ProposedDate { get; set; }
        public bool? QaapprovedFlag { get; set; }
        public DateTime? QaapprovedDateTime { get; set; }
        public decimal? QaapprovedBy { get; set; }
        public string Remark { get; set; }
        public DateTime? ExpectedShipDate { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? MktapprovedDateTime { get; set; }
        public decimal? MktapprovedBy { get; set; }
        public bool? MktapprovedFlag { get; set; }
        public bool? IntermediateBatch { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public byte[] RecordVersion { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }

        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual ICollection<MSubBatch> MSubBatch { get; set; }
        public virtual ICollection<SmBatchDetail> SmBatchDetail { get; set; }
        public virtual ICollection<SmDeactivateBatch> SmDeactivateBatch { get; set; }
        public virtual ICollection<SmMrtoWareHouse> SmMrtoWareHouse { get; set; }
        public virtual ICollection<SmQasample> SmQasample { get; set; }
        public virtual ICollection<SmRawMaterialIssued> SmRawMaterialIssued { get; set; }
        public virtual ICollection<SmRawMaterialReceived> SmRawMaterialReceived { get; set; }
        public virtual ICollection<SmTimeCardHourDetail> SmTimeCardHourDetail { get; set; }
    }
}
