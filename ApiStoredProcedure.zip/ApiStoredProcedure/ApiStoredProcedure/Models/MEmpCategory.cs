﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpCategory
    {
        public MEmpCategory()
        {
            SmEmpCategoryDocument = new HashSet<SmEmpCategoryDocument>();
        }

        public decimal EmpCategoryId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? EmployeeCategoryId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual MEmployeeCategory EmployeeCategory { get; set; }
        public virtual ICollection<SmEmpCategoryDocument> SmEmpCategoryDocument { get; set; }
    }
}
