﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProtocolInfo
    {
        public MProtocolInfo()
        {
            SmStabilityProtocolInfo = new HashSet<SmStabilityProtocolInfo>();
        }

        public decimal ProtocolInfoId { get; set; }
        public decimal? DisplayIndex { get; set; }
        public string Description { get; set; }
        public string Values { get; set; }
        public string InfoType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmStabilityProtocolInfo> SmStabilityProtocolInfo { get; set; }
    }
}
