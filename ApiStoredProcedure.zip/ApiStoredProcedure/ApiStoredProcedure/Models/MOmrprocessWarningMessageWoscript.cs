﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessWarningMessageWoscript
    {
        public decimal OmrprocessWarningMessageWoscriptId { get; set; }
        public decimal? OrderNo { get; set; }
        public string WarningOn { get; set; }
        public string WarningCondition { get; set; }
        public string FocusAfterWarning { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
