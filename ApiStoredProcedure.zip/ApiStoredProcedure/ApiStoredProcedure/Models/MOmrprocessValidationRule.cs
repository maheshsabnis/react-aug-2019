﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessValidationRule
    {
        public decimal OmrprocessValidationRuleId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string ValidationOn { get; set; }
        public string ValidationCondition { get; set; }
    }
}
