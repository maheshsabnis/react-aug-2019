﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTrainingModule
    {
        public MTrainingModule()
        {
            SmTrainingModuleRevision = new HashSet<SmTrainingModuleRevision>();
        }

        public decimal TrainingModuleId { get; set; }
        public string ModuleName { get; set; }
        public string ModuleCode { get; set; }
        public string NewRev { get; set; }
        public string OldRev { get; set; }
        public decimal? DocumentId { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Comment { get; set; }

        public virtual ICollection<SmTrainingModuleRevision> SmTrainingModuleRevision { get; set; }
    }
}
