﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDcckilledRequestHistory
    {
        public decimal DcckilledRequestHistoryId { get; set; }
        public decimal? DccrequestId { get; set; }
        public decimal? RequestorId { get; set; }
        public string ApproveSign { get; set; }
        public decimal? ApproveBy { get; set; }
        public DateTime? ApproveDate { get; set; }
        public bool? ApproveFlag { get; set; }
        public string RejectSign { get; set; }
        public decimal? RejectBy { get; set; }
        public DateTime? RejectDate { get; set; }
        public bool? RejectFlag { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual MDccrequest Dccrequest { get; set; }
    }
}
