﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDocumentNameHistory
    {
        public decimal DocumentNameHistoryId { get; set; }
        public decimal? DocumentId { get; set; }
        public string DocNum { get; set; }
        public decimal? ParentDocumentId { get; set; }
        public string DocTitle { get; set; }
        public string DocDescription { get; set; }
        public string Owner { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DocCategoryId { get; set; }
        public string CurrentRev { get; set; }
        public string TrainingReq4AllRevs { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
