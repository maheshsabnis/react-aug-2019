﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampaignDetails
    {
        public decimal CampaignDetailId { get; set; }
        public decimal? CampaignId { get; set; }
        public decimal? ProductId { get; set; }
        public decimal? FormulaId { get; set; }
        public decimal? ProductPartyId { get; set; }
        public decimal? Skuid { get; set; }
        public decimal? Quantity { get; set; }
        public decimal? UnitId { get; set; }
        public string Remark { get; set; }
        public decimal? NoofBatches { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }

        public virtual SmCampaign Campaign { get; set; }
        public virtual SmProductParty ProductParty { get; set; }
        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual MSku Sku { get; set; }
    }
}
