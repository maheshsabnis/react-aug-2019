﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSiInspectionFor
    {
        public MSiInspectionFor()
        {
            MSiDefects = new HashSet<MSiDefects>();
            MSiInspectionResultChecklist = new HashSet<MSiInspectionResultChecklist>();
            SmRawMaterialReceived = new HashSet<SmRawMaterialReceived>();
        }

        public decimal InspectionForId { get; set; }
        public string InspectionFor { get; set; }
        public string SamplingPlan { get; set; }
        public string IsTable { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<MSiDefects> MSiDefects { get; set; }
        public virtual ICollection<MSiInspectionResultChecklist> MSiInspectionResultChecklist { get; set; }
        public virtual ICollection<SmRawMaterialReceived> SmRawMaterialReceived { get; set; }
    }
}
