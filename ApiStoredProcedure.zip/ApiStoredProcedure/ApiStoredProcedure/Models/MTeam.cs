﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTeam
    {
        public decimal TeamId { get; set; }
        public string TeamName { get; set; }
        public decimal? ParentId { get; set; }
        public decimal? TeamCoordinator { get; set; }
        public decimal? GroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
