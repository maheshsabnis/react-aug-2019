﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEducationHistory
    {
        public decimal EducationHistoryId { get; set; }
        public decimal? EducationId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEducation Education { get; set; }
    }
}
