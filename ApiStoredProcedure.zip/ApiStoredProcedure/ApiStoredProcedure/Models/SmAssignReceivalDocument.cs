﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssignReceivalDocument
    {
        public decimal AssignReceivalDocumentId { get; set; }
        public decimal? AssignReceivalId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? DocTypeId { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }

        public virtual SmAssignReceival AssignReceival { get; set; }
    }
}
