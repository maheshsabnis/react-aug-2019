﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTypeOfWork
    {
        public MTypeOfWork()
        {
            SmWorkRequest01 = new HashSet<SmWorkRequest01>();
        }

        public decimal TypeOfWorkId { get; set; }
        public string TypeOfWork { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmWorkRequest01> SmWorkRequest01 { get; set; }
    }
}
