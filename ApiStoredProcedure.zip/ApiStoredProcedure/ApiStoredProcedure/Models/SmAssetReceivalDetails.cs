﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetReceivalDetails
    {
        public SmAssetReceivalDetails()
        {
            SmAssetNoDetail = new HashSet<SmAssetNoDetail>();
        }

        public decimal AssetReceivalDetailId { get; set; }
        public decimal? AssetReceivalId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? AssetModelId { get; set; }
        public decimal? PodetailId { get; set; }
        public decimal? ManufacturerId { get; set; }
        public double? Quantity { get; set; }
        public decimal? UnitId { get; set; }
        public decimal? Sets { get; set; }
        public DateTime? MfgDate { get; set; }
        public decimal? Rate { get; set; }
        public string Remark { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmAssetReceival AssetReceival { get; set; }
        public virtual ICollection<SmAssetNoDetail> SmAssetNoDetail { get; set; }
    }
}
