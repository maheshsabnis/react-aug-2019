﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSkill
    {
        public MSkill()
        {
            MEmpSkill = new HashSet<MEmpSkill>();
            SmSkillApproval = new HashSet<SmSkillApproval>();
            SmSkillHistory = new HashSet<SmSkillHistory>();
        }

        public decimal SkillId { get; set; }
        public string Skill { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MEmpSkill> MEmpSkill { get; set; }
        public virtual ICollection<SmSkillApproval> SmSkillApproval { get; set; }
        public virtual ICollection<SmSkillHistory> SmSkillHistory { get; set; }
    }
}
