﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MReports
    {
        public MReports()
        {
            MReportsVersions = new HashSet<MReportsVersions>();
        }

        public decimal ReportId { get; set; }
        public string ReportName { get; set; }
        public string FileName { get; set; }
        public byte[] ReportFile { get; set; }
        public string MenuLinkName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual ICollection<MReportsVersions> MReportsVersions { get; set; }
    }
}
