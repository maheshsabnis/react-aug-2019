﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class LTimeCardLock
    {
        public decimal TimeCardLockId { get; set; }
        public decimal? TimeCardLockPeriod { get; set; }
        public decimal? SsnArea { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
