﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDepartment
    {
        public MDepartment()
        {
            InverseParentDepartment = new HashSet<MDepartment>();
            MDccrequest = new HashSet<MDccrequest>();
            MEmployee = new HashSet<MEmployee>();
            MEmployeeDept = new HashSet<MEmployeeDept>();
            MHod = new HashSet<MHod>();
            MHodincharge = new HashSet<MHodincharge>();
            MPartyContact = new HashSet<MPartyContact>();
            SmAssetNoDetail = new HashSet<SmAssetNoDetail>();
            SmContractWork = new HashSet<SmContractWork>();
            SmDeactivateBatch = new HashSet<SmDeactivateBatch>();
            SmDepartmentActivity = new HashSet<SmDepartmentActivity>();
            SmDepartmentTrainingRequisitesRevision = new HashSet<SmDepartmentTrainingRequisitesRevision>();
            SmDeptInvolvedInRiskAssessment = new HashSet<SmDeptInvolvedInRiskAssessment>();
            SmDeptTrnReq = new HashSet<SmDeptTrnReq>();
            SmDocRevApproval = new HashSet<SmDocRevApproval>();
            SmMaterialRequizitionDetail = new HashSet<SmMaterialRequizitionDetail>();
            SmOverTime = new HashSet<SmOverTime>();
            SmWorQaassessment = new HashSet<SmWorQaassessment>();
            SmWorkRequest = new HashSet<SmWorkRequest>();
        }

        public decimal DepartmentId { get; set; }
        public string DepartmentNo { get; set; }
        public string DepartmentName { get; set; }
        public string Description { get; set; }
        public decimal? ParentDepartmentId { get; set; }
        public bool? InvDeptInFlag { get; set; }
        public bool? AssetOwnerShipFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public string Remark { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MDepartment ParentDepartment { get; set; }
        public virtual ICollection<MDepartment> InverseParentDepartment { get; set; }
        public virtual ICollection<MDccrequest> MDccrequest { get; set; }
        public virtual ICollection<MEmployee> MEmployee { get; set; }
        public virtual ICollection<MEmployeeDept> MEmployeeDept { get; set; }
        public virtual ICollection<MHod> MHod { get; set; }
        public virtual ICollection<MHodincharge> MHodincharge { get; set; }
        public virtual ICollection<MPartyContact> MPartyContact { get; set; }
        public virtual ICollection<SmAssetNoDetail> SmAssetNoDetail { get; set; }
        public virtual ICollection<SmContractWork> SmContractWork { get; set; }
        public virtual ICollection<SmDeactivateBatch> SmDeactivateBatch { get; set; }
        public virtual ICollection<SmDepartmentActivity> SmDepartmentActivity { get; set; }
        public virtual ICollection<SmDepartmentTrainingRequisitesRevision> SmDepartmentTrainingRequisitesRevision { get; set; }
        public virtual ICollection<SmDeptInvolvedInRiskAssessment> SmDeptInvolvedInRiskAssessment { get; set; }
        public virtual ICollection<SmDeptTrnReq> SmDeptTrnReq { get; set; }
        public virtual ICollection<SmDocRevApproval> SmDocRevApproval { get; set; }
        public virtual ICollection<SmMaterialRequizitionDetail> SmMaterialRequizitionDetail { get; set; }
        public virtual ICollection<SmOverTime> SmOverTime { get; set; }
        public virtual ICollection<SmWorQaassessment> SmWorQaassessment { get; set; }
        public virtual ICollection<SmWorkRequest> SmWorkRequest { get; set; }
    }
}
