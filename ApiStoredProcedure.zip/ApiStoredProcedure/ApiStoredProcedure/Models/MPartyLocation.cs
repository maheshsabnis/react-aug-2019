﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPartyLocation
    {
        public MPartyLocation()
        {
            MPartyContact = new HashSet<MPartyContact>();
            SmMaterialPartyCodeSupplier = new HashSet<SmMaterialPartyCodeSupplier>();
            SmPartyLocationAddressType = new HashSet<SmPartyLocationAddressType>();
            SmPartyLocationApproval = new HashSet<SmPartyLocationApproval>();
            SmPartyLocationDocument = new HashSet<SmPartyLocationDocument>();
            SmPartyLocationPhone = new HashSet<SmPartyLocationPhone>();
        }

        public decimal PartyLocationId { get; set; }
        public decimal? PartyId { get; set; }
        public string PartyLocationCode { get; set; }
        public string PartyLocation { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public decimal? CountryId { get; set; }
        public decimal? StateId { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public string WebSite { get; set; }
        public string Email { get; set; }
        public string Remark { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MCountry Country { get; set; }
        public virtual MParty Party { get; set; }
        public virtual MState State { get; set; }
        public virtual ICollection<MPartyContact> MPartyContact { get; set; }
        public virtual ICollection<SmMaterialPartyCodeSupplier> SmMaterialPartyCodeSupplier { get; set; }
        public virtual ICollection<SmPartyLocationAddressType> SmPartyLocationAddressType { get; set; }
        public virtual ICollection<SmPartyLocationApproval> SmPartyLocationApproval { get; set; }
        public virtual ICollection<SmPartyLocationDocument> SmPartyLocationDocument { get; set; }
        public virtual ICollection<SmPartyLocationPhone> SmPartyLocationPhone { get; set; }
    }
}
