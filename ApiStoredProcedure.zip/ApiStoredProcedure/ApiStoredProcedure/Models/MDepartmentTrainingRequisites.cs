﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDepartmentTrainingRequisites
    {
        public MDepartmentTrainingRequisites()
        {
            SmDepartmentTrainingRequisitesRevision = new HashSet<SmDepartmentTrainingRequisitesRevision>();
        }

        public decimal DepartmentTrainingRequisitesId { get; set; }
        public decimal? DepartmentId { get; set; }
        public string DepartmentTrainingRequisitesCode { get; set; }
        public string NewRev { get; set; }
        public string OldRev { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }

        public virtual ICollection<SmDepartmentTrainingRequisitesRevision> SmDepartmentTrainingRequisitesRevision { get; set; }
    }
}
