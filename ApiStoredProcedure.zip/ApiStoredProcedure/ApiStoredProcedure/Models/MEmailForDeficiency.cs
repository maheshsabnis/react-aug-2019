﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmailForDeficiency
    {
        public decimal EmailForDeficiencyId { get; set; }
        public string ToEmailId { get; set; }
        public string Utype { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? Datetime { get; set; }
    }
}
