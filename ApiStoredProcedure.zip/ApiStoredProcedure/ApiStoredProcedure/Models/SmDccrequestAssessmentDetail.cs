﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDccrequestAssessmentDetail
    {
        public decimal DccrequestAssessmentDetailId { get; set; }
        public decimal? DccrequestId { get; set; }
        public decimal? DccstakeHolderRoleId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual MDccrequest Dccrequest { get; set; }
        public virtual MDccrequestAssessmentRole DccstakeHolderRole { get; set; }
    }
}
