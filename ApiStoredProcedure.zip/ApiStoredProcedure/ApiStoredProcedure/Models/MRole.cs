﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRole
    {
        public MRole()
        {
            MEmployeeRole = new HashSet<MEmployeeRole>();
            MRolewiseAccess = new HashSet<MRolewiseAccess>();
            SmRoleApproval = new HashSet<SmRoleApproval>();
        }

        public decimal RoleId { get; set; }
        public string Role { get; set; }
        public decimal? Priority { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MEmployeeRole> MEmployeeRole { get; set; }
        public virtual ICollection<MRolewiseAccess> MRolewiseAccess { get; set; }
        public virtual ICollection<SmRoleApproval> SmRoleApproval { get; set; }
    }
}
