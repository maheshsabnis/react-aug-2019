﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBomversionMaterial
    {
        public decimal BomversionMaterialId { get; set; }
        public decimal? BomversionId { get; set; }
        public decimal? RawMaterialId { get; set; }
        public double? Quantity { get; set; }
        public decimal QuantityUnitId { get; set; }
        public string Comment { get; set; }
        public bool? IsEquivalent { get; set; }
        public decimal? EquivalentToId { get; set; }
        public bool? IsCombine { get; set; }
        public decimal? FormulaDetailId { get; set; }
        public decimal? EquivalentToRawMaterialId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual SmBomversion Bomversion { get; set; }
        public virtual MUnit QuantityUnit { get; set; }
        public virtual SmRawMaterialParty RawMaterial { get; set; }
    }
}
