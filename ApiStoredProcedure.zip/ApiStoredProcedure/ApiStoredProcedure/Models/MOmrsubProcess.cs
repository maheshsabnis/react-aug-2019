﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrsubProcess
    {
        public MOmrsubProcess()
        {
            SmOmrsubProcessPending = new HashSet<SmOmrsubProcessPending>();
            SmUserRightsNew = new HashSet<SmUserRightsNew>();
        }

        public decimal OmrsubProcessId { get; set; }
        public decimal? OmrprocessId { get; set; }
        public string ProcessName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmOmrsubProcessPending> SmOmrsubProcessPending { get; set; }
        public virtual ICollection<SmUserRightsNew> SmUserRightsNew { get; set; }
    }
}
