﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MBom
    {
        public MBom()
        {
            SmBomversion = new HashSet<SmBomversion>();
        }

        public decimal Bomid { get; set; }
        public decimal? ProductFamilyId { get; set; }
        public string Bomcode { get; set; }
        public decimal? ProductionProcessVersionId { get; set; }
        public decimal? ProductionProcessVersionDetailId { get; set; }
        public decimal? ProductId { get; set; }
        public decimal? FormulaId { get; set; }
        public string SubCode { get; set; }
        public decimal? FormulaBomid { get; set; }
        public decimal? PackagingBomid { get; set; }
        public decimal? ProductionSuppliesBomid { get; set; }
        public bool? SubmitFlag { get; set; }
        public decimal? SubmittedBy { get; set; }
        public string SubmittedSign { get; set; }
        public bool? SubmittedIncorrectPassword { get; set; }
        public DateTime? SubmittedByDateTime { get; set; }
        public bool? ReviewFlag { get; set; }
        public decimal? ReviewedBy { get; set; }
        public string ReviewedSign { get; set; }
        public bool? ReviewedIncorrectPassword { get; set; }
        public DateTime? ReviewedByDateTime { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public string ApprovedSign { get; set; }
        public bool? ApprovedIncorrectPassword { get; set; }
        public DateTime? ApprovedByDateTime { get; set; }
        public bool? RejectFlag { get; set; }
        public decimal? RejectedBy { get; set; }
        public string RejectedSign { get; set; }
        public bool? RejectedIncorrectPassword { get; set; }
        public DateTime? RejectedByDateTime { get; set; }
        public bool? ResubmitFlag { get; set; }
        public string Status { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? ReferenceBomid { get; set; }

        public virtual MFormula Formula { get; set; }
        public virtual MFormulaBom FormulaBom { get; set; }
        public virtual MPackagingBom PackagingBom { get; set; }
        public virtual MProduct Product { get; set; }
        public virtual MProductionSuppliesBom ProductionSuppliesBom { get; set; }
        public virtual ICollection<SmBomversion> SmBomversion { get; set; }
    }
}
