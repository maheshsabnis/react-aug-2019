﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampPsbom
    {
        public SmCampPsbom()
        {
            SmCampPsbomdetail = new HashSet<SmCampPsbomdetail>();
        }

        public decimal CampPsbomid { get; set; }
        public string Bomcode { get; set; }
        public decimal? CampaignId { get; set; }
        public decimal? ProductionSuppliesBomid { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MProductionSuppliesBom ProductionSuppliesBom { get; set; }
        public virtual ICollection<SmCampPsbomdetail> SmCampPsbomdetail { get; set; }
    }
}
