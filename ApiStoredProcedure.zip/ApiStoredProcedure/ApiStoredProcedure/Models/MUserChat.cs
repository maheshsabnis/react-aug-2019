﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MUserChat
    {
        public decimal UserChatId { get; set; }
        public decimal? FromUserId { get; set; }
        public decimal? ToUserId { get; set; }
        public string Msg { get; set; }
        public DateTime? MsgDateTime { get; set; }
        public bool? Seen { get; set; }
        public DateTime? SeenDateTime { get; set; }
    }
}
