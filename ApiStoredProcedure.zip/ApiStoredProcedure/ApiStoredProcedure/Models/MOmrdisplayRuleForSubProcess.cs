﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrdisplayRuleForSubProcess
    {
        public decimal OmrsubprocessDisplayRuleId { get; set; }
        public decimal? OmrprocessDisplayRuleId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
    }
}
