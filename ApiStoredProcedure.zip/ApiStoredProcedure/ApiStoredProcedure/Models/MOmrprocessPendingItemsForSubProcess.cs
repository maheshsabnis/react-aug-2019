﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessPendingItemsForSubProcess
    {
        public decimal OmrprocessPendingItemsForSubProcessId { get; set; }
        public decimal? OmrprocessPendingItemsId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? SubMenuId { get; set; }

        public virtual MOmrprocessPendingItems OmrprocessPendingItems { get; set; }
    }
}
