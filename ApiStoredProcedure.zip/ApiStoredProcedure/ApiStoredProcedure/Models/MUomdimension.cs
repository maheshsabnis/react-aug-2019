﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MUomdimension
    {
        public decimal UomdimensionId { get; set; }
        public decimal? ConvertFrom { get; set; }
        public decimal? ConvertTo { get; set; }
        public double? MultiplyBy { get; set; }
        public double? DivideBy { get; set; }
        public decimal? Exponent { get; set; }
        public float? AddConstant { get; set; }
        public decimal? Rounding { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
