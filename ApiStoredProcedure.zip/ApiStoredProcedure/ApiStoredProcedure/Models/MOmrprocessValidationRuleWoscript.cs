﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessValidationRuleWoscript
    {
        public decimal OmrprocessValidationRuleWoscriptId { get; set; }
        public decimal? OrderNo { get; set; }
        public string ValidationOn { get; set; }
        public string ValidationCondition { get; set; }
        public string FocusAfterValidation { get; set; }
        public string FormType { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
