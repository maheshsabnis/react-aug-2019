﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetPoterms
    {
        public decimal PoTermId { get; set; }
        public decimal? AssetPurchaseOrderId { get; set; }
        public decimal? SeqNo { get; set; }
        public decimal? TermId { get; set; }
        public string Description { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmAssetPurchaseOrder AssetPurchaseOrder { get; set; }
    }
}
