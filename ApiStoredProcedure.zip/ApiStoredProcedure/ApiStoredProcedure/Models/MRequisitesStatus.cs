﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRequisitesStatus
    {
        public MRequisitesStatus()
        {
            SmDepartmentTrainingRequisitesRevision = new HashSet<SmDepartmentTrainingRequisitesRevision>();
            SmJobTitleRequisitesRevision = new HashSet<SmJobTitleRequisitesRevision>();
        }

        public decimal RequisitesStatusId { get; set; }
        public string Status { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmDepartmentTrainingRequisitesRevision> SmDepartmentTrainingRequisitesRevision { get; set; }
        public virtual ICollection<SmJobTitleRequisitesRevision> SmJobTitleRequisitesRevision { get; set; }
    }
}
