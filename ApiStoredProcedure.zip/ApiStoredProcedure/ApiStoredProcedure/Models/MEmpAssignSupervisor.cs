﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpAssignSupervisor
    {
        public MEmpAssignSupervisor()
        {
            SmEmpAssignSupervisorDocument = new HashSet<SmEmpAssignSupervisorDocument>();
        }

        public decimal EmpAssignSupervisorId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? EmployeeDeptId { get; set; }
        public decimal? SupervisorId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Reason { get; set; }
        public bool? IsDefault { get; set; }
        public string DeactivationFlag { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual ICollection<SmEmpAssignSupervisorDocument> SmEmpAssignSupervisorDocument { get; set; }
    }
}
