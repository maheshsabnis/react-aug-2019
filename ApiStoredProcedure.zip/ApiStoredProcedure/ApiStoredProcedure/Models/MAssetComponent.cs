﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAssetComponent
    {
        public decimal AssetComponentId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? ParentAssetId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Remark { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? ChangeId { get; set; }

        public virtual MAsset ParentAsset { get; set; }
    }
}
