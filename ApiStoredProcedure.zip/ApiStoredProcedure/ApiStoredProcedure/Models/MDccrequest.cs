﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDccrequest
    {
        public MDccrequest()
        {
            MDcccompletionDate = new HashSet<MDcccompletionDate>();
            SmDcckilledRequestHistory = new HashSet<SmDcckilledRequestHistory>();
            SmDccrequestAssessmentDetail = new HashSet<SmDccrequestAssessmentDetail>();
            SmDocRevision = new HashSet<SmDocRevision>();
        }

        public decimal DccrequestId { get; set; }
        public string RequestNo { get; set; }
        public decimal? RequestBy { get; set; }
        public decimal? DocumentId { get; set; }
        public decimal? DocRevId { get; set; }
        public string DocTitle { get; set; }
        public string DocDescription { get; set; }
        public string DocComment { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DocCategoryId { get; set; }
        public DateTime? RequestDate { get; set; }
        public DateTime? NeedByDate { get; set; }
        public string Capano { get; set; }
        public string Priority { get; set; }
        public bool? ReqReviewFlag { get; set; }
        public string ReqReviewedSign { get; set; }
        public bool? ReqReviewedIncorrectPassword { get; set; }
        public decimal? ReqReviewedBy { get; set; }
        public DateTime? ReqReviewedByDateTime { get; set; }
        public bool? ReqApproveFlag { get; set; }
        public string ReqApprovedSign { get; set; }
        public bool? ReqApproveIncorrectPassword { get; set; }
        public decimal? ReqApprovedBy { get; set; }
        public DateTime? ReqApprovedByDatetime { get; set; }
        public bool? ReqRejectedFlag { get; set; }
        public string ReqRejectedSign { get; set; }
        public bool? ReqRejectedIncorrectPassword { get; set; }
        public decimal? ReqRejectedBy { get; set; }
        public DateTime? ReqRejectedByDateTime { get; set; }
        public string ReqApprovedByRemark { get; set; }
        public bool? ReqSubmitFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? DccrequestTypeId { get; set; }
        public bool? KillFlag { get; set; }
        public string KilledSign { get; set; }
        public bool? KilledIncorrectPassword { get; set; }
        public decimal? KilledBy { get; set; }
        public DateTime? KilledDate { get; set; }
        public string KilledComment { get; set; }
        public string RequestType { get; set; }
        public bool? IsActiveFlag { get; set; }

        public virtual MDccrequestType DccrequestType { get; set; }
        public virtual MDepartment Department { get; set; }
        public virtual MDocCategory DocCategory { get; set; }
        public virtual MDocument Document { get; set; }
        public virtual ICollection<MDcccompletionDate> MDcccompletionDate { get; set; }
        public virtual ICollection<SmDcckilledRequestHistory> SmDcckilledRequestHistory { get; set; }
        public virtual ICollection<SmDccrequestAssessmentDetail> SmDccrequestAssessmentDetail { get; set; }
        public virtual ICollection<SmDocRevision> SmDocRevision { get; set; }
    }
}
