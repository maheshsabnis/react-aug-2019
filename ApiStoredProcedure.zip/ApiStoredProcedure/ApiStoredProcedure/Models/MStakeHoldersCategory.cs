﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MStakeHoldersCategory
    {
        public decimal StakeHoldersCategoryId { get; set; }
        public string Category { get; set; }
    }
}
