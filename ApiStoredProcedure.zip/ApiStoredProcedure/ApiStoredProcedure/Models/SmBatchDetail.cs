﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBatchDetail
    {
        public SmBatchDetail()
        {
            SmRawMaterialIssued = new HashSet<SmRawMaterialIssued>();
        }

        public decimal BatchDetailId { get; set; }
        public decimal? BatchId { get; set; }
        public decimal? RawMaterialReceivedId { get; set; }
        public double? Quantity { get; set; }
        public decimal? QuantityUnitId { get; set; }
        public string Remark { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MBatch Batch { get; set; }
        public virtual MUnit QuantityUnit { get; set; }
        public virtual ICollection<SmRawMaterialIssued> SmRawMaterialIssued { get; set; }
    }
}
