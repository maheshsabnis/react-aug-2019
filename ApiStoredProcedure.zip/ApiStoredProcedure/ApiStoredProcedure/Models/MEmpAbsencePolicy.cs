﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpAbsencePolicy
    {
        public MEmpAbsencePolicy()
        {
            MAbsenceRequest = new HashSet<MAbsenceRequest>();
            SmEmpAbsencePolicyApproval = new HashSet<SmEmpAbsencePolicyApproval>();
            SmEmpAbsencePolicyDocument = new HashSet<SmEmpAbsencePolicyDocument>();
        }

        public decimal EmpAbsencePolicyId { get; set; }
        public decimal? AbsencePolicyId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? AbsenceYearId { get; set; }
        public bool? NoLimitFlag { get; set; }
        public bool? CarryFlag { get; set; }
        public double? MaxCarryForwardDaysLimit { get; set; }
        public bool? EligibilityCriteriaFlag { get; set; }
        public double? TotalNoOfLeave { get; set; }
        public double? TotalNoOfLeaveInHrs { get; set; }
        public double? PerWorkingDayHrs { get; set; }
        public string PerWorkingDayHrsUnit { get; set; }
        public double? NoOfLeave { get; set; }
        public string NoOfLeaveUnit { get; set; }
        public DateTime? EffectiveFromDate { get; set; }
        public DateTime? EffectiveToDate { get; set; }
        public DateTime? EffectiveCloseDate { get; set; }
        public double? AllowedDays { get; set; }
        public double? AllowedHours { get; set; }
        public double? TotalAllowedHours { get; set; }
        public double? CarryForwordDays { get; set; }
        public double? CarryForwordHours { get; set; }
        public double? TotalCarryForwordHours { get; set; }
        public double? FinalAllowedDays { get; set; }
        public double? FinalAllowedHours { get; set; }
        public double? FinalTotalAllowedHours { get; set; }
        public double? EligibleDays { get; set; }
        public double? EligibleHours { get; set; }
        public double? TotalEligibleHours { get; set; }
        public double? RequestedDays { get; set; }
        public double? RequestedHours { get; set; }
        public double? TotalRequestedHours { get; set; }
        public double? ApprovedDays { get; set; }
        public double? ApprovedHours { get; set; }
        public double? TotalApprovedHours { get; set; }
        public double? AvailedDays { get; set; }
        public double? AvailedHours { get; set; }
        public double? TotalAvailedHours { get; set; }
        public double? BalanceDays { get; set; }
        public double? BalanceHours { get; set; }
        public double? TotalBalanceHours { get; set; }
        public DateTime? LastModifiedDateTime { get; set; }
        public bool? HrrequestFlag { get; set; }
        public bool? CreditFlag { get; set; }
        public double? CreditValidity { get; set; }
        public double? ConsolidateRequestedDays { get; set; }
        public double? ConsolidatedDays { get; set; }
        public double? TempBalanceDays { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? EmpAbsencePolicyStatusId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }
        public string Type { get; set; }
        public double? PrevTotalNoOfLeave { get; set; }

        public virtual MAbsencePolicy AbsencePolicy { get; set; }
        public virtual MEmpAbsencePolicyStatus EmpAbsencePolicyStatus { get; set; }
        public virtual ICollection<MAbsenceRequest> MAbsenceRequest { get; set; }
        public virtual ICollection<SmEmpAbsencePolicyApproval> SmEmpAbsencePolicyApproval { get; set; }
        public virtual ICollection<SmEmpAbsencePolicyDocument> SmEmpAbsencePolicyDocument { get; set; }
    }
}
