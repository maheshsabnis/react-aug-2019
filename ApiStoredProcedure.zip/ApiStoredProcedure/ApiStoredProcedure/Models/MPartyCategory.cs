﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPartyCategory
    {
        public MPartyCategory()
        {
            SmPartyCategoryApproval = new HashSet<SmPartyCategoryApproval>();
            SmPartyCategoryDetail = new HashSet<SmPartyCategoryDetail>();
        }

        public decimal PartyCategoryId { get; set; }
        public string Category { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<SmPartyCategoryApproval> SmPartyCategoryApproval { get; set; }
        public virtual ICollection<SmPartyCategoryDetail> SmPartyCategoryDetail { get; set; }
    }
}
