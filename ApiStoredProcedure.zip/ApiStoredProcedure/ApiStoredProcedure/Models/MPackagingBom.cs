﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPackagingBom
    {
        public MPackagingBom()
        {
            MBom = new HashSet<MBom>();
            SmCampPkgBom = new HashSet<SmCampPkgBom>();
            SmPackagingBomdetail = new HashSet<SmPackagingBomdetail>();
        }

        public decimal PackagingBomid { get; set; }
        public string Bomcode { get; set; }
        public decimal? FormulaId { get; set; }
        public decimal? Skuid { get; set; }
        public decimal? ProductId { get; set; }
        public decimal? PackagingLevel { get; set; }
        public decimal? ShipperLevel { get; set; }
        public double? QuantityPerShipper { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ReferencePackagingBomid { get; set; }
        public double? MultiplierFactor { get; set; }
        public string IsTransferFlag { get; set; }

        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual ICollection<MBom> MBom { get; set; }
        public virtual ICollection<SmCampPkgBom> SmCampPkgBom { get; set; }
        public virtual ICollection<SmPackagingBomdetail> SmPackagingBomdetail { get; set; }
    }
}
