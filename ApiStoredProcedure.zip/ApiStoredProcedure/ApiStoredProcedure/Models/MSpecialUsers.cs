﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSpecialUsers
    {
        public decimal SpecialUsersId { get; set; }
        public decimal? UserId { get; set; }
        public decimal? SubMenuId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MSubMenu SubMenu { get; set; }
        public virtual MUser User { get; set; }
    }
}
