﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpTrnReq
    {
        public decimal EmpTrnReq { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? TrnClassId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual MEmployee Employee { get; set; }
    }
}
