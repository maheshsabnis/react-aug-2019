﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCustomerProductSpecification
    {
        public SmCustomerProductSpecification()
        {
            SmPackageMaterial = new HashSet<SmPackageMaterial>();
            SmProductBom = new HashSet<SmProductBom>();
        }

        public decimal CustomerProductSpecificationId { get; set; }
        public decimal? ProductCustomerId { get; set; }
        public string LabelType { get; set; }
        public string CustomerProductName { get; set; }
        public decimal? FormulaId { get; set; }
        public string Upc { get; set; }
        public string Ndc { get; set; }
        public string ThirteenDcode { get; set; }
        public decimal? ProductManufacturerId { get; set; }
        public decimal? ProductSupplierId { get; set; }
        public decimal? TestingPartyId { get; set; }
        public decimal? StabilityPartyId { get; set; }
        public decimal? PackagingPartyId { get; set; }
        public string PackageType { get; set; }
        public string QtyBulkPerBlister { get; set; }
        public string BlisterCardSize { get; set; }
        public string CardType { get; set; }
        public string BundlingofBlisters { get; set; }
        public string QtyOfBlistersInCarton { get; set; }
        public string QtyBulkPerBottle { get; set; }
        public string BottleSizeType { get; set; }
        public string CapSizeType { get; set; }
        public string Cotton { get; set; }
        public string Desiccant { get; set; }
        public string NeckBand { get; set; }
        public string BodyBand { get; set; }
        public string LabelSizeType { get; set; }
        public string LabelSupplier { get; set; }
        public string BundlingofBottles { get; set; }
        public string CartonPerBottle { get; set; }
        public string UpcforCarton { get; set; }
        public string CartonSupplier { get; set; }
        public string DisplaySize { get; set; }
        public string QtyPerDisplay { get; set; }
        public string ShipperSize { get; set; }
        public string UpcforShipper { get; set; }
        public string QtyPerShipper { get; set; }
        public string LabelForShipper { get; set; }
        public string CasesPerSkid { get; set; }
        public bool? PrepareFlag { get; set; }
        public string PreparedByRemark { get; set; }
        public bool? ReviewFlag { get; set; }
        public decimal? ReviewedBy { get; set; }
        public DateTime? ReviewedByQcDateTime { get; set; }
        public string ReviewedByRemark { get; set; }
        public bool? ReviewCorrection { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public DateTime? ApprovedByQaDatetime { get; set; }
        public string ApprovedByRemark { get; set; }
        public bool? ApprovalCorrection { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public string Revision { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MFormula Formula { get; set; }
        public virtual SmProductParty PackagingParty { get; set; }
        public virtual SmProductParty ProductCustomer { get; set; }
        public virtual SmProductParty ProductManufacturer { get; set; }
        public virtual SmProductParty ProductSupplier { get; set; }
        public virtual SmProductParty StabilityParty { get; set; }
        public virtual SmProductParty TestingParty { get; set; }
        public virtual ICollection<SmPackageMaterial> SmPackageMaterial { get; set; }
        public virtual ICollection<SmProductBom> SmProductBom { get; set; }
    }
}
