﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDocRevApprovalHistory
    {
        public decimal DocRevApprovalHistoryId { get; set; }
        public decimal? DocRevApprovalId { get; set; }
        public decimal? ApprovedBy { get; set; }
        public decimal? SequenceNo { get; set; }
        public decimal? DccstakeHolderRoleId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public string HistorySign { get; set; }
        public bool? HistoryIncorrectPassword { get; set; }
        public decimal? HistoryBy { get; set; }
        public DateTime? HistoryDate { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MDccrequestAssessmentRole DccstakeHolderRole { get; set; }
        public virtual SmDocRevApproval DocRevApproval { get; set; }
    }
}
