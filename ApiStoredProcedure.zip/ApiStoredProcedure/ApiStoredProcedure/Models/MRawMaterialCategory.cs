﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRawMaterialCategory
    {
        public MRawMaterialCategory()
        {
            MRawMaterial = new HashSet<MRawMaterial>();
            SmRawMaterialCategoryApproval = new HashSet<SmRawMaterialCategoryApproval>();
            SmRawMaterialCategoryDetail = new HashSet<SmRawMaterialCategoryDetail>();
            SmRawMaterialCategoryForPo = new HashSet<SmRawMaterialCategoryForPo>();
        }

        public decimal RawMaterialCategoryId { get; set; }
        public string RawMaterialCategory { get; set; }
        public string Code { get; set; }
        public string CategoryCode { get; set; }
        public decimal? ItemTypeId { get; set; }
        public string CategoryType { get; set; }
        public string InventoryFlag { get; set; }
        public decimal? InspectionForId { get; set; }
        public string DispositionType { get; set; }
        public bool? IsParent { get; set; }
        public bool? IsBulk { get; set; }
        public string Remark { get; set; }
        public decimal? MaterialTypeId { get; set; }
        public bool? ReviewThroughSampling { get; set; }
        public decimal? ReconciliationWeightPer { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public bool? ReusableFlag { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }
        public decimal? SampleTypeId { get; set; }

        public virtual MMaterialType MaterialType { get; set; }
        public virtual ICollection<MRawMaterial> MRawMaterial { get; set; }
        public virtual ICollection<SmRawMaterialCategoryApproval> SmRawMaterialCategoryApproval { get; set; }
        public virtual ICollection<SmRawMaterialCategoryDetail> SmRawMaterialCategoryDetail { get; set; }
        public virtual ICollection<SmRawMaterialCategoryForPo> SmRawMaterialCategoryForPo { get; set; }
    }
}
