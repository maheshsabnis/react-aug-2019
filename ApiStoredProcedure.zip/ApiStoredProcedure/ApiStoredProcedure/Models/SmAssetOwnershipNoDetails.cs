﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetOwnershipNoDetails
    {
        public decimal AssetOwnerShipId { get; set; }
        public decimal? AssetNodetailId { get; set; }
        public decimal? DeptId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Deactivationflag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal SiteId { get; set; }

        public virtual SmAssetNoDetail AssetNodetail { get; set; }
    }
}
