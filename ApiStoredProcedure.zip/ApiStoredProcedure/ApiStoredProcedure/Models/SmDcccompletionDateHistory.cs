﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDcccompletionDateHistory
    {
        public decimal DcccompletionDateHistoryId { get; set; }
        public decimal DcccompletionDateId { get; set; }
        public double? Duration { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? CompletionDate { get; set; }
        public decimal? DccstakeHolderRoleId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public string Comment { get; set; }
        public bool? RushFlag { get; set; }
        public decimal? RushedBy { get; set; }
        public string RushedSign { get; set; }
        public bool? RushedIncorrectPassword { get; set; }
        public DateTime? RushedByDateTime { get; set; }

        public virtual MDcccompletionDate DcccompletionDate { get; set; }
        public virtual MDccrequestAssessmentRole DccstakeHolderRole { get; set; }
    }
}
