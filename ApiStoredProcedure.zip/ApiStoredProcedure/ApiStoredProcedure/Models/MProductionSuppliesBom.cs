﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProductionSuppliesBom
    {
        public MProductionSuppliesBom()
        {
            MBom = new HashSet<MBom>();
            SmCampPsbom = new HashSet<SmCampPsbom>();
            SmProductionSuppliesBomdetail = new HashSet<SmProductionSuppliesBomdetail>();
        }

        public decimal ProductionSuppliesBomid { get; set; }
        public string Bomcode { get; set; }
        public decimal? FormulaId { get; set; }
        public decimal? ProductId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ReferencePsbomid { get; set; }
        public double? MultiplierFactor { get; set; }
        public string IsTransferFlag { get; set; }

        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual ICollection<MBom> MBom { get; set; }
        public virtual ICollection<SmCampPsbom> SmCampPsbom { get; set; }
        public virtual ICollection<SmProductionSuppliesBomdetail> SmProductionSuppliesBomdetail { get; set; }
    }
}
