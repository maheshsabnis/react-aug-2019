﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDepartmentActivity
    {
        public SmDepartmentActivity()
        {
            SmTimeCardHourDetail = new HashSet<SmTimeCardHourDetail>();
        }

        public decimal DepartmentActivityId { get; set; }
        public decimal? ActivityId { get; set; }
        public decimal? DepartmentId { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MActivity Activity { get; set; }
        public virtual MUser AddedByNavigation { get; set; }
        public virtual MDepartment Department { get; set; }
        public virtual ICollection<SmTimeCardHourDetail> SmTimeCardHourDetail { get; set; }
    }
}
