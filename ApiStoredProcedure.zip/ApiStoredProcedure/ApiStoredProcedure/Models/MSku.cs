﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSku
    {
        public MSku()
        {
            SmCampaignDetails = new HashSet<SmCampaignDetails>();
            SmProductionYearlyProjectionDetail = new HashSet<SmProductionYearlyProjectionDetail>();
            SmSkudocument = new HashSet<SmSkudocument>();
            SmYearlyProjectionDetail = new HashSet<SmYearlyProjectionDetail>();
            TmpCampaignDetails = new HashSet<TmpCampaignDetails>();
        }

        public decimal Skuid { get; set; }
        public decimal? ProductId { get; set; }
        public double? Quantity { get; set; }
        public decimal? UnitId { get; set; }
        public string Ndc { get; set; }
        public string Remark { get; set; }
        public string FormType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public string Remark1 { get; set; }
        public decimal? RequestBy { get; set; }
        public decimal? ProductTypeHistoryId { get; set; }
        public decimal? ProductTypeId { get; set; }

        public virtual MProduct Product { get; set; }
        public virtual SmProductTypeHistory ProductTypeHistory { get; set; }
        public virtual ICollection<SmCampaignDetails> SmCampaignDetails { get; set; }
        public virtual ICollection<SmProductionYearlyProjectionDetail> SmProductionYearlyProjectionDetail { get; set; }
        public virtual ICollection<SmSkudocument> SmSkudocument { get; set; }
        public virtual ICollection<SmYearlyProjectionDetail> SmYearlyProjectionDetail { get; set; }
        public virtual ICollection<TmpCampaignDetails> TmpCampaignDetails { get; set; }
    }
}
