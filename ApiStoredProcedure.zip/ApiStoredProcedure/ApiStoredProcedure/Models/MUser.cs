﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MUser
    {
        public MUser()
        {
            InverseAddedByNavigation = new HashSet<MUser>();
            MActivity = new HashSet<MActivity>();
            MAssetModel = new HashSet<MAssetModel>();
            MAssetModelFixParam = new HashSet<MAssetModelFixParam>();
            MDrug = new HashSet<MDrug>();
            MEmployeeLeave = new HashSet<MEmployeeLeave>();
            MEmployeeLeaveDate = new HashSet<MEmployeeLeaveDate>();
            MEquipment = new HashSet<MEquipment>();
            MEquipmentModel = new HashSet<MEquipmentModel>();
            MOrderStatus = new HashSet<MOrderStatus>();
            MPackage = new HashSet<MPackage>();
            MPackageComp = new HashSet<MPackageComp>();
            MPackageType = new HashSet<MPackageType>();
            MPartyAddressType = new HashSet<MPartyAddressType>();
            MPartyLocation = new HashSet<MPartyLocation>();
            MProject = new HashSet<MProject>();
            MSite = new HashSet<MSite>();
            MSpecialUsers = new HashSet<MSpecialUsers>();
            MStmtestSolution = new HashSet<MStmtestSolution>();
            MUnitOperation = new HashSet<MUnitOperation>();
            MUserRightsForEmail = new HashSet<MUserRightsForEmail>();
            MVendorAddressTypeOld = new HashSet<MVendorAddressTypeOld>();
            MVendorLicenseOld = new HashSet<MVendorLicenseOld>();
            MVendorLocationOld = new HashSet<MVendorLocationOld>();
            MVendorTaxOld = new HashSet<MVendorTaxOld>();
            SSuggestionAddedByNavigation = new HashSet<SSuggestion>();
            SSuggestionSuggestionByNavigation = new HashSet<SSuggestion>();
            SmAssetReceival = new HashSet<SmAssetReceival>();
            SmContract = new HashSet<SmContract>();
            SmDepartmentActivity = new HashSet<SmDepartmentActivity>();
            SmFormulaAsset = new HashSet<SmFormulaAsset>();
            SmHodapproval = new HashSet<SmHodapproval>();
            SmMaterialRequizitionAddedByNavigation = new HashSet<SmMaterialRequizition>();
            SmMaterialRequizitionRequizitionByNavigation = new HashSet<SmMaterialRequizition>();
            SmOmrsubProcessPending = new HashSet<SmOmrsubProcessPending>();
            SmOverTimeAddedByNavigation = new HashSet<SmOverTime>();
            SmOverTimeDeptApprovedByNavigation = new HashSet<SmOverTime>();
            SmOverTimeHrapprovedByNavigation = new HashSet<SmOverTime>();
            SmPackCompParameter = new HashSet<SmPackCompParameter>();
            SmPartyLicense = new HashSet<SmPartyLicense>();
            SmPartyTax = new HashSet<SmPartyTax>();
            SmPmcycleStakeHolder = new HashSet<SmPmcycleStakeHolder>();
            SmProductBom = new HashSet<SmProductBom>();
            SmRawMaterialParty = new HashSet<SmRawMaterialParty>();
            SmSalesOrderStatus = new HashSet<SmSalesOrderStatus>();
            SmSiteEmployeeLeaveAddedByNavigation = new HashSet<SmSiteEmployeeLeave>();
            SmSiteEmployeeLeaveApprovedByNavigation = new HashSet<SmSiteEmployeeLeave>();
            SmSiteEmployeeLeaveRejectedByNavigation = new HashSet<SmSiteEmployeeLeave>();
            SmSiteEmployeeLeaveReviewedByNavigation = new HashSet<SmSiteEmployeeLeave>();
            SmTimeCardHourDetail = new HashSet<SmTimeCardHourDetail>();
            SmUserApproval = new HashSet<SmUserApproval>();
            SmUserResetHistory = new HashSet<SmUserResetHistory>();
            SmUserRightAddedByNavigation = new HashSet<SmUserRight>();
            SmUserRightUser = new HashSet<SmUserRight>();
            SmWorQaassessment = new HashSet<SmWorQaassessment>();
            SmWorkRequest = new HashSet<SmWorkRequest>();
        }

        public decimal UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? SectionId { get; set; }
        public decimal? LoginTryCount { get; set; }
        public string Admin { get; set; }
        public string DomainUserName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public string EncryptedPassword { get; set; }
        public bool? ChangePasswordFlag { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual ICollection<MUser> InverseAddedByNavigation { get; set; }
        public virtual ICollection<MActivity> MActivity { get; set; }
        public virtual ICollection<MAssetModel> MAssetModel { get; set; }
        public virtual ICollection<MAssetModelFixParam> MAssetModelFixParam { get; set; }
        public virtual ICollection<MDrug> MDrug { get; set; }
        public virtual ICollection<MEmployeeLeave> MEmployeeLeave { get; set; }
        public virtual ICollection<MEmployeeLeaveDate> MEmployeeLeaveDate { get; set; }
        public virtual ICollection<MEquipment> MEquipment { get; set; }
        public virtual ICollection<MEquipmentModel> MEquipmentModel { get; set; }
        public virtual ICollection<MOrderStatus> MOrderStatus { get; set; }
        public virtual ICollection<MPackage> MPackage { get; set; }
        public virtual ICollection<MPackageComp> MPackageComp { get; set; }
        public virtual ICollection<MPackageType> MPackageType { get; set; }
        public virtual ICollection<MPartyAddressType> MPartyAddressType { get; set; }
        public virtual ICollection<MPartyLocation> MPartyLocation { get; set; }
        public virtual ICollection<MProject> MProject { get; set; }
        public virtual ICollection<MSite> MSite { get; set; }
        public virtual ICollection<MSpecialUsers> MSpecialUsers { get; set; }
        public virtual ICollection<MStmtestSolution> MStmtestSolution { get; set; }
        public virtual ICollection<MUnitOperation> MUnitOperation { get; set; }
        public virtual ICollection<MUserRightsForEmail> MUserRightsForEmail { get; set; }
        public virtual ICollection<MVendorAddressTypeOld> MVendorAddressTypeOld { get; set; }
        public virtual ICollection<MVendorLicenseOld> MVendorLicenseOld { get; set; }
        public virtual ICollection<MVendorLocationOld> MVendorLocationOld { get; set; }
        public virtual ICollection<MVendorTaxOld> MVendorTaxOld { get; set; }
        public virtual ICollection<SSuggestion> SSuggestionAddedByNavigation { get; set; }
        public virtual ICollection<SSuggestion> SSuggestionSuggestionByNavigation { get; set; }
        public virtual ICollection<SmAssetReceival> SmAssetReceival { get; set; }
        public virtual ICollection<SmContract> SmContract { get; set; }
        public virtual ICollection<SmDepartmentActivity> SmDepartmentActivity { get; set; }
        public virtual ICollection<SmFormulaAsset> SmFormulaAsset { get; set; }
        public virtual ICollection<SmHodapproval> SmHodapproval { get; set; }
        public virtual ICollection<SmMaterialRequizition> SmMaterialRequizitionAddedByNavigation { get; set; }
        public virtual ICollection<SmMaterialRequizition> SmMaterialRequizitionRequizitionByNavigation { get; set; }
        public virtual ICollection<SmOmrsubProcessPending> SmOmrsubProcessPending { get; set; }
        public virtual ICollection<SmOverTime> SmOverTimeAddedByNavigation { get; set; }
        public virtual ICollection<SmOverTime> SmOverTimeDeptApprovedByNavigation { get; set; }
        public virtual ICollection<SmOverTime> SmOverTimeHrapprovedByNavigation { get; set; }
        public virtual ICollection<SmPackCompParameter> SmPackCompParameter { get; set; }
        public virtual ICollection<SmPartyLicense> SmPartyLicense { get; set; }
        public virtual ICollection<SmPartyTax> SmPartyTax { get; set; }
        public virtual ICollection<SmPmcycleStakeHolder> SmPmcycleStakeHolder { get; set; }
        public virtual ICollection<SmProductBom> SmProductBom { get; set; }
        public virtual ICollection<SmRawMaterialParty> SmRawMaterialParty { get; set; }
        public virtual ICollection<SmSalesOrderStatus> SmSalesOrderStatus { get; set; }
        public virtual ICollection<SmSiteEmployeeLeave> SmSiteEmployeeLeaveAddedByNavigation { get; set; }
        public virtual ICollection<SmSiteEmployeeLeave> SmSiteEmployeeLeaveApprovedByNavigation { get; set; }
        public virtual ICollection<SmSiteEmployeeLeave> SmSiteEmployeeLeaveRejectedByNavigation { get; set; }
        public virtual ICollection<SmSiteEmployeeLeave> SmSiteEmployeeLeaveReviewedByNavigation { get; set; }
        public virtual ICollection<SmTimeCardHourDetail> SmTimeCardHourDetail { get; set; }
        public virtual ICollection<SmUserApproval> SmUserApproval { get; set; }
        public virtual ICollection<SmUserResetHistory> SmUserResetHistory { get; set; }
        public virtual ICollection<SmUserRight> SmUserRightAddedByNavigation { get; set; }
        public virtual ICollection<SmUserRight> SmUserRightUser { get; set; }
        public virtual ICollection<SmWorQaassessment> SmWorQaassessment { get; set; }
        public virtual ICollection<SmWorkRequest> SmWorkRequest { get; set; }
    }
}
