﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmContractWork
    {
        public SmContractWork()
        {
            SmContractWorkApproval = new HashSet<SmContractWorkApproval>();
            SmContractWorkDocument = new HashSet<SmContractWorkDocument>();
        }

        public decimal ContractWorkId { get; set; }
        public decimal? PartyContactId { get; set; }
        public string WorkPerformed { get; set; }
        public string Duration { get; set; }
        public bool? DocumentRequiredFlag { get; set; }
        public decimal? DocRevId { get; set; }
        public bool? ControlledSubstanceFlag { get; set; }
        public string Description { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? EmployeeId { get; set; }
        public DateTime? ContractServiceDate { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MDepartment Department { get; set; }
        public virtual SmDocRevision DocRev { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual SmPartyContactAddressType PartyContact { get; set; }
        public virtual ICollection<SmContractWorkApproval> SmContractWorkApproval { get; set; }
        public virtual ICollection<SmContractWorkDocument> SmContractWorkDocument { get; set; }
    }
}
