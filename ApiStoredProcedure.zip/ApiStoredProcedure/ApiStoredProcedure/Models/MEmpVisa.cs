﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpVisa
    {
        public MEmpVisa()
        {
            SmEmpVisaDocument = new HashSet<SmEmpVisaDocument>();
            SmEmpVisaHistory = new HashSet<SmEmpVisaHistory>();
        }

        public decimal EmpVisaId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? EmpPassportId { get; set; }
        public decimal? VisaTypeId { get; set; }
        public string VisaNo { get; set; }
        public decimal? NoOfEntry { get; set; }
        public DateTime? IssuedDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public decimal? IssuedBy { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string Comment { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmpPassport EmpPassport { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual MCountry IssuedByNavigation { get; set; }
        public virtual MVisaType VisaType { get; set; }
        public virtual ICollection<SmEmpVisaDocument> SmEmpVisaDocument { get; set; }
        public virtual ICollection<SmEmpVisaHistory> SmEmpVisaHistory { get; set; }
    }
}
