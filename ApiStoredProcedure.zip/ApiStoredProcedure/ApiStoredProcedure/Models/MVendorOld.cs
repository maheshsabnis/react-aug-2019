﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MVendorOld
    {
        public MVendorOld()
        {
            MVendorLicenseOld = new HashSet<MVendorLicenseOld>();
            MVendorLocationOld = new HashSet<MVendorLocationOld>();
            MVendorTaxOld = new HashSet<MVendorTaxOld>();
            SmVendorCategoryDetailOld = new HashSet<SmVendorCategoryDetailOld>();
        }

        public decimal VendorId { get; set; }
        public string VendorName { get; set; }
        public string VendorCode { get; set; }
        public string VendorAccountNo { get; set; }
        public string Gpid { get; set; }
        public decimal? SubsidiaryOfId { get; set; }
        public double? CreditLimitUsd { get; set; }
        public decimal? CreditLimitDays { get; set; }
        public string Terms { get; set; }
        public string WebSite { get; set; }
        public string Email { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Type { get; set; }

        public virtual ICollection<MVendorLicenseOld> MVendorLicenseOld { get; set; }
        public virtual ICollection<MVendorLocationOld> MVendorLocationOld { get; set; }
        public virtual ICollection<MVendorTaxOld> MVendorTaxOld { get; set; }
        public virtual ICollection<SmVendorCategoryDetailOld> SmVendorCategoryDetailOld { get; set; }
    }
}
