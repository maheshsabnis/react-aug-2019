﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDeviationDocument
    {
        public decimal DeviationDocumentId { get; set; }
        public decimal? DeviationId { get; set; }
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }

        public virtual SmDeviation Deviation { get; set; }
    }
}
