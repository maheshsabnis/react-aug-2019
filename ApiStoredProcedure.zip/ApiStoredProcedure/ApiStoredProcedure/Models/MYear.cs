﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MYear
    {
        public MYear()
        {
            SmYearlyProjection = new HashSet<SmYearlyProjection>();
        }

        public decimal YearId { get; set; }
        public string Year { get; set; }
        public string Type { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmYearlyProjection> SmYearlyProjection { get; set; }
    }
}
