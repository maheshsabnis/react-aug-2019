﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdprojectTemplate
    {
        public SmEctdprojectTemplate()
        {
            SmECtdprojectApproverHistory = new HashSet<SmECtdprojectApproverHistory>();
        }

        public decimal EctdprojectId { get; set; }
        public decimal? TemplateId { get; set; }
        public decimal? ProjectId { get; set; }
        public string DataBaseName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ProjectApproverId { get; set; }
        public decimal? ProjectPublisherId { get; set; }
        public bool? SubmitFlag { get; set; }
        public decimal? SubmittedBy { get; set; }
        public string SubmittedSign { get; set; }
        public bool? SubmittedIncorrectPassword { get; set; }
        public DateTime? SubmittedByDateTime { get; set; }
        public bool? PublisherSubmitFlag { get; set; }
        public decimal? PublisherSubmittedBy { get; set; }
        public string PublisherSubmittedSign { get; set; }
        public bool? PublisherSubmittedIncorrectPassword { get; set; }
        public DateTime? PublisherSubmittedByDateTime { get; set; }
        public bool? ProjectApproverUploadFlag { get; set; }
        public bool? ProjectPublisherUploadFlag { get; set; }

        public virtual MProject Project { get; set; }
        public virtual MEmployee ProjectApprover { get; set; }
        public virtual MEmployee ProjectPublisher { get; set; }
        public virtual MEctdtemplate Template { get; set; }
        public virtual ICollection<SmECtdprojectApproverHistory> SmECtdprojectApproverHistory { get; set; }
    }
}
