﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampPkgBomdetail
    {
        public decimal CampPkgBomdetailId { get; set; }
        public decimal? CampPkgBomid { get; set; }
        public decimal? PackagingBomdetailId { get; set; }
        public double? Bom { get; set; }
        public double? BombySize { get; set; }

        public virtual SmCampPkgBom CampPkgBom { get; set; }
        public virtual SmPackagingBomdetail PackagingBomdetail { get; set; }
    }
}
