﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEquipment
    {
        public MEquipment()
        {
            MEquipmentModel = new HashSet<MEquipmentModel>();
            SmEquipmentUnitOpn = new HashSet<SmEquipmentUnitOpn>();
        }

        public decimal EquipmentId { get; set; }
        public string EquipmentName { get; set; }
        public decimal? EquipmentCategoryId { get; set; }
        public string EquipmentDesc { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MEquipmentCategory EquipmentCategory { get; set; }
        public virtual ICollection<MEquipmentModel> MEquipmentModel { get; set; }
        public virtual ICollection<SmEquipmentUnitOpn> SmEquipmentUnitOpn { get; set; }
    }
}
