﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmployeeRate
    {
        public SmEmployeeRate()
        {
            SmEmployeeRateDocument = new HashSet<SmEmployeeRateDocument>();
        }

        public decimal EmployeeRateId { get; set; }
        public decimal? EmployeeId { get; set; }
        public double? Rate { get; set; }
        public decimal? EmpTypeId { get; set; }
        public string PayType { get; set; }
        public string Comment { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual ICollection<SmEmployeeRateDocument> SmEmployeeRateDocument { get; set; }
    }
}
