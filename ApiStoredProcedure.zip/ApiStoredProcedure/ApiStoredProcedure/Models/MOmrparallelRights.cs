﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrparallelRights
    {
        public decimal OmrparallelRightsId { get; set; }
        public decimal? FromUserId { get; set; }
        public decimal? ToUserId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
