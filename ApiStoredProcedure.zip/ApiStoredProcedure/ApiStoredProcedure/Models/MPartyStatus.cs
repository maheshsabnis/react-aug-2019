﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPartyStatus
    {
        public MPartyStatus()
        {
            SmPartyCategoryDetail = new HashSet<SmPartyCategoryDetail>();
            SmThirteenDcodeReqPartyStatus = new HashSet<SmThirteenDcodeReq>();
            SmThirteenDcodeReqPartyStatusId1Navigation = new HashSet<SmThirteenDcodeReq>();
        }

        public decimal PartyStatusId { get; set; }
        public string PartyStatus { get; set; }
        public string StatusCode { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmPartyCategoryDetail> SmPartyCategoryDetail { get; set; }
        public virtual ICollection<SmThirteenDcodeReq> SmThirteenDcodeReqPartyStatus { get; set; }
        public virtual ICollection<SmThirteenDcodeReq> SmThirteenDcodeReqPartyStatusId1Navigation { get; set; }
    }
}
