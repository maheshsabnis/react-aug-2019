﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRow
    {
        public MRow()
        {
            MStorageLocation = new HashSet<MStorageLocation>();
        }

        public decimal RowId { get; set; }
        public decimal? AreaSiteId { get; set; }
        public decimal? MaterialStatusId { get; set; }
        public decimal? AreaId { get; set; }
        public string RowName { get; set; }
        public string RowCode { get; set; }
        public decimal? NoOfColumns { get; set; }
        public decimal? NoOfLevels { get; set; }
        public string Remark { get; set; }
        public decimal? ColumnStart { get; set; }
        public decimal? ColumnEnd { get; set; }
        public decimal? LevelStart { get; set; }
        public decimal? LevelEnd { get; set; }
        public bool? LtoR { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MArea Area { get; set; }
        public virtual ICollection<MStorageLocation> MStorageLocation { get; set; }
    }
}
