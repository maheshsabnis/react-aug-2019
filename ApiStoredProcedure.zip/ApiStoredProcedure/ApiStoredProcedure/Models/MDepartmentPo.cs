﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDepartmentPo
    {
        public decimal DepartmentPoid { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? NoofPo { get; set; }
        public double? Amount { get; set; }
        public double? TotalAmount { get; set; }
        public decimal? NoofPo1 { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
