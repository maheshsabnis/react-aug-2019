﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrapprovalFormforSubProcess
    {
        public decimal OmrApprovalFormId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public string FormName { get; set; }
        public string FormCaption { get; set; }
        public string MenuLinkName { get; set; }
        public string FormNameForInstance { get; set; }
        public string CategoryType { get; set; }
        public string NavigateUrl { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
