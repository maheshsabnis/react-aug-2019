﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmECtdprojectApproverHistory
    {
        public decimal ProjectApproverHistoryId { get; set; }
        public decimal? EctdprojectId { get; set; }
        public decimal? EmployeeId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Comment { get; set; }
        public decimal? EctdstakeHolderRoleId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmEctdprojectTemplate Ectdproject { get; set; }
        public virtual MEctdstakeHolderRole EctdstakeHolderRole { get; set; }
        public virtual MEmployee Employee { get; set; }
    }
}
