﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEquipmentModel
    {
        public decimal EquipmentModelId { get; set; }
        public string EquipmentModelName { get; set; }
        public decimal? EquipmentId { get; set; }
        public string Remark { get; set; }
        public decimal? AddedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MEquipment Equipment { get; set; }
    }
}
