﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDccrequestStatus
    {
        public decimal DccreqStatusId { get; set; }
        public decimal? DccrequestId { get; set; }
        public string Dccrequest { get; set; }
        public string ReqDeptApproval { get; set; }
        public string AssignTrackingNumber { get; set; }
        public string DocumentReceival { get; set; }
        public string DraftPrepare { get; set; }
        public string DraftDeptApproval { get; set; }
        public string Dccapproval { get; set; }
        public string Review { get; set; }
        public string AssignChangeControlNumber { get; set; }
        public string MakeEffective { get; set; }
        public string PendingAtFormName { get; set; }
        public string PendingAtPreviousStatus { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
    }
}
