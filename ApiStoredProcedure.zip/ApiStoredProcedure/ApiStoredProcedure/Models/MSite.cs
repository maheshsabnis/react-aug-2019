﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSite
    {
        public MSite()
        {
            MArea = new HashSet<MArea>();
            MSiteEmployee = new HashSet<MSiteEmployee>();
            SmAssetPurchaseOrder = new HashSet<SmAssetPurchaseOrder>();
            SmMaterialRequizition = new HashSet<SmMaterialRequizition>();
            SmPurchaseOrder = new HashSet<SmPurchaseOrder>();
            SmSiteAddressTypeDetail = new HashSet<SmSiteAddressTypeDetail>();
            SmSiteAddresswisePhoneDetails = new HashSet<SmSiteAddresswisePhoneDetails>();
            SmSiteApproval = new HashSet<SmSiteApproval>();
            SmSiteContact = new HashSet<SmSiteContact>();
        }

        public decimal SiteId { get; set; }
        public decimal? PermittedDomainId { get; set; }
        public string Site { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public decimal? StateId { get; set; }
        public string Zip { get; set; }
        public decimal? CountryId { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedAtSiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MCountry Country { get; set; }
        public virtual MPermittedDomain PermittedDomain { get; set; }
        public virtual MState State { get; set; }
        public virtual ICollection<MArea> MArea { get; set; }
        public virtual ICollection<MSiteEmployee> MSiteEmployee { get; set; }
        public virtual ICollection<SmAssetPurchaseOrder> SmAssetPurchaseOrder { get; set; }
        public virtual ICollection<SmMaterialRequizition> SmMaterialRequizition { get; set; }
        public virtual ICollection<SmPurchaseOrder> SmPurchaseOrder { get; set; }
        public virtual ICollection<SmSiteAddressTypeDetail> SmSiteAddressTypeDetail { get; set; }
        public virtual ICollection<SmSiteAddresswisePhoneDetails> SmSiteAddresswisePhoneDetails { get; set; }
        public virtual ICollection<SmSiteApproval> SmSiteApproval { get; set; }
        public virtual ICollection<SmSiteContact> SmSiteContact { get; set; }
    }
}
