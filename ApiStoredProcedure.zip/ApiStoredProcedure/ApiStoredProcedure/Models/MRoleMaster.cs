﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRoleMaster
    {
        public decimal RoleId { get; set; }
        public string Role { get; set; }
        public string LinkName { get; set; }
        public string Admin { get; set; }
        public string Gl { get; set; }
        public string Tc { get; set; }
        public string MenuType { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
