﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpPersonalDetail
    {
        public MEmpPersonalDetail()
        {
            SmEmpPersonalDetailDocument = new HashSet<SmEmpPersonalDetailDocument>();
        }

        public decimal EmpPersonalDetailId { get; set; }
        public decimal EmployeeId { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Gender { get; set; }
        public decimal? BloodGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual ICollection<SmEmpPersonalDetailDocument> SmEmpPersonalDetailDocument { get; set; }
    }
}
