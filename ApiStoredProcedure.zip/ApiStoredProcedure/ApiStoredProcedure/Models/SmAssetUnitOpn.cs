﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetUnitOpn
    {
        public decimal AssetUnitOpnId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? UnitOperationId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
