﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeCategory
    {
        public MEmployeeCategory()
        {
            MEmpCategory = new HashSet<MEmpCategory>();
        }

        public decimal EmployeeCategoryId { get; set; }
        public string EmployeeCategory { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<MEmpCategory> MEmpCategory { get; set; }
    }
}
