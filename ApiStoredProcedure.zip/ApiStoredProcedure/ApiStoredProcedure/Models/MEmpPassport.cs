﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpPassport
    {
        public MEmpPassport()
        {
            MEmpVisa = new HashSet<MEmpVisa>();
            SmEmpPassportDocument = new HashSet<SmEmpPassportDocument>();
            SmEmpPassportHistory = new HashSet<SmEmpPassportHistory>();
        }

        public decimal EmpPassportId { get; set; }
        public decimal? EmployeeId { get; set; }
        public string PassportNumber { get; set; }
        public DateTime? IssuedDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public decimal? IssuedBy { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string Comment { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual MCountry IssuedByNavigation { get; set; }
        public virtual ICollection<MEmpVisa> MEmpVisa { get; set; }
        public virtual ICollection<SmEmpPassportDocument> SmEmpPassportDocument { get; set; }
        public virtual ICollection<SmEmpPassportHistory> SmEmpPassportHistory { get; set; }
    }
}
