﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDeptInvolvedInRiskAssessment
    {
        public decimal DeptInvolvedinRiskAssessmentId { get; set; }
        public decimal? ImpactAssessmentId { get; set; }
        public decimal? DepartmentId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MDepartment Department { get; set; }
        public virtual SmImpactAssessment ImpactAssessment { get; set; }
    }
}
