﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MResourceList
    {
        public decimal ResourceId { get; set; }
        public decimal? ResourceTypeId { get; set; }
        public string ResourceName { get; set; }
        public decimal? ResourceParentId { get; set; }
        public string DeActivationFlag { get; set; }
    }
}
