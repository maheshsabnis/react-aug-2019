﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetSopapproval
    {
        public decimal AssetSopapprovalId { get; set; }
        public decimal? AssetModelId { get; set; }
        public string Remark { get; set; }
        public bool? ReviewFlag { get; set; }
        public bool? ApproveFlag { get; set; }
        public bool? RejectedFlag { get; set; }
        public bool? RecalledFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public string ApprovalSign { get; set; }
        public DateTime? ApprovedByDatetime { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
