﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MVProjectTemplate
    {
        public MVProjectTemplate()
        {
            SmVProjectPredecessorActivity = new HashSet<SmVProjectPredecessorActivity>();
            SmVProjectProjectTemplateDetails = new HashSet<SmVProjectProjectTemplateDetails>();
            SmVProjectTemplate = new HashSet<SmVProjectTemplate>();
            SmVProjectTemplateDetails = new HashSet<SmVProjectTemplateDetails>();
        }

        public decimal VProjectTemplateId { get; set; }
        public string VProjectTemplate { get; set; }
        public string Comment { get; set; }
        public bool? SubmitFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmVProjectPredecessorActivity> SmVProjectPredecessorActivity { get; set; }
        public virtual ICollection<SmVProjectProjectTemplateDetails> SmVProjectProjectTemplateDetails { get; set; }
        public virtual ICollection<SmVProjectTemplate> SmVProjectTemplate { get; set; }
        public virtual ICollection<SmVProjectTemplateDetails> SmVProjectTemplateDetails { get; set; }
    }
}
