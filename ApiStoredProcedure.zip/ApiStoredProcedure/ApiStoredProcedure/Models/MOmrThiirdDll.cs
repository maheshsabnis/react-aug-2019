﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrThiirdDll
    {
        public decimal OmrThirdDllid { get; set; }
        public string Dllname { get; set; }
        public byte[] DllFile { get; set; }
        public string Path { get; set; }
        public DateTime? UploadedDateTime { get; set; }
        public string UploadedBy { get; set; }
        public string Comments { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? UpdateDlldate { get; set; }
    }
}
