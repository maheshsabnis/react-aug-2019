﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrformControlType
    {
        public decimal FormControlTypeId { get; set; }
        public string FormControlType { get; set; }
        public string FormType { get; set; }
    }
}
