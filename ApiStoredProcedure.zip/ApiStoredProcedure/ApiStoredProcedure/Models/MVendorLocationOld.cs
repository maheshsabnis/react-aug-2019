﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MVendorLocationOld
    {
        public MVendorLocationOld()
        {
            SmVendorLocationAddressTypeOld = new HashSet<SmVendorLocationAddressTypeOld>();
        }

        public decimal VendorLocationId { get; set; }
        public decimal? VendorId { get; set; }
        public string VendorLocationCode { get; set; }
        public string VendorLocation { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public decimal StateId { get; set; }
        public string Zip { get; set; }
        public decimal? CountryId { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string WebSite { get; set; }
        public string Email { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MCountry Country { get; set; }
        public virtual MState State { get; set; }
        public virtual MVendorOld Vendor { get; set; }
        public virtual ICollection<SmVendorLocationAddressTypeOld> SmVendorLocationAddressTypeOld { get; set; }
    }
}
