﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRequestType
    {
        public decimal RequestTypeId { get; set; }
        public string RequestType { get; set; }
        public bool? MandatoryProjectFlag { get; set; }
        public decimal AddedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
