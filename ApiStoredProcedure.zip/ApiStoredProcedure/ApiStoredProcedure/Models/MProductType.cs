﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProductType
    {
        public MProductType()
        {
            MProductionProcess = new HashSet<MProductionProcess>();
            SmDMaterial = new HashSet<SmDMaterial>();
            SmDeviationDetail = new HashSet<SmDeviationDetail>();
            SmEventDetails = new HashSet<SmEventDetails>();
            SmProductTypeApproval = new HashSet<SmProductTypeApproval>();
            SmProductTypeHistory = new HashSet<SmProductTypeHistory>();
            SmQasample = new HashSet<SmQasample>();
        }

        public decimal ProductTypeId { get; set; }
        public string ProductType { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MProductionProcess> MProductionProcess { get; set; }
        public virtual ICollection<SmDMaterial> SmDMaterial { get; set; }
        public virtual ICollection<SmDeviationDetail> SmDeviationDetail { get; set; }
        public virtual ICollection<SmEventDetails> SmEventDetails { get; set; }
        public virtual ICollection<SmProductTypeApproval> SmProductTypeApproval { get; set; }
        public virtual ICollection<SmProductTypeHistory> SmProductTypeHistory { get; set; }
        public virtual ICollection<SmQasample> SmQasample { get; set; }
    }
}
