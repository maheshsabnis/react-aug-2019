﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctddocument
    {
        public SmEctddocument()
        {
            SmEctddocumentVersion = new HashSet<SmEctddocumentVersion>();
        }

        public decimal FileId { get; set; }
        public string FileName { get; set; }
        public byte[] Fle { get; set; }
        public string Type { get; set; }
        public decimal? EctdprojectTemplateDetailId { get; set; }
        public decimal? EctdstakeHolderId { get; set; }
        public decimal? CreatedBy { get; set; }
        public decimal? EctdstakeHolderRoleId { get; set; }
        public DateTime? CreationDate { get; set; }
        public string CheckSum { get; set; }
        public string LockFlag { get; set; }
        public bool? TransferFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public bool? DocumentDeleteFlag { get; set; }
        public bool? DocTemplateUsed { get; set; }

        public virtual SmEctdprojectTemplateDetails EctdprojectTemplateDetail { get; set; }
        public virtual SmEctdstakeHolder EctdstakeHolder { get; set; }
        public virtual ICollection<SmEctddocumentVersion> SmEctddocumentVersion { get; set; }
    }
}
