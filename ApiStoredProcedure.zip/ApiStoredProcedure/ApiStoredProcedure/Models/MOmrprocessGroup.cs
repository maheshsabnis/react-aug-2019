﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessGroup
    {
        public decimal OmrprocessGroupId { get; set; }
        public string GroupCode { get; set; }
        public decimal? OmrsubProcessId { get; set; }
    }
}
