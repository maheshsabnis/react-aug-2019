﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctduploadDirStructure
    {
        public SmEctduploadDirStructure()
        {
            SmEctduploadDirStructureDetail = new HashSet<SmEctduploadDirStructureDetail>();
        }

        public decimal UplooadDirStructureId { get; set; }
        public string Directory { get; set; }
        public decimal ParentDirectoryStructureId { get; set; }
        public decimal? VersionNo { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmEctduploadDirStructureDetail> SmEctduploadDirStructureDetail { get; set; }
    }
}
