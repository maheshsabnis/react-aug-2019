﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampaign
    {
        public SmCampaign()
        {
            SmCampIngrdsBom = new HashSet<SmCampIngrdsBom>();
            SmCampaignDetails = new HashSet<SmCampaignDetails>();
            SmMaterialRequizition = new HashSet<SmMaterialRequizition>();
        }

        public decimal CampaignId { get; set; }
        public string CampaignCode { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<SmCampIngrdsBom> SmCampIngrdsBom { get; set; }
        public virtual ICollection<SmCampaignDetails> SmCampaignDetails { get; set; }
        public virtual ICollection<SmMaterialRequizition> SmMaterialRequizition { get; set; }
    }
}
