﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MState
    {
        public MState()
        {
            MEmployeeAddress = new HashSet<MEmployeeAddress>();
            MPartyLocation = new HashSet<MPartyLocation>();
            MSite = new HashSet<MSite>();
            MVendorLocationOld = new HashSet<MVendorLocationOld>();
            SmComplaint = new HashSet<SmComplaint>();
        }

        public decimal StateId { get; set; }
        public decimal? CountryId { get; set; }
        public string State { get; set; }
        public string StateAbbr { get; set; }

        public virtual MCountry Country { get; set; }
        public virtual ICollection<MEmployeeAddress> MEmployeeAddress { get; set; }
        public virtual ICollection<MPartyLocation> MPartyLocation { get; set; }
        public virtual ICollection<MSite> MSite { get; set; }
        public virtual ICollection<MVendorLocationOld> MVendorLocationOld { get; set; }
        public virtual ICollection<SmComplaint> SmComplaint { get; set; }
    }
}
