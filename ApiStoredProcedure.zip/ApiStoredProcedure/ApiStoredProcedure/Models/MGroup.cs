﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MGroup
    {
        public decimal GroupId { get; set; }
        public string GroupName { get; set; }
        public decimal? ParentId { get; set; }
        public decimal? GroupLeader { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
