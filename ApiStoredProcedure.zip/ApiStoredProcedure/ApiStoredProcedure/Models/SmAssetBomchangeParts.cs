﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetBomchangeParts
    {
        public decimal AssetChangePartsId { get; set; }
        public decimal? AssetBomdetailId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? AssetModelId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
