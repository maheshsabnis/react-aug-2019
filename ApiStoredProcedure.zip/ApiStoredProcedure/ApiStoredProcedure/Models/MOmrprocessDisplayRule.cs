﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessDisplayRule
    {
        public decimal OmrprocessDisplayRuleId { get; set; }
        public string Field { get; set; }
        public string DisplayRule { get; set; }
        public string HiddenColumns { get; set; }
        public string ColumnWidth { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
