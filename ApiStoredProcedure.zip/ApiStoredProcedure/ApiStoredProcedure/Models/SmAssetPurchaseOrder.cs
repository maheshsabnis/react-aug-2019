﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetPurchaseOrder
    {
        public SmAssetPurchaseOrder()
        {
            SmAssetPoterms = new HashSet<SmAssetPoterms>();
            SmAssetPurchaseOrderDetail = new HashSet<SmAssetPurchaseOrderDetail>();
        }

        public decimal AssetPurchaseOrderId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string PurchaseOrderNo { get; set; }
        public decimal? AssetRequisitonId { get; set; }
        public decimal? SupplierId { get; set; }
        public decimal? SupplierContactId { get; set; }
        public DateTime? OrderDate { get; set; }
        public decimal? PurchaseManId { get; set; }
        public decimal? BillToLocationId { get; set; }
        public decimal? BillToContactId { get; set; }
        public decimal? ShipToSiteId { get; set; }
        public decimal? ShipToSiteContactId { get; set; }
        public decimal? ShipToLocationId { get; set; }
        public decimal? ShipToContactId { get; set; }
        public decimal? BrokerCategoryDetailId { get; set; }
        public double? Brokerage { get; set; }
        public string Terms { get; set; }
        public decimal? TermsBePaidInDays { get; set; }
        public decimal? TermsDiscIfPaidInDays { get; set; }
        public double? TermsDiscount { get; set; }
        public decimal? CarrierCategoryDetailId { get; set; }
        public decimal? SiteWarehouseContactId { get; set; }
        public decimal? OtherWarehouseContactId { get; set; }
        public string WarehouseContactPhone { get; set; }
        public string ReceivingHours { get; set; }
        public bool? TaxExempt { get; set; }
        public string TaxDistrict { get; set; }
        public string Fob { get; set; }
        public decimal? PurchaseOrderBy { get; set; }
        public string PurchaseOrderBySign { get; set; }
        public bool? PoincorrectPassword { get; set; }
        public DateTime? PurchaseOrderByDatetime { get; set; }
        public string Remark { get; set; }
        public string LockFlag { get; set; }
        public bool? PocancelFlag { get; set; }
        public decimal? PocanceledBy { get; set; }
        public string PocanceledByRemark { get; set; }
        public DateTime? PocanceledByDateTime { get; set; }
        public bool? PocloseFlag { get; set; }
        public decimal? PoclosedBy { get; set; }
        public string PoclosedByRemark { get; set; }
        public DateTime? PoclosedByDateTime { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Reference { get; set; }
        public DateTime? RefDate { get; set; }
        public double? Tax { get; set; }
        public bool? PotaxFlag { get; set; }
        public decimal? LeaseBillToVendorId { get; set; }
        public decimal? LeaseBillToLocationId { get; set; }
        public decimal? LeaseBillToContactId { get; set; }
        public bool? LeaseFlag { get; set; }
        public string LeaseLockFlag { get; set; }
        public string LeaseReference { get; set; }
        public DateTime? LeaseRefDate { get; set; }

        public virtual SmSiteContact BillToContact { get; set; }
        public virtual SmSiteAddressTypeDetail BillToLocation { get; set; }
        public virtual MDocType DocType { get; set; }
        public virtual SmVendorLocationContactOld ShipToContact { get; set; }
        public virtual SmVendorLocationAddressTypeOld ShipToLocation { get; set; }
        public virtual MSite ShipToSite { get; set; }
        public virtual SmSiteContact ShipToSiteContact { get; set; }
        public virtual SmVendorCategoryDetailOld Supplier { get; set; }
        public virtual SmVendorLocationContactOld SupplierContact { get; set; }
        public virtual ICollection<SmAssetPoterms> SmAssetPoterms { get; set; }
        public virtual ICollection<SmAssetPurchaseOrderDetail> SmAssetPurchaseOrderDetail { get; set; }
    }
}
