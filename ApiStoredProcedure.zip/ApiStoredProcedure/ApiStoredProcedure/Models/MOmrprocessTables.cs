﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessTables
    {
        public decimal OmrprocessTableId { get; set; }
        public decimal? OmrprocessId { get; set; }
        public string TableName { get; set; }
    }
}
