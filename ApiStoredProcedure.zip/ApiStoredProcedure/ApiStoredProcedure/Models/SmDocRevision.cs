﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDocRevision
    {
        public SmDocRevision()
        {
            SmAssetSop = new HashSet<SmAssetSop>();
            SmContractWork = new HashSet<SmContractWork>();
            SmDccreferenceDocumentDetail = new HashSet<SmDccreferenceDocumentDetail>();
            SmJobTitleRequisitesCmdocument = new HashSet<SmJobTitleRequisitesCmdocument>();
            SmPmcycle = new HashSet<SmPmcycle>();
            SmStandardTestMethod = new HashSet<SmStandardTestMethod>();
            SmStmtestDetail = new HashSet<SmStmtestDetail>();
            SmStmtestTemplateSpecification = new HashSet<SmStmtestTemplateSpecification>();
            SmTrainingCourseOtherDocument = new HashSet<SmTrainingCourseOtherDocument>();
            SmTrainingEventCmdocument = new HashSet<SmTrainingEventCmdocument>();
            SmTrnClassDetail = new HashSet<SmTrnClassDetail>();
        }

        public decimal DocRevId { get; set; }
        public decimal? DocumentId { get; set; }
        public string NewRev { get; set; }
        public string OldRev { get; set; }
        public decimal? DocStatusId { get; set; }
        public DateTime? DateEffective { get; set; }
        public string RecertReq { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? DccrequestId { get; set; }
        public string TrackingNo { get; set; }
        public bool? SubmitFlag { get; set; }
        public decimal? SubmittedBy { get; set; }
        public string SubmittedSign { get; set; }
        public bool? SubmittedIncorrectPassword { get; set; }
        public DateTime? SubmittedByDateTime { get; set; }
        public bool? IsAnnexureavailable { get; set; }
        public bool? DocReviewFlag { get; set; }
        public decimal? DocReviewedBy { get; set; }
        public DateTime? DocReviewedByDateTime { get; set; }
        public bool? DocReceiveFlag { get; set; }
        public decimal? DocReceivedBy { get; set; }
        public DateTime? DocReceivedByDateTime { get; set; }
        public string ReceivalComment { get; set; }
        public DateTime? ReceivalDate { get; set; }
        public bool? DocPrepareSubmitFlag { get; set; }
        public bool? ReSubmitFlag { get; set; }
        public string DocPrepareSubmittedSign { get; set; }
        public bool? DocPrepareSubmittedIncorrectPassword { get; set; }
        public decimal? DocPrepareSubmittedBy { get; set; }
        public DateTime? DocPrepareSubmittedByDateTime { get; set; }
        public bool? DeptReviewFlag { get; set; }
        public decimal? DeptReviewedBy { get; set; }
        public string DeptReviewedSign { get; set; }
        public bool? DeptReviewedIncorrectPassword { get; set; }
        public DateTime? DeptReviewedByDateTime { get; set; }
        public bool? DeptApproveFlag { get; set; }
        public decimal? DeptApprovedBy { get; set; }
        public string DeptApprovedSign { get; set; }
        public bool? DeptApproveIncorrectPassword { get; set; }
        public DateTime? DeptApprovedByDatetime { get; set; }
        public string DeptApprovedByRemark { get; set; }
        public bool? ReDocPrepareSubmitFlag { get; set; }
        public bool? DccapproveFlag { get; set; }
        public decimal? DccapprovedBy { get; set; }
        public string DccapprovedSign { get; set; }
        public bool? DccapproveIncorrectPassword { get; set; }
        public DateTime? DccapprovedByDatetime { get; set; }
        public string ChangeControlNo { get; set; }
        public bool? ChangeControlSubmitFlag { get; set; }
        public decimal? ChangeControlSubmitedBy { get; set; }
        public string ChangeControlSubmitedSign { get; set; }
        public bool? ChangeControlSubmitIncorrectPassword { get; set; }
        public DateTime? ChangeControlSubmitedByDatetime { get; set; }
        public DateTime? AssignedDate { get; set; }
        public bool? DocEffectiveSubmitFlag { get; set; }
        public decimal? DocEffectiveSubmitedBy { get; set; }
        public string DocEffectiveSubmitedSign { get; set; }
        public bool? DocEffectiveSubmitIncorrectPassword { get; set; }
        public DateTime? DocEffectiveSubmitedByDatetime { get; set; }
        public decimal? PrevDocRevId { get; set; }
        public bool? ReviewerVersionFlag { get; set; }

        public virtual MDccrequest Dccrequest { get; set; }
        public virtual MDocStatus DocStatus { get; set; }
        public virtual MDocument Document { get; set; }
        public virtual MDccreferenceDocument MDccreferenceDocument { get; set; }
        public virtual ICollection<SmAssetSop> SmAssetSop { get; set; }
        public virtual ICollection<SmContractWork> SmContractWork { get; set; }
        public virtual ICollection<SmDccreferenceDocumentDetail> SmDccreferenceDocumentDetail { get; set; }
        public virtual ICollection<SmJobTitleRequisitesCmdocument> SmJobTitleRequisitesCmdocument { get; set; }
        public virtual ICollection<SmPmcycle> SmPmcycle { get; set; }
        public virtual ICollection<SmStandardTestMethod> SmStandardTestMethod { get; set; }
        public virtual ICollection<SmStmtestDetail> SmStmtestDetail { get; set; }
        public virtual ICollection<SmStmtestTemplateSpecification> SmStmtestTemplateSpecification { get; set; }
        public virtual ICollection<SmTrainingCourseOtherDocument> SmTrainingCourseOtherDocument { get; set; }
        public virtual ICollection<SmTrainingEventCmdocument> SmTrainingEventCmdocument { get; set; }
        public virtual ICollection<SmTrnClassDetail> SmTrnClassDetail { get; set; }
    }
}
