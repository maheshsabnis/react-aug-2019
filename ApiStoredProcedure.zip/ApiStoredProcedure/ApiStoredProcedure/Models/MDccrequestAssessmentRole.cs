﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDccrequestAssessmentRole
    {
        public MDccrequestAssessmentRole()
        {
            SmDcccompletionDateHistory = new HashSet<SmDcccompletionDateHistory>();
            SmDccrequestAssessmentDetail = new HashSet<SmDccrequestAssessmentDetail>();
            SmDocRevApproval = new HashSet<SmDocRevApproval>();
            SmDocRevApprovalHistory = new HashSet<SmDocRevApprovalHistory>();
        }

        public decimal DccstakeHolderRoleId { get; set; }
        public string Role { get; set; }
        public bool? AssessmentFlag { get; set; }
        public bool? RoleFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual ICollection<SmDcccompletionDateHistory> SmDcccompletionDateHistory { get; set; }
        public virtual ICollection<SmDccrequestAssessmentDetail> SmDccrequestAssessmentDetail { get; set; }
        public virtual ICollection<SmDocRevApproval> SmDocRevApproval { get; set; }
        public virtual ICollection<SmDocRevApprovalHistory> SmDocRevApprovalHistory { get; set; }
    }
}
