﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAbsenceRequestDocument
    {
        public decimal AbsenceRequestDocId { get; set; }
        public decimal? AbsenceRequestId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MAbsenceRequest AbsenceRequest { get; set; }
    }
}
