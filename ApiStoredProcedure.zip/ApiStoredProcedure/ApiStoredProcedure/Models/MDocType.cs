﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDocType
    {
        public MDocType()
        {
            MOmrsubProcessDocType = new HashSet<MOmrsubProcessDocType>();
            MOrderStatus = new HashSet<MOrderStatus>();
            SmAssetDocument = new HashSet<SmAssetDocument>();
            SmAssetModelDocument = new HashSet<SmAssetModelDocument>();
            SmAssetPurchaseOrder = new HashSet<SmAssetPurchaseOrder>();
            SmBomversionDocument = new HashSet<SmBomversionDocument>();
            SmDocTypeApproval = new HashSet<SmDocTypeApproval>();
            SmEmpCategoryDocument = new HashSet<SmEmpCategoryDocument>();
            SmEmpCertificationDocument = new HashSet<SmEmpCertificationDocument>();
            SmEmpDependentsDocument = new HashSet<SmEmpDependentsDocument>();
            SmEmpDocument = new HashSet<SmEmpDocument>();
            SmEmpEducationDocument = new HashSet<SmEmpEducationDocument>();
            SmEmpLanguageDetailDocument = new HashSet<SmEmpLanguageDetailDocument>();
            SmEmpMaritalStatusDocument = new HashSet<SmEmpMaritalStatusDocument>();
            SmEmpMembershipDocument = new HashSet<SmEmpMembershipDocument>();
            SmEmpNameDocument = new HashSet<SmEmpNameDocument>();
            SmEmpPassportDocument = new HashSet<SmEmpPassportDocument>();
            SmEmpPersonalDetailDocument = new HashSet<SmEmpPersonalDetailDocument>();
            SmEmpPersonalReferenceNumberDocument = new HashSet<SmEmpPersonalReferenceNumberDocument>();
            SmEmpSkillDocument = new HashSet<SmEmpSkillDocument>();
            SmEmpTypeDocument = new HashSet<SmEmpTypeDocument>();
            SmEmpVisaDocument = new HashSet<SmEmpVisaDocument>();
            SmEmployeeDeptDocument = new HashSet<SmEmployeeDeptDocument>();
            SmEmployeeDesigDocument = new HashSet<SmEmployeeDesigDocument>();
            SmEmployeePhoneDocument = new HashSet<SmEmployeePhoneDocument>();
            SmHoddocument = new HashSet<SmHoddocument>();
            SmMrtoWareHouseDocument = new HashSet<SmMrtoWareHouseDocument>();
            SmProductDocument = new HashSet<SmProductDocument>();
            SmProductFamilyDocument = new HashSet<SmProductFamilyDocument>();
            SmProductionProcessVersionDetailDocument = new HashSet<SmProductionProcessVersionDetailDocument>();
            SmPurchaseOrder = new HashSet<SmPurchaseOrder>();
            SmRawMaterialIssuedDocument = new HashSet<SmRawMaterialIssuedDocument>();
            SmSalesOrder = new HashSet<SmSalesOrder>();
            SmSiteEmployeeDocument = new HashSet<SmSiteEmployeeDocument>();
            SmSolutionPreparationAssetDocument = new HashSet<SmSolutionPreparationAssetDocument>();
            SmSolutionPreparationDocument = new HashSet<SmSolutionPreparationDocument>();
            SmStmdocument = new HashSet<SmStmdocument>();
            SmTestCompletionDocument = new HashSet<SmTestCompletionDocument>();
            SmTestDocumentW = new HashSet<SmTestDocumentW>();
            SmTestExecutionAssetDocument = new HashSet<SmTestExecutionAssetDocument>();
            SmTestExecutionDocument = new HashSet<SmTestExecutionDocument>();
            SmTrnClassEmpDocument = new HashSet<SmTrnClassEmpDocument>();
            SmTrnTrxnDocument = new HashSet<SmTrnTrxnDocument>();
            SmWeighLabelDocument = new HashSet<SmWeighLabelDocument>();
        }

        public decimal DocTypeId { get; set; }
        public string DocType { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MOmrsubProcessDocType> MOmrsubProcessDocType { get; set; }
        public virtual ICollection<MOrderStatus> MOrderStatus { get; set; }
        public virtual ICollection<SmAssetDocument> SmAssetDocument { get; set; }
        public virtual ICollection<SmAssetModelDocument> SmAssetModelDocument { get; set; }
        public virtual ICollection<SmAssetPurchaseOrder> SmAssetPurchaseOrder { get; set; }
        public virtual ICollection<SmBomversionDocument> SmBomversionDocument { get; set; }
        public virtual ICollection<SmDocTypeApproval> SmDocTypeApproval { get; set; }
        public virtual ICollection<SmEmpCategoryDocument> SmEmpCategoryDocument { get; set; }
        public virtual ICollection<SmEmpCertificationDocument> SmEmpCertificationDocument { get; set; }
        public virtual ICollection<SmEmpDependentsDocument> SmEmpDependentsDocument { get; set; }
        public virtual ICollection<SmEmpDocument> SmEmpDocument { get; set; }
        public virtual ICollection<SmEmpEducationDocument> SmEmpEducationDocument { get; set; }
        public virtual ICollection<SmEmpLanguageDetailDocument> SmEmpLanguageDetailDocument { get; set; }
        public virtual ICollection<SmEmpMaritalStatusDocument> SmEmpMaritalStatusDocument { get; set; }
        public virtual ICollection<SmEmpMembershipDocument> SmEmpMembershipDocument { get; set; }
        public virtual ICollection<SmEmpNameDocument> SmEmpNameDocument { get; set; }
        public virtual ICollection<SmEmpPassportDocument> SmEmpPassportDocument { get; set; }
        public virtual ICollection<SmEmpPersonalDetailDocument> SmEmpPersonalDetailDocument { get; set; }
        public virtual ICollection<SmEmpPersonalReferenceNumberDocument> SmEmpPersonalReferenceNumberDocument { get; set; }
        public virtual ICollection<SmEmpSkillDocument> SmEmpSkillDocument { get; set; }
        public virtual ICollection<SmEmpTypeDocument> SmEmpTypeDocument { get; set; }
        public virtual ICollection<SmEmpVisaDocument> SmEmpVisaDocument { get; set; }
        public virtual ICollection<SmEmployeeDeptDocument> SmEmployeeDeptDocument { get; set; }
        public virtual ICollection<SmEmployeeDesigDocument> SmEmployeeDesigDocument { get; set; }
        public virtual ICollection<SmEmployeePhoneDocument> SmEmployeePhoneDocument { get; set; }
        public virtual ICollection<SmHoddocument> SmHoddocument { get; set; }
        public virtual ICollection<SmMrtoWareHouseDocument> SmMrtoWareHouseDocument { get; set; }
        public virtual ICollection<SmProductDocument> SmProductDocument { get; set; }
        public virtual ICollection<SmProductFamilyDocument> SmProductFamilyDocument { get; set; }
        public virtual ICollection<SmProductionProcessVersionDetailDocument> SmProductionProcessVersionDetailDocument { get; set; }
        public virtual ICollection<SmPurchaseOrder> SmPurchaseOrder { get; set; }
        public virtual ICollection<SmRawMaterialIssuedDocument> SmRawMaterialIssuedDocument { get; set; }
        public virtual ICollection<SmSalesOrder> SmSalesOrder { get; set; }
        public virtual ICollection<SmSiteEmployeeDocument> SmSiteEmployeeDocument { get; set; }
        public virtual ICollection<SmSolutionPreparationAssetDocument> SmSolutionPreparationAssetDocument { get; set; }
        public virtual ICollection<SmSolutionPreparationDocument> SmSolutionPreparationDocument { get; set; }
        public virtual ICollection<SmStmdocument> SmStmdocument { get; set; }
        public virtual ICollection<SmTestCompletionDocument> SmTestCompletionDocument { get; set; }
        public virtual ICollection<SmTestDocumentW> SmTestDocumentW { get; set; }
        public virtual ICollection<SmTestExecutionAssetDocument> SmTestExecutionAssetDocument { get; set; }
        public virtual ICollection<SmTestExecutionDocument> SmTestExecutionDocument { get; set; }
        public virtual ICollection<SmTrnClassEmpDocument> SmTrnClassEmpDocument { get; set; }
        public virtual ICollection<SmTrnTrxnDocument> SmTrnTrxnDocument { get; set; }
        public virtual ICollection<SmWeighLabelDocument> SmWeighLabelDocument { get; set; }
    }
}
