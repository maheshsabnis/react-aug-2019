﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdfiles
    {
        public decimal EctdfilesId { get; set; }
        public decimal? EctdstakeHolderId { get; set; }
        public string FileName { get; set; }
        public byte[] Content { get; set; }
        public string Sequence { get; set; }
        public string CheckSum { get; set; }
        public string LockFlag { get; set; }
        public string Comment { get; set; }
        public string FileTagName { get; set; }
        public string DisplayName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmEctdstakeHolder EctdstakeHolder { get; set; }
    }
}
