﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetReceival
    {
        public SmAssetReceival()
        {
            SmAssetNoDetail = new HashSet<SmAssetNoDetail>();
            SmAssetReceivalApproval = new HashSet<SmAssetReceivalApproval>();
            SmAssetReceivalDetails = new HashSet<SmAssetReceivalDetails>();
            SmRawMaterialInvoiceDetails = new HashSet<SmRawMaterialInvoiceDetails>();
        }

        public decimal AssetReceivalId { get; set; }
        public decimal? Grnid { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? AssetModelId { get; set; }
        public decimal? PodetailId { get; set; }
        public string InvoiceNo { get; set; }
        public string PackingListNo { get; set; }
        public decimal? SupplierId { get; set; }
        public decimal? ManufacturerId { get; set; }
        public decimal? CarrierId { get; set; }
        public double? Quantity { get; set; }
        public decimal? UnitId { get; set; }
        public decimal? Sets { get; set; }
        public bool? Mmyyformat { get; set; }
        public DateTime? MfgDate { get; set; }
        public string Currency { get; set; }
        public double? Rate { get; set; }
        public double? Custom { get; set; }
        public double? EntryTax { get; set; }
        public double? OtherCharges { get; set; }
        public string FreightBillNo { get; set; }
        public DateTime? FreightBillDate { get; set; }
        public string ReceivingNo { get; set; }
        public decimal? ReceivedBy { get; set; }
        public DateTime? ReceivalDateTime { get; set; }
        public string Remark { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public bool? ShowInInvoice { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MAsset Asset { get; set; }
        public virtual MAssetModel AssetModel { get; set; }
        public virtual MUnit Unit { get; set; }
        public virtual ICollection<SmAssetNoDetail> SmAssetNoDetail { get; set; }
        public virtual ICollection<SmAssetReceivalApproval> SmAssetReceivalApproval { get; set; }
        public virtual ICollection<SmAssetReceivalDetails> SmAssetReceivalDetails { get; set; }
        public virtual ICollection<SmRawMaterialInvoiceDetails> SmRawMaterialInvoiceDetails { get; set; }
    }
}
