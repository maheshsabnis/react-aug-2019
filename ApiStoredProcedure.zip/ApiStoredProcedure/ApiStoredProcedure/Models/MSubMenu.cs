﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSubMenu
    {
        public MSubMenu()
        {
            MSpecialUsers = new HashSet<MSpecialUsers>();
            SmUserRight = new HashSet<SmUserRight>();
        }

        public decimal SubMenuId { get; set; }
        public decimal? MenuId { get; set; }
        public decimal? ParentSubMenuId { get; set; }
        public string SubMenuName { get; set; }
        public string MenuLinkName { get; set; }
        public bool? WebFlag { get; set; }
        public string NavigateUrl { get; set; }
        public string FormName { get; set; }
        public string FormCaption { get; set; }
        public bool? DefaultRights { get; set; }
        public bool? InchargeHoDdefaultRights { get; set; }
        public string SubMenuFor { get; set; }
        public decimal? ModuleId { get; set; }
        public decimal? DisplayOrder { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public bool? ShowInAdminPanel { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MMenu Menu { get; set; }
        public virtual ICollection<MSpecialUsers> MSpecialUsers { get; set; }
        public virtual ICollection<SmUserRight> SmUserRight { get; set; }
    }
}
