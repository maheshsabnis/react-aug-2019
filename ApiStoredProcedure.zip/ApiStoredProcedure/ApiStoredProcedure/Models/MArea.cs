﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MArea
    {
        public MArea()
        {
            MRow = new HashSet<MRow>();
            SmAreaApproval = new HashSet<SmAreaApproval>();
            SmAreaDocuments = new HashSet<SmAreaDocuments>();
            SmPickingTicketContainerDetail = new HashSet<SmPickingTicketContainerDetail>();
            SmPickingTicketLocationDetail = new HashSet<SmPickingTicketLocationDetail>();
        }

        public decimal AreaId { get; set; }
        public decimal? AreaSiteId { get; set; }
        public decimal? MaterialStatusId { get; set; }
        public string AreaName { get; set; }
        public string AreaCode { get; set; }
        public string RowStart { get; set; }
        public string RowEnd { get; set; }
        public decimal? ColumnStart { get; set; }
        public decimal? ColumnEnd { get; set; }
        public decimal? LevelStart { get; set; }
        public decimal? LevelEnd { get; set; }
        public decimal? BinStart { get; set; }
        public decimal? BinEnd { get; set; }
        public string Remark { get; set; }
        public bool? DefaultRecArea { get; set; }
        public bool? UnRackedArea { get; set; }
        public bool? AsymmetricArea { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MSite AreaSite { get; set; }
        public virtual MMaterialStatus MaterialStatus { get; set; }
        public virtual ICollection<MRow> MRow { get; set; }
        public virtual ICollection<SmAreaApproval> SmAreaApproval { get; set; }
        public virtual ICollection<SmAreaDocuments> SmAreaDocuments { get; set; }
        public virtual ICollection<SmPickingTicketContainerDetail> SmPickingTicketContainerDetail { get; set; }
        public virtual ICollection<SmPickingTicketLocationDetail> SmPickingTicketLocationDetail { get; set; }
    }
}
