﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdprojectDetail
    {
        public SmEctdprojectDetail()
        {
            SmEctdfileApproval = new HashSet<SmEctdfileApproval>();
            SmEctdstakeHolder = new HashSet<SmEctdstakeHolder>();
        }

        public decimal EctdprojectDetailId { get; set; }
        public decimal? ProjectId { get; set; }
        public decimal? TemplateId { get; set; }
        public decimal? FolderId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmEctdfileApproval> SmEctdfileApproval { get; set; }
        public virtual ICollection<SmEctdstakeHolder> SmEctdstakeHolder { get; set; }
    }
}
