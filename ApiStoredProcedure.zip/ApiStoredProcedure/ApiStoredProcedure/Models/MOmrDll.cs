﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrDll
    {
        public decimal OmrDllid { get; set; }
        public string MajorVersionNo { get; set; }
        public string MinorVersionNo { get; set; }
        public string Dllname { get; set; }
        public byte[] DllFile { get; set; }
        public DateTime? UploadedDateTime { get; set; }
        public string UploadedBy { get; set; }
        public string Comments { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
