﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetPurchaseOrderDetail
    {
        public SmAssetPurchaseOrderDetail()
        {
            SmAssetPoexpectedDetail = new HashSet<SmAssetPoexpectedDetail>();
            SmAssetPurchaseOrderDetailHistory = new HashSet<SmAssetPurchaseOrderDetailHistory>();
        }

        public decimal AssetPurchaseOrderDetailId { get; set; }
        public decimal? AssetPurchaseOrderId { get; set; }
        public decimal? AssetRequisitionId { get; set; }
        public decimal? AssetRequisitionDetailId { get; set; }
        public decimal? AssetRequisitionApprovalId { get; set; }
        public decimal? AssetModelId { get; set; }
        public double? Quantity { get; set; }
        public decimal? UnitId { get; set; }
        public double? PricePerUnit { get; set; }
        public double? Discount { get; set; }
        public DateTime? NeedByDate { get; set; }
        public DateTime? ExpectedShipDate { get; set; }
        public decimal? ShipFromSiteId { get; set; }
        public decimal? ShipToLocationId { get; set; }
        public decimal? ShipToContactId { get; set; }
        public bool? PocancelFlag { get; set; }
        public decimal? PocanceledBy { get; set; }
        public string PocanceledByRemark { get; set; }
        public DateTime? PocanceledByDateTime { get; set; }
        public string Remark { get; set; }
        public bool? DirectPo { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? CurrencyId1 { get; set; }
        public decimal? CurrencyId2 { get; set; }
        public double? CurReferenceRate { get; set; }
        public DateTime? CurReferenceRateDate { get; set; }
        public decimal? PurchaseOrderId { get; set; }
        public double? ReceivedQty { get; set; }
        public double? PendingQty { get; set; }
        public decimal? PocancelId { get; set; }
        public string CatalogueNo { get; set; }
        public string Specifications { get; set; }

        public virtual MAssetModel AssetModel { get; set; }
        public virtual SmAssetPurchaseOrder AssetPurchaseOrder { get; set; }
        public virtual SmAssetRequisitionApproval AssetRequisitionApproval { get; set; }
        public virtual SmAssetRequisitionDetail AssetRequisitionDetail { get; set; }
        public virtual SmPurchaseOrder PurchaseOrder { get; set; }
        public virtual SmSiteAddressTypeDetail ShipToLocation { get; set; }
        public virtual MUnit Unit { get; set; }
        public virtual ICollection<SmAssetPoexpectedDetail> SmAssetPoexpectedDetail { get; set; }
        public virtual ICollection<SmAssetPurchaseOrderDetailHistory> SmAssetPurchaseOrderDetailHistory { get; set; }
    }
}
