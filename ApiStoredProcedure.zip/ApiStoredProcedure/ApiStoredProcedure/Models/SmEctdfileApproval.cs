﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdfileApproval
    {
        public decimal EctdfileApprovalId { get; set; }
        public decimal? EctdstakeHolderId { get; set; }
        public decimal? EctdprojectDetailId { get; set; }
        public decimal? PreviousApprovalId { get; set; }
        public bool? ReviewFlag { get; set; }
        public decimal? ReviewedBy { get; set; }
        public string ReviewedSign { get; set; }
        public bool? ReviewedIncorrectPassword { get; set; }
        public DateTime? ReviewedByDateTime { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public string ApprovedSign { get; set; }
        public bool? ApproveIncorrectPassword { get; set; }
        public DateTime? ApprovedByDatetime { get; set; }
        public string ApprovedByRemark { get; set; }
        public bool? RejectedFlag { get; set; }
        public decimal? RejectedBy { get; set; }
        public string RejectedSign { get; set; }
        public bool? RejectedIncorrectPassword { get; set; }
        public DateTime? RejectedByDateTime { get; set; }
        public bool? ReReviewFlag { get; set; }
        public bool? UpdateFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmEctdprojectDetail EctdprojectDetail { get; set; }
        public virtual SmEctdstakeHolder EctdstakeHolder { get; set; }
    }
}
