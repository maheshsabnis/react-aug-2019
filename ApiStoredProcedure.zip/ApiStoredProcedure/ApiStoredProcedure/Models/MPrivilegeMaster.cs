﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPrivilegeMaster
    {
        public decimal PrivilegeId { get; set; }
        public string PrivilegeName { get; set; }
        public string DeActivationFlag { get; set; }
    }
}
