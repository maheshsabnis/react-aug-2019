﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBomversionAsset
    {
        public SmBomversionAsset()
        {
            SmBomversionAssetPart = new HashSet<SmBomversionAssetPart>();
        }

        public decimal BomversionAssetId { get; set; }
        public decimal? BomversionId { get; set; }
        public decimal? AssetId { get; set; }
        public decimal AssetModelId { get; set; }
        public decimal? Quantity { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MAsset Asset { get; set; }
        public virtual MAssetModel AssetModel { get; set; }
        public virtual SmBomversion Bomversion { get; set; }
        public virtual ICollection<SmBomversionAssetPart> SmBomversionAssetPart { get; set; }
    }
}
