﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDccfileOpenStatus
    {
        public decimal DccfileOpenStatusId { get; set; }
        public decimal? DccdocRevId { get; set; }
        public string FileName { get; set; }
        public string FileOpenMode { get; set; }
        public DateTime? FileOpenTime { get; set; }
        public DateTime? FileCloseTime { get; set; }
        public decimal? UserId { get; set; }
    }
}
