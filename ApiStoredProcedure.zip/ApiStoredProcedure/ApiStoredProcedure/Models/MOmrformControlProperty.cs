﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrformControlProperty
    {
        public decimal FormControlPropertyId { get; set; }
        public decimal? FormControlTypeId { get; set; }
        public string PropertyName { get; set; }
    }
}
