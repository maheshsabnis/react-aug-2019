﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAbsenceRequest
    {
        public MAbsenceRequest()
        {
            MClosedAbsenceRequest = new HashSet<MClosedAbsenceRequest>();
            SmAbsenceRequestApproval = new HashSet<SmAbsenceRequestApproval>();
            SmAbsenceRequestDocument = new HashSet<SmAbsenceRequestDocument>();
        }

        public decimal AbsenceRequestId { get; set; }
        public decimal? AbsencePolicyId { get; set; }
        public decimal? RequestBy { get; set; }
        public decimal? EmpAbsencePolicyId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? ReasonLeaveId { get; set; }
        public string AbsenceCode { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public DateTime? RequestDate { get; set; }
        public double? RequestedDays { get; set; }
        public double? RequestedHours { get; set; }
        public double? TotalRequestedHours { get; set; }
        public bool? CreditFlag { get; set; }
        public bool? HrrequestFlag { get; set; }
        public decimal? HrrequestBy { get; set; }
        public string Remark { get; set; }
        public decimal? PreviousAbsenceRequestId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? AbsenceRequestStatusId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MAbsencePolicy AbsencePolicy { get; set; }
        public virtual MEmpAbsencePolicy EmpAbsencePolicy { get; set; }
        public virtual ICollection<MClosedAbsenceRequest> MClosedAbsenceRequest { get; set; }
        public virtual ICollection<SmAbsenceRequestApproval> SmAbsenceRequestApproval { get; set; }
        public virtual ICollection<SmAbsenceRequestDocument> SmAbsenceRequestDocument { get; set; }
    }
}
