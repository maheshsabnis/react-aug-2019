﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAbsenceRequestAttachedDocuments
    {
        public decimal AbsenceRequestDocId { get; set; }
        public decimal? SiteEmployeeLeaveId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmSiteEmployeeLeave SiteEmployeeLeave { get; set; }
    }
}
