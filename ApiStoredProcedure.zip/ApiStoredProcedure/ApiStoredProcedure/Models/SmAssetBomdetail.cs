﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetBomdetail
    {
        public decimal AssetBomdetailId { get; set; }
        public decimal? AssetBomid { get; set; }
        public decimal? AssetId { get; set; }
        public decimal? AssetModelId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
