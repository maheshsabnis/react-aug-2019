﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MSiDefects
    {
        public MSiDefects()
        {
            SmSiBulkTabletsCapsulesDefectDetail = new HashSet<SmSiBulkTabletsCapsulesDefectDetail>();
            SmSiFoldingCartonsDefectDetail = new HashSet<SmSiFoldingCartonsDefectDetail>();
            SmSiLabelsDefectDetail = new HashSet<SmSiLabelsDefectDetail>();
            SmSiPackagedProductDefectDetail = new HashSet<SmSiPackagedProductDefectDetail>();
            SmSiPackagingVerification = new HashSet<SmSiPackagingVerification>();
        }

        public decimal DefectId { get; set; }
        public decimal? InspectionForId { get; set; }
        public string DefectLevel { get; set; }
        public string DefectName { get; set; }
        public string Aql { get; set; }
        public string AccRej { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MSiInspectionFor InspectionFor { get; set; }
        public virtual ICollection<SmSiBulkTabletsCapsulesDefectDetail> SmSiBulkTabletsCapsulesDefectDetail { get; set; }
        public virtual ICollection<SmSiFoldingCartonsDefectDetail> SmSiFoldingCartonsDefectDetail { get; set; }
        public virtual ICollection<SmSiLabelsDefectDetail> SmSiLabelsDefectDetail { get; set; }
        public virtual ICollection<SmSiPackagedProductDefectDetail> SmSiPackagedProductDefectDetail { get; set; }
        public virtual ICollection<SmSiPackagingVerification> SmSiPackagingVerification { get; set; }
    }
}
