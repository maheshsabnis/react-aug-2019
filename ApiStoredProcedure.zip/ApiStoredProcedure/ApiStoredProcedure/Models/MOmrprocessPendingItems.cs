﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessPendingItems
    {
        public MOmrprocessPendingItems()
        {
            MOmrprocessPendingItemsForSubProcess = new HashSet<MOmrprocessPendingItemsForSubProcess>();
        }

        public decimal OmrprocessPendingItemsId { get; set; }
        public string Field { get; set; }
        public string DisplayRule { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? SubmenuId { get; set; }

        public virtual ICollection<MOmrprocessPendingItemsForSubProcess> MOmrprocessPendingItemsForSubProcess { get; set; }
    }
}
