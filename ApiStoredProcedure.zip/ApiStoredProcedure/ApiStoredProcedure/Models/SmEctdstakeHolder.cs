﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdstakeHolder
    {
        public SmEctdstakeHolder()
        {
            SmEctddocument = new HashSet<SmEctddocument>();
            SmEctdfileApproval = new HashSet<SmEctdfileApproval>();
            SmEctdfiles = new HashSet<SmEctdfiles>();
            SmEctdstakeHolderHistory = new HashSet<SmEctdstakeHolderHistory>();
        }

        public decimal EctdstakeHolderId { get; set; }
        public decimal? EctdprojectDetailId { get; set; }
        public decimal? EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Responsibility { get; set; }
        public DateTime? ApprCompletionDate { get; set; }
        public decimal? EctdstakeHolderRoleId { get; set; }
        public bool? IsVisible { get; set; }
        public bool? SubmitFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmEctdprojectDetail EctdprojectDetail { get; set; }
        public virtual ICollection<SmEctddocument> SmEctddocument { get; set; }
        public virtual ICollection<SmEctdfileApproval> SmEctdfileApproval { get; set; }
        public virtual ICollection<SmEctdfiles> SmEctdfiles { get; set; }
        public virtual ICollection<SmEctdstakeHolderHistory> SmEctdstakeHolderHistory { get; set; }
    }
}
