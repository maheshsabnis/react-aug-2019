﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MParty
    {
        public MParty()
        {
            MPartyLocation = new HashSet<MPartyLocation>();
            SmPartyApproval = new HashSet<SmPartyApproval>();
            SmPartyCategoryDetail = new HashSet<SmPartyCategoryDetail>();
            SmPartyDocument = new HashSet<SmPartyDocument>();
            SmPartyLicense = new HashSet<SmPartyLicense>();
            SmPartyTax = new HashSet<SmPartyTax>();
        }

        public decimal PartyId { get; set; }
        public string PartyName { get; set; }
        public string PartyCode { get; set; }
        public string PartyAccountNo { get; set; }
        public string Gpid { get; set; }
        public decimal? SubsidiaryOfId { get; set; }
        public double? CreditLimitUsd { get; set; }
        public decimal? CreditLimitDays { get; set; }
        public string Terms { get; set; }
        public string WebSite { get; set; }
        public string Email { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Type { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MPartyLocation> MPartyLocation { get; set; }
        public virtual ICollection<SmPartyApproval> SmPartyApproval { get; set; }
        public virtual ICollection<SmPartyCategoryDetail> SmPartyCategoryDetail { get; set; }
        public virtual ICollection<SmPartyDocument> SmPartyDocument { get; set; }
        public virtual ICollection<SmPartyLicense> SmPartyLicense { get; set; }
        public virtual ICollection<SmPartyTax> SmPartyTax { get; set; }
    }
}
