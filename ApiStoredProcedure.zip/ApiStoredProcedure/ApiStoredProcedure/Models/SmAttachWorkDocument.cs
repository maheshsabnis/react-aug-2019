﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAttachWorkDocument
    {
        public decimal AttachWorkDocumentId { get; set; }
        public decimal? WorkDocumentationId { get; set; }
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public decimal? DocTypeId { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmWorkDocumentation WorkDocumentation { get; set; }
    }
}
