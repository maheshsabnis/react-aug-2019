﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MParameter
    {
        public MParameter()
        {
            MAssetModelFixParam = new HashSet<MAssetModelFixParam>();
            SmParameterApproval = new HashSet<SmParameterApproval>();
            SmSolutionPreparationAssetParameter = new HashSet<SmSolutionPreparationAssetParameter>();
            SmStmtestTemplateAssetParameter = new HashSet<SmStmtestTemplateAssetParameter>();
            SmStmtestTemplateSolutionAsset = new HashSet<SmStmtestTemplateSolutionAsset>();
            SmTestExecutionAssetParameter = new HashSet<SmTestExecutionAssetParameter>();
        }

        public decimal ParameterId { get; set; }
        public string Parameter { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MAssetModelFixParam> MAssetModelFixParam { get; set; }
        public virtual ICollection<SmParameterApproval> SmParameterApproval { get; set; }
        public virtual ICollection<SmSolutionPreparationAssetParameter> SmSolutionPreparationAssetParameter { get; set; }
        public virtual ICollection<SmStmtestTemplateAssetParameter> SmStmtestTemplateAssetParameter { get; set; }
        public virtual ICollection<SmStmtestTemplateSolutionAsset> SmStmtestTemplateSolutionAsset { get; set; }
        public virtual ICollection<SmTestExecutionAssetParameter> SmTestExecutionAssetParameter { get; set; }
    }
}
