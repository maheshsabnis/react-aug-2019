﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDocument
    {
        public MDocument()
        {
            MDccrequest = new HashSet<MDccrequest>();
            SmDepartmentTrainingRequisitesCmdocument = new HashSet<SmDepartmentTrainingRequisitesCmdocument>();
            SmDocRevision = new HashSet<SmDocRevision>();
            SmJobTitleRequisitesCmdocument = new HashSet<SmJobTitleRequisitesCmdocument>();
            SmSpecificationNliddetail = new HashSet<SmSpecificationNliddetail>();
            SmStandardTestMethod = new HashSet<SmStandardTestMethod>();
            SmStmtestDetail = new HashSet<SmStmtestDetail>();
            SmTestDocument = new HashSet<SmTestDocument>();
            SmTrnClassDetail = new HashSet<SmTrnClassDetail>();
        }

        public decimal DocumentId { get; set; }
        public string DocNum { get; set; }
        public decimal? ParentDocumentId { get; set; }
        public string DocTitle { get; set; }
        public string DocDescription { get; set; }
        public string Owner { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DocCategoryId { get; set; }
        public string CurrentRev { get; set; }
        public string TrainingReq4AllRevs { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual MDocCategory DocCategory { get; set; }
        public virtual ICollection<MDccrequest> MDccrequest { get; set; }
        public virtual ICollection<SmDepartmentTrainingRequisitesCmdocument> SmDepartmentTrainingRequisitesCmdocument { get; set; }
        public virtual ICollection<SmDocRevision> SmDocRevision { get; set; }
        public virtual ICollection<SmJobTitleRequisitesCmdocument> SmJobTitleRequisitesCmdocument { get; set; }
        public virtual ICollection<SmSpecificationNliddetail> SmSpecificationNliddetail { get; set; }
        public virtual ICollection<SmStandardTestMethod> SmStandardTestMethod { get; set; }
        public virtual ICollection<SmStmtestDetail> SmStmtestDetail { get; set; }
        public virtual ICollection<SmTestDocument> SmTestDocument { get; set; }
        public virtual ICollection<SmTrnClassDetail> SmTrnClassDetail { get; set; }
    }
}
