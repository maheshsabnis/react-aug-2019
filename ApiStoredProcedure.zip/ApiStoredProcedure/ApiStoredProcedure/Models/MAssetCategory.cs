﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAssetCategory
    {
        public decimal AssetCategoryId { get; set; }
        public string AssetCategory { get; set; }
        public decimal? AssetTypeId { get; set; }
        public string CategoryCode { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MAssetType AssetType { get; set; }
    }
}
