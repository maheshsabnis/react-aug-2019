﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrformControl
    {
        public decimal FormControlId { get; set; }
        public decimal? FormId { get; set; }
        public string FormControlName { get; set; }
        public string FormControlTypeId { get; set; }
        public decimal? FormControlPropertyId { get; set; }
        public string PropertyValue { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
