﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeAddress
    {
        public MEmployeeAddress()
        {
            SmEmployeeAddressDocument = new HashSet<SmEmployeeAddressDocument>();
            SmEmployeeAddressHistory = new HashSet<SmEmployeeAddressHistory>();
        }

        public decimal EmployeeAddressId { get; set; }
        public decimal? EmployeeId { get; set; }
        public decimal? AddressTypeId { get; set; }
        public string AddressType { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string City { get; set; }
        public decimal? StateId { get; set; }
        public string Zip { get; set; }
        public decimal? CountryId { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Reason { get; set; }
        public bool? SameAddressFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MCountry Country { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual MState State { get; set; }
        public virtual ICollection<SmEmployeeAddressDocument> SmEmployeeAddressDocument { get; set; }
        public virtual ICollection<SmEmployeeAddressHistory> SmEmployeeAddressHistory { get; set; }
    }
}
