﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEctdsubmission
    {
        public decimal SubmissionId { get; set; }
        public decimal? ApplicationId { get; set; }
        public string SubmissionCode { get; set; }
        public string SubmissionName { get; set; }
        public string SequenceNumber { get; set; }
        public DateTime? SubmissionDate { get; set; }
        public bool? TemplateFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEctdapplication Application { get; set; }
    }
}
