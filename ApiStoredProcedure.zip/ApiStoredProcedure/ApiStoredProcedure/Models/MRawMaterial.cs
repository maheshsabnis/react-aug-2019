﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MRawMaterial
    {
        public MRawMaterial()
        {
            SmBomversionProductionSupplies = new HashSet<SmBomversionProductionSupplies>();
            SmProductBomDetail = new HashSet<SmProductBomDetail>();
            SmRawMaterialParty = new HashSet<SmRawMaterialParty>();
            SmThirteenDcodeReq = new HashSet<SmThirteenDcodeReq>();
        }

        public decimal RawMaterialId { get; set; }
        public string RawMaterialName { get; set; }
        public string RawMaterialGrade { get; set; }
        public decimal? RawMaterialCategoryId { get; set; }
        public string ItemCode { get; set; }
        public string Pkg { get; set; }
        public string OldItemCode { get; set; }
        public string QaOldItemCode { get; set; }
        public string Ndc { get; set; }
        public string Cascode { get; set; }
        public double? MinStorageTemp { get; set; }
        public double? MaxStorageTemp { get; set; }
        public double? MinStorageHumidity { get; set; }
        public double? MaxStorageHumidity { get; set; }
        public double? RolQuantity { get; set; }
        public decimal? RolQuantityUnitId { get; set; }
        public decimal? InUnit { get; set; }
        public decimal? OutUnit { get; set; }
        public double? OutUnitXFactor { get; set; }
        public string RawMaterialUse { get; set; }
        public string Remark { get; set; }
        public decimal? TestCycle { get; set; }
        public string TestCyclePeriod { get; set; }
        public string RetestFlag { get; set; }
        public bool? CapsuleFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public decimal? StateId { get; set; }
        public decimal? Density { get; set; }
        public decimal? DensityUnitId { get; set; }
        public decimal? QuantityDimensionId { get; set; }
        public decimal? SiunitId { get; set; }
        public decimal? InwardQuantityDimensionId { get; set; }
        public decimal? OutwardQuantityDimensionId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MRawMaterialCategory RawMaterialCategory { get; set; }
        public virtual ICollection<SmBomversionProductionSupplies> SmBomversionProductionSupplies { get; set; }
        public virtual ICollection<SmProductBomDetail> SmProductBomDetail { get; set; }
        public virtual ICollection<SmRawMaterialParty> SmRawMaterialParty { get; set; }
        public virtual ICollection<SmThirteenDcodeReq> SmThirteenDcodeReq { get; set; }
    }
}
