﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployee
    {
        public MEmployee()
        {
            MEmpBackgroundCheck = new HashSet<MEmpBackgroundCheck>();
            MEmpCategory = new HashSet<MEmpCategory>();
            MEmpCertification = new HashSet<MEmpCertification>();
            MEmpDependents = new HashSet<MEmpDependents>();
            MEmpDrugTest = new HashSet<MEmpDrugTest>();
            MEmpEducation = new HashSet<MEmpEducation>();
            MEmpEmergencyContact = new HashSet<MEmpEmergencyContact>();
            MEmpHiring = new HashSet<MEmpHiring>();
            MEmpMaritalStatus = new HashSet<MEmpMaritalStatus>();
            MEmpMembership = new HashSet<MEmpMembership>();
            MEmpName = new HashSet<MEmpName>();
            MEmpPassport = new HashSet<MEmpPassport>();
            MEmpPersonalDetail = new HashSet<MEmpPersonalDetail>();
            MEmpPersonalReferenceNumber = new HashSet<MEmpPersonalReferenceNumber>();
            MEmpVisa = new HashSet<MEmpVisa>();
            MEmpWorkExperience = new HashSet<MEmpWorkExperience>();
            MEmployeeAddress = new HashSet<MEmployeeAddress>();
            MEmployeeDesig = new HashSet<MEmployeeDesig>();
            MEmployeeEmail = new HashSet<MEmployeeEmail>();
            MEmployeeLeave = new HashSet<MEmployeeLeave>();
            MEmployeeLeaveDate = new HashSet<MEmployeeLeaveDate>();
            MEmployeePhoneNumber = new HashSet<MEmployeePhoneNumber>();
            MHod = new HashSet<MHod>();
            MHodincharge = new HashSet<MHodincharge>();
            MSiteEmployee = new HashSet<MSiteEmployee>();
            SmAssignReceival = new HashSet<SmAssignReceival>();
            SmContractWork = new HashSet<SmContractWork>();
            SmCreditAbsence = new HashSet<SmCreditAbsence>();
            SmCreditAbsenceDetail = new HashSet<SmCreditAbsenceDetail>();
            SmDocRevApproval = new HashSet<SmDocRevApproval>();
            SmECtdprojectApproverHistory = new HashSet<SmECtdprojectApproverHistory>();
            SmEctdprojectTemplateProjectApprover = new HashSet<SmEctdprojectTemplate>();
            SmEctdprojectTemplateProjectPublisher = new HashSet<SmEctdprojectTemplate>();
            SmEmpDocument = new HashSet<SmEmpDocument>();
            SmEmpTrnReq = new HashSet<SmEmpTrnReq>();
            SmEmployeeApproval = new HashSet<SmEmployeeApproval>();
            SmOverTime = new HashSet<SmOverTime>();
            SmPersonalRefenceNumber = new HashSet<SmPersonalRefenceNumber>();
            SmSelfStudy = new HashSet<SmSelfStudy>();
            SmTestPlanEmployeeDetail = new HashSet<SmTestPlanEmployeeDetail>();
            SmTimeCardHourDetail = new HashSet<SmTimeCardHourDetail>();
            SmTrnClassEmp = new HashSet<SmTrnClassEmp>();
            SmTrnTrxn = new HashSet<SmTrnTrxn>();
        }

        public decimal EmployeeId { get; set; }
        public string EmployeeNo { get; set; }
        public string SocialSecurityNo { get; set; }
        public decimal? TitleId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Sex { get; set; }
        public string MaritalStatus { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string OfficePhone { get; set; }
        public string OfficePhoneExt { get; set; }
        public string MobilePhone { get; set; }
        public string EmailId { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DesignationId { get; set; }
        public decimal? PermittedDomainId { get; set; }
        public decimal? PartyId { get; set; }
        public DateTime? HiredDate { get; set; }
        public DateTime? RehireDate { get; set; }
        public DateTime? DrugTest { get; set; }
        public DateTime? BackgroundCheck { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string TerminationReason { get; set; }
        public decimal? OldEmployeeId { get; set; }
        public string OldEmployeeNo { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public string RequestStatus { get; set; }
        public decimal? SuffixId { get; set; }
        public byte[] Photo { get; set; }
        public string PhotoName { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MDepartment Department { get; set; }
        public virtual MDesignation Designation { get; set; }
        public virtual MPermittedDomain PermittedDomain { get; set; }
        public virtual MTitle Title { get; set; }
        public virtual MUser MUser { get; set; }
        public virtual ICollection<MEmpBackgroundCheck> MEmpBackgroundCheck { get; set; }
        public virtual ICollection<MEmpCategory> MEmpCategory { get; set; }
        public virtual ICollection<MEmpCertification> MEmpCertification { get; set; }
        public virtual ICollection<MEmpDependents> MEmpDependents { get; set; }
        public virtual ICollection<MEmpDrugTest> MEmpDrugTest { get; set; }
        public virtual ICollection<MEmpEducation> MEmpEducation { get; set; }
        public virtual ICollection<MEmpEmergencyContact> MEmpEmergencyContact { get; set; }
        public virtual ICollection<MEmpHiring> MEmpHiring { get; set; }
        public virtual ICollection<MEmpMaritalStatus> MEmpMaritalStatus { get; set; }
        public virtual ICollection<MEmpMembership> MEmpMembership { get; set; }
        public virtual ICollection<MEmpName> MEmpName { get; set; }
        public virtual ICollection<MEmpPassport> MEmpPassport { get; set; }
        public virtual ICollection<MEmpPersonalDetail> MEmpPersonalDetail { get; set; }
        public virtual ICollection<MEmpPersonalReferenceNumber> MEmpPersonalReferenceNumber { get; set; }
        public virtual ICollection<MEmpVisa> MEmpVisa { get; set; }
        public virtual ICollection<MEmpWorkExperience> MEmpWorkExperience { get; set; }
        public virtual ICollection<MEmployeeAddress> MEmployeeAddress { get; set; }
        public virtual ICollection<MEmployeeDesig> MEmployeeDesig { get; set; }
        public virtual ICollection<MEmployeeEmail> MEmployeeEmail { get; set; }
        public virtual ICollection<MEmployeeLeave> MEmployeeLeave { get; set; }
        public virtual ICollection<MEmployeeLeaveDate> MEmployeeLeaveDate { get; set; }
        public virtual ICollection<MEmployeePhoneNumber> MEmployeePhoneNumber { get; set; }
        public virtual ICollection<MHod> MHod { get; set; }
        public virtual ICollection<MHodincharge> MHodincharge { get; set; }
        public virtual ICollection<MSiteEmployee> MSiteEmployee { get; set; }
        public virtual ICollection<SmAssignReceival> SmAssignReceival { get; set; }
        public virtual ICollection<SmContractWork> SmContractWork { get; set; }
        public virtual ICollection<SmCreditAbsence> SmCreditAbsence { get; set; }
        public virtual ICollection<SmCreditAbsenceDetail> SmCreditAbsenceDetail { get; set; }
        public virtual ICollection<SmDocRevApproval> SmDocRevApproval { get; set; }
        public virtual ICollection<SmECtdprojectApproverHistory> SmECtdprojectApproverHistory { get; set; }
        public virtual ICollection<SmEctdprojectTemplate> SmEctdprojectTemplateProjectApprover { get; set; }
        public virtual ICollection<SmEctdprojectTemplate> SmEctdprojectTemplateProjectPublisher { get; set; }
        public virtual ICollection<SmEmpDocument> SmEmpDocument { get; set; }
        public virtual ICollection<SmEmpTrnReq> SmEmpTrnReq { get; set; }
        public virtual ICollection<SmEmployeeApproval> SmEmployeeApproval { get; set; }
        public virtual ICollection<SmOverTime> SmOverTime { get; set; }
        public virtual ICollection<SmPersonalRefenceNumber> SmPersonalRefenceNumber { get; set; }
        public virtual ICollection<SmSelfStudy> SmSelfStudy { get; set; }
        public virtual ICollection<SmTestPlanEmployeeDetail> SmTestPlanEmployeeDetail { get; set; }
        public virtual ICollection<SmTimeCardHourDetail> SmTimeCardHourDetail { get; set; }
        public virtual ICollection<SmTrnClassEmp> SmTrnClassEmp { get; set; }
        public virtual ICollection<SmTrnTrxn> SmTrnTrxn { get; set; }
    }
}
