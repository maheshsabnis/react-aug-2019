﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmClosedAbsenceRequestDocument
    {
        public decimal ClosedAbsenceRequestDocumentId { get; set; }
        public decimal? ClosedAbsenceRequestId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MClosedAbsenceRequest ClosedAbsenceRequest { get; set; }
    }
}
