﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MUnitConversionFactor
    {
        public decimal UnitConversionFactorId { get; set; }
        public decimal? SiunitId { get; set; }
        public decimal? InUnitId { get; set; }
        public decimal? OutUnitId { get; set; }
        public double? ConversionFactor { get; set; }
        public decimal? MultiplyBy { get; set; }
        public decimal? DivideBy { get; set; }
        public decimal? Exponent { get; set; }
        public decimal? AddConstant { get; set; }
        public decimal? DecimalDisplay { get; set; }
        public decimal? DecimalRounding { get; set; }
        public string Deactivationflag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUnit InUnit { get; set; }
        public virtual MUnit OutUnit { get; set; }
    }
}
