﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDissolutionSample
    {
        public decimal SmdissolutionSampleId { get; set; }
        public decimal? SolutionPreparationId { get; set; }
        public decimal DissolutionSampleId { get; set; }
        public int? SmdissolutionSampleNo { get; set; }
        public double? SmdissolutionSample1 { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }

        public virtual SmSolutionPreparation SolutionPreparation { get; set; }
    }
}
