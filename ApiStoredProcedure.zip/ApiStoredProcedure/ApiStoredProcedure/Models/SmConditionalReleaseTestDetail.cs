﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmConditionalReleaseTestDetail
    {
        public decimal ConditionalReleaseTestDetailId { get; set; }
        public decimal? ConditionalReleaseId { get; set; }
        public decimal? TestId { get; set; }
        public string Test { get; set; }
        public decimal? QctestNumberId { get; set; }
        public bool? Conforms { get; set; }
        public decimal? AddedBy { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? SiteId { get; set; }
    }
}
