﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetPoexpectedDetail
    {
        public decimal AssetPoexpectedDetailId { get; set; }
        public decimal? AssetPurchaseOrderDetailId { get; set; }
        public string ExptdLotNo { get; set; }
        public double? ExptdQuantity { get; set; }
        public DateTime? ExptdDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmAssetPurchaseOrderDetail AssetPurchaseOrderDetail { get; set; }
    }
}
