﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBomversion
    {
        public SmBomversion()
        {
            SmBomversionApproval = new HashSet<SmBomversionApproval>();
            SmBomversionAsset = new HashSet<SmBomversionAsset>();
            SmBomversionDocument = new HashSet<SmBomversionDocument>();
            SmBomversionHr = new HashSet<SmBomversionHr>();
            SmBomversionMaterial = new HashSet<SmBomversionMaterial>();
            SmBomversionProduct = new HashSet<SmBomversionProduct>();
            SmBomversionProductionSupplies = new HashSet<SmBomversionProductionSupplies>();
        }

        public decimal BomversionId { get; set; }
        public decimal? Bomid { get; set; }
        public decimal? BomstatusId { get; set; }
        public string VersionNo { get; set; }
        public double? Quantity { get; set; }
        public decimal? QuantityUnitId { get; set; }
        public string Comment { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }
        public decimal? ReferenceBomversionId { get; set; }
        public string IsTransferFlag { get; set; }

        public virtual MBom Bom { get; set; }
        public virtual MBomstatus Bomstatus { get; set; }
        public virtual ICollection<SmBomversionApproval> SmBomversionApproval { get; set; }
        public virtual ICollection<SmBomversionAsset> SmBomversionAsset { get; set; }
        public virtual ICollection<SmBomversionDocument> SmBomversionDocument { get; set; }
        public virtual ICollection<SmBomversionHr> SmBomversionHr { get; set; }
        public virtual ICollection<SmBomversionMaterial> SmBomversionMaterial { get; set; }
        public virtual ICollection<SmBomversionProduct> SmBomversionProduct { get; set; }
        public virtual ICollection<SmBomversionProductionSupplies> SmBomversionProductionSupplies { get; set; }
    }
}
