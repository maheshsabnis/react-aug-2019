﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MMacAddressUser
    {
        public decimal MacAddressUserId { get; set; }
        public decimal? MacAddressId { get; set; }
        public decimal? UserId { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MMacAddress MacAddress { get; set; }
    }
}
