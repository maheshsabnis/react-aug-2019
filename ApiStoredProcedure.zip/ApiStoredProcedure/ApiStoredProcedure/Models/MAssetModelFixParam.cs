﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAssetModelFixParam
    {
        public decimal AssetModelFixParamId { get; set; }
        public decimal? AssetModelId { get; set; }
        public decimal? FixParamId { get; set; }
        public decimal? FixParamUnitId { get; set; }
        public double? FixParamValue { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Remark { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MAssetModel AssetModel { get; set; }
        public virtual MParameter FixParam { get; set; }
        public virtual MUnit FixParamUnit { get; set; }
    }
}
