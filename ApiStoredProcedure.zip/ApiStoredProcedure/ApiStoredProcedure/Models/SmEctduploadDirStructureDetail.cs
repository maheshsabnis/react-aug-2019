﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctduploadDirStructureDetail
    {
        public decimal UploadDirStructureDetailId { get; set; }
        public decimal? UplooadDirStructureId { get; set; }
        public string FileName { get; set; }
        public byte[] Fle { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string FilePath { get; set; }
        public string FileType { get; set; }

        public virtual SmEctduploadDirStructure UplooadDirStructure { get; set; }
    }
}
