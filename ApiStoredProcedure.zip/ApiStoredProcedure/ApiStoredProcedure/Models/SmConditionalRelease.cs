﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmConditionalRelease
    {
        public SmConditionalRelease()
        {
            SmConditionalReleaseDocument = new HashSet<SmConditionalReleaseDocument>();
        }

        public decimal ConditionalReleaseId { get; set; }
        public string Crnumber { get; set; }
        public decimal? RawMaterialReceivedId { get; set; }
        public string OldReceivalNo { get; set; }
        public decimal? SamplingId { get; set; }
        public string Reason { get; set; }
        public decimal? RequestedBy { get; set; }
        public DateTime? RequestedDate { get; set; }
        public string CoameetNlispec { get; set; }
        public bool? VerifySubmitFlag { get; set; }
        public decimal? QaverifiedBy { get; set; }
        public DateTime? QaverifiedDate { get; set; }
        public bool? Crflag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string FormName { get; set; }
        public decimal? QasampleId { get; set; }
        public decimal? RDsampleId { get; set; }
        public decimal? QcsampleId { get; set; }
        public string Specification { get; set; }
        public string Reference { get; set; }
        public bool? QcsubmitFlag { get; set; }
        public decimal? QcsampleBy { get; set; }
        public DateTime? QcsampleDate { get; set; }
        public bool? DispositionFlag { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? SiteId { get; set; }
        public bool? PdfAttached { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }

        public virtual SmRawMaterialReceived RawMaterialReceived { get; set; }
        public virtual ICollection<SmConditionalReleaseDocument> SmConditionalReleaseDocument { get; set; }
    }
}
