﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPermittedDomain
    {
        public MPermittedDomain()
        {
            MEmployee = new HashSet<MEmployee>();
            MSite = new HashSet<MSite>();
        }

        public decimal PermittedDomainId { get; set; }
        public string DomainName { get; set; }
        public string CompanyName { get; set; }
        public bool? GroupCompany { get; set; }
        public string Remark { get; set; }
        public bool? PrimaryDomain { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<MEmployee> MEmployee { get; set; }
        public virtual ICollection<MSite> MSite { get; set; }
    }
}
