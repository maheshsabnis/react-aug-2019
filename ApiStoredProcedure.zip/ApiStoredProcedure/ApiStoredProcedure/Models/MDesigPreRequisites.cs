﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDesigPreRequisites
    {
        public decimal DesigPreRequisitesId { get; set; }
        public decimal? DesignationId { get; set; }
        public string Prerequisites { get; set; }
        public string RolesResponsibility { get; set; }
        public string PosDocLink { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MDesignation Designation { get; set; }
    }
}
