﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDispositionCheckList
    {
        public decimal DispositionCheckListId { get; set; }
        public decimal? DispositionFormId { get; set; }
        public string DispositionCheckList { get; set; }
        public decimal? SequenceNo { get; set; }
        public bool? Checkbox { get; set; }
        public string ReviewType { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
