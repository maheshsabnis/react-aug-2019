﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MMaterialStatus
    {
        public MMaterialStatus()
        {
            MArea = new HashSet<MArea>();
            SmPalletLocationDetails = new HashSet<SmPalletLocationDetails>();
        }

        public decimal MaterialStatusId { get; set; }
        public string MaterialStatus { get; set; }
        public bool? IsIssue { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<MArea> MArea { get; set; }
        public virtual ICollection<SmPalletLocationDetails> SmPalletLocationDetails { get; set; }
    }
}
