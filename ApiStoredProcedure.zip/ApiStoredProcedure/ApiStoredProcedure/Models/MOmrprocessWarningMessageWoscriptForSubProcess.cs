﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessWarningMessageWoscriptForSubProcess
    {
        public decimal WarningMessageWoscriptForSubProcessId { get; set; }
        public decimal? OmrprocessWarningMessageWoscriptId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
