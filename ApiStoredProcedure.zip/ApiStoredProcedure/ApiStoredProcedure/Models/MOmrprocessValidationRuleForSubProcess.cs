﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessValidationRuleForSubProcess
    {
        public decimal ValidationRuleForSubProcessId { get; set; }
        public decimal? ValidationRuleId { get; set; }
        public decimal? OmrSubProcessId { get; set; }
        public decimal? OmrProcessGroupId { get; set; }
    }
}
