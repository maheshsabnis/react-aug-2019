﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAsset
    {
        public MAsset()
        {
            MAssetComponent = new HashSet<MAssetComponent>();
            MAssetModel = new HashSet<MAssetModel>();
            SmAssetApproval = new HashSet<SmAssetApproval>();
            SmAssetDocument = new HashSet<SmAssetDocument>();
            SmAssetReceival = new HashSet<SmAssetReceival>();
            SmBomversionAsset = new HashSet<SmBomversionAsset>();
            SmBomversionAssetPart = new HashSet<SmBomversionAssetPart>();
            SmStmtestTemplateAsset = new HashSet<SmStmtestTemplateAsset>();
            SmStmtestTemplateSolutionAsset = new HashSet<SmStmtestTemplateSolutionAsset>();
            SmTestEquipment = new HashSet<SmTestEquipment>();
            SmVProjectStructureAsset = new HashSet<SmVProjectStructureAsset>();
            SmWorkDocumentEquipment = new HashSet<SmWorkDocumentEquipment>();
        }

        public decimal AssetId { get; set; }
        public decimal? AssetCategoryId { get; set; }
        public decimal? ComponentOfAssetId { get; set; }
        public string AssetName { get; set; }
        public string AssetDesc { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MAssetComponent> MAssetComponent { get; set; }
        public virtual ICollection<MAssetModel> MAssetModel { get; set; }
        public virtual ICollection<SmAssetApproval> SmAssetApproval { get; set; }
        public virtual ICollection<SmAssetDocument> SmAssetDocument { get; set; }
        public virtual ICollection<SmAssetReceival> SmAssetReceival { get; set; }
        public virtual ICollection<SmBomversionAsset> SmBomversionAsset { get; set; }
        public virtual ICollection<SmBomversionAssetPart> SmBomversionAssetPart { get; set; }
        public virtual ICollection<SmStmtestTemplateAsset> SmStmtestTemplateAsset { get; set; }
        public virtual ICollection<SmStmtestTemplateSolutionAsset> SmStmtestTemplateSolutionAsset { get; set; }
        public virtual ICollection<SmTestEquipment> SmTestEquipment { get; set; }
        public virtual ICollection<SmVProjectStructureAsset> SmVProjectStructureAsset { get; set; }
        public virtual ICollection<SmWorkDocumentEquipment> SmWorkDocumentEquipment { get; set; }
    }
}
