﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampPsbomdetail
    {
        public decimal CampPsbomdetailId { get; set; }
        public decimal? CampPsbomid { get; set; }
        public decimal? ProductionSuppliesBomdetailId { get; set; }
        public double? CampQuantity { get; set; }

        public virtual SmCampPsbom CampPsbom { get; set; }
        public virtual SmProductionSuppliesBomdetail ProductionSuppliesBomdetail { get; set; }
    }
}
