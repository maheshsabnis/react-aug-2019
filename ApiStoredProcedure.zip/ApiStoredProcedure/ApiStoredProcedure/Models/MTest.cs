﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTest
    {
        public MTest()
        {
            InverseParentTest = new HashSet<MTest>();
            SmQctestNumber = new HashSet<SmQctestNumber>();
            SmStmtestDetail = new HashSet<SmStmtestDetail>();
            SmTestApproval = new HashSet<SmTestApproval>();
            SmTestCategory = new HashSet<SmTestCategory>();
            SmTestDocumentW = new HashSet<SmTestDocumentW>();
        }

        public decimal TestId { get; set; }
        public string Test { get; set; }
        public string TestAbbreviation { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public decimal? SiteId { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? ParentTestId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual MTest ParentTest { get; set; }
        public virtual ICollection<MTest> InverseParentTest { get; set; }
        public virtual ICollection<SmQctestNumber> SmQctestNumber { get; set; }
        public virtual ICollection<SmStmtestDetail> SmStmtestDetail { get; set; }
        public virtual ICollection<SmTestApproval> SmTestApproval { get; set; }
        public virtual ICollection<SmTestCategory> SmTestCategory { get; set; }
        public virtual ICollection<SmTestDocumentW> SmTestDocumentW { get; set; }
    }
}
