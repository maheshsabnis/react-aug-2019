﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEmpPersonalReferenceNumberDocument
    {
        public decimal EmpPersonalReferenceNumberDocumentId { get; set; }
        public decimal? EmpPersonalReferenceNumberId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MDocType DocType { get; set; }
        public virtual MEmpPersonalReferenceNumber EmpPersonalReferenceNumber { get; set; }
    }
}
