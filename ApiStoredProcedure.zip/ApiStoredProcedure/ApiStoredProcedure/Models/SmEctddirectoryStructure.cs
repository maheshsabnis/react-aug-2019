﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctddirectoryStructure
    {
        public decimal EctddirectoryStructureId { get; set; }
        public decimal? TemplateId { get; set; }
        public string Directory { get; set; }
        public decimal? ParentEctddirectoryStructureId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
