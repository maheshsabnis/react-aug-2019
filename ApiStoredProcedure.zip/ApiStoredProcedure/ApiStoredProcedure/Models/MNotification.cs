﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MNotification
    {
        public decimal NotificationId { get; set; }
        public string Code { get; set; }
        public string Notification { get; set; }
        public DateTime? NotificationDate { get; set; }
        public bool? Notified { get; set; }
        public DateTime? NotifiedDate { get; set; }
        public bool? Seen { get; set; }
        public DateTime? SeenDate { get; set; }
        public string DomainUserName { get; set; }
        public decimal? UserId { get; set; }
    }
}
