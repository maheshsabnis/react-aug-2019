﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDocumentDashboardSearchList
    {
        public decimal DocumentDashboardSerachListId { get; set; }
        public decimal? DocumentDashboardLinksId { get; set; }
        public decimal? Order { get; set; }
        public string Keywords { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmDocumentDashboardLinks DocumentDashboardLinks { get; set; }
    }
}
