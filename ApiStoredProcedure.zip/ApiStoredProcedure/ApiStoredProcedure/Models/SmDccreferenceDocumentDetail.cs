﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDccreferenceDocumentDetail
    {
        public decimal DccrefDocDetailId { get; set; }
        public decimal? DccrefDocId { get; set; }
        public decimal? RefDocRevId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MDccreferenceDocument DccrefDoc { get; set; }
        public virtual SmDocRevision RefDocRev { get; set; }
    }
}
