﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MClosedAbsenceRequest
    {
        public MClosedAbsenceRequest()
        {
            SmClosedAbsenceRequestApproval = new HashSet<SmClosedAbsenceRequestApproval>();
            SmClosedAbsenceRequestDocument = new HashSet<SmClosedAbsenceRequestDocument>();
        }

        public decimal ClosedAbsenceRequestId { get; set; }
        public decimal? AbsenceRequestId { get; set; }
        public bool? Availed { get; set; }
        public bool? Canceled { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? AbsenceRequestStatusId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MAbsenceRequest AbsenceRequest { get; set; }
        public virtual ICollection<SmClosedAbsenceRequestApproval> SmClosedAbsenceRequestApproval { get; set; }
        public virtual ICollection<SmClosedAbsenceRequestDocument> SmClosedAbsenceRequestDocument { get; set; }
    }
}
