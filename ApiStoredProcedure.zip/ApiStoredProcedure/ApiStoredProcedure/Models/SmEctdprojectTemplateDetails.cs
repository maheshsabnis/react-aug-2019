﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmEctdprojectTemplateDetails
    {
        public SmEctdprojectTemplateDetails()
        {
            SmEctddocument = new HashSet<SmEctddocument>();
        }

        public decimal EctdprojectTemplateDetailId { get; set; }
        public decimal? FolderId { get; set; }
        public string FolderName { get; set; }
        public string ECtdsection { get; set; }
        public decimal? TemplateId { get; set; }
        public decimal? ProjectId { get; set; }
        public decimal? ParentFolderId { get; set; }
        public string FolderTagName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? EctddirectoryStructureId { get; set; }
        public string PublishedFileName { get; set; }
        public string PublishedFilePath { get; set; }

        public virtual ICollection<SmEctddocument> SmEctddocument { get; set; }
    }
}
