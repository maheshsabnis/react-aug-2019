﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MGpintegrationUser
    {
        public decimal GpintegrationUserId { get; set; }
        public decimal? UserId { get; set; }
        public string Deactivationflag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
