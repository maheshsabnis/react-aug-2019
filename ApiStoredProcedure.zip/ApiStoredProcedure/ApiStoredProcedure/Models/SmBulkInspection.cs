﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmBulkInspection
    {
        public decimal BulkInspectionId { get; set; }
        public decimal? BulkId { get; set; }
        public string Inspection { get; set; }
        public string MaterialIdentification { get; set; }
        public string MaterialSource { get; set; }
        public string LabelInformation { get; set; }
        public string ContainerSpace { get; set; }
        public decimal? LotId { get; set; }
        public bool? ApprovedSupplier { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmBulk Bulk { get; set; }
    }
}
