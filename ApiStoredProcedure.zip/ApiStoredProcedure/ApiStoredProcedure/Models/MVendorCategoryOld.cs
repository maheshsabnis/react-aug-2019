﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MVendorCategoryOld
    {
        public MVendorCategoryOld()
        {
            SmVendorCategoryDetailOld = new HashSet<SmVendorCategoryDetailOld>();
        }

        public decimal VendorCategoryId { get; set; }
        public string Category { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual ICollection<SmVendorCategoryDetailOld> SmVendorCategoryDetailOld { get; set; }
    }
}
