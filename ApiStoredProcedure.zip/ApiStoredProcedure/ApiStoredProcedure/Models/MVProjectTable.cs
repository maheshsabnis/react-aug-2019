﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MVProjectTable
    {
        public decimal VProjectTableId { get; set; }
        public decimal? SequenceNo { get; set; }
        public string TableName { get; set; }
        public bool? IscopyData { get; set; }
        public string PrimaryKeyColumn { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
