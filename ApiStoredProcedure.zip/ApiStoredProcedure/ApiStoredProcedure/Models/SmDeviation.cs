﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDeviation
    {
        public SmDeviation()
        {
            SmDeviationDetail = new HashSet<SmDeviationDetail>();
            SmDeviationDocument = new HashSet<SmDeviationDocument>();
            SmDeviationResponsibleDept = new HashSet<SmDeviationResponsibleDept>();
            SmInvestigation = new HashSet<SmInvestigation>();
        }

        public decimal DeviationId { get; set; }
        public decimal? EventId { get; set; }
        public string DeviationNo { get; set; }
        public DateTime? DateofDiscovery { get; set; }
        public DateTime? DateofEvent { get; set; }
        public string EventDescription { get; set; }
        public string ImmActTaken { get; set; }
        public string Comments { get; set; }
        public decimal? DeviationCategoryId { get; set; }
        public decimal? MethodofDiscoveryId { get; set; }
        public string DeviationCategoryOther { get; set; }
        public string MethodofDother { get; set; }
        public string DeviationApprovedSign { get; set; }
        public bool? DeviationApproveIncorrectPassword { get; set; }
        public DateTime? DueDate { get; set; }
        public string CommentForDirectDeviation { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? ReportedBy { get; set; }
        public decimal? ReportedByDeptId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual SmEvent Event { get; set; }
        public virtual ICollection<SmDeviationDetail> SmDeviationDetail { get; set; }
        public virtual ICollection<SmDeviationDocument> SmDeviationDocument { get; set; }
        public virtual ICollection<SmDeviationResponsibleDept> SmDeviationResponsibleDept { get; set; }
        public virtual ICollection<SmInvestigation> SmInvestigation { get; set; }
    }
}
