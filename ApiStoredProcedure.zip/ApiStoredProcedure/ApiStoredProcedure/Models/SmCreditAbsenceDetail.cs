﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCreditAbsenceDetail
    {
        public decimal CreditAbsenceDetailId { get; set; }
        public decimal? EmployeeId { get; set; }
        public double? CreditAbsenceDays { get; set; }
        public double? DebitAbsenceDays { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MEmployee Employee { get; set; }
    }
}
