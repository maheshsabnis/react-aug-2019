﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetNoDetail
    {
        public SmAssetNoDetail()
        {
            SmAssetNoDetailApproval = new HashSet<SmAssetNoDetailApproval>();
            SmAssetOwnershipNoDetails = new HashSet<SmAssetOwnershipNoDetails>();
            SmPmcycle = new HashSet<SmPmcycle>();
            SmSolutionPreparationAssetDetail = new HashSet<SmSolutionPreparationAssetDetail>();
            SmStabilityInitiationDetail = new HashSet<SmStabilityInitiationDetail>();
            SmTestExecutionAssetDetail = new HashSet<SmTestExecutionAssetDetail>();
            SmTestPlanAssetDetail = new HashSet<SmTestPlanAssetDetail>();
            SmWeighing = new HashSet<SmWeighing>();
            SmWorkDocumentEquipmentOriginalAssetNoDetail = new HashSet<SmWorkDocumentEquipment>();
            SmWorkDocumentEquipmentReplacedAssetNoDetail = new HashSet<SmWorkDocumentEquipment>();
            SmWorkRequest = new HashSet<SmWorkRequest>();
        }

        public decimal NoDetailId { get; set; }
        public decimal? AssetNoDetailStatusId { get; set; }
        public decimal? AssetReceivalId { get; set; }
        public decimal? AssetReceivalDetailId { get; set; }
        public string AssetNo { get; set; }
        public string SerialNo { get; set; }
        public string AssetCode { get; set; }
        public decimal? DeptId { get; set; }
        public decimal? LocationId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public string Status { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual SmAssetReceival AssetReceival { get; set; }
        public virtual SmAssetReceivalDetails AssetReceivalDetail { get; set; }
        public virtual MDepartment Dept { get; set; }
        public virtual MLocation Location { get; set; }
        public virtual ICollection<SmAssetNoDetailApproval> SmAssetNoDetailApproval { get; set; }
        public virtual ICollection<SmAssetOwnershipNoDetails> SmAssetOwnershipNoDetails { get; set; }
        public virtual ICollection<SmPmcycle> SmPmcycle { get; set; }
        public virtual ICollection<SmSolutionPreparationAssetDetail> SmSolutionPreparationAssetDetail { get; set; }
        public virtual ICollection<SmStabilityInitiationDetail> SmStabilityInitiationDetail { get; set; }
        public virtual ICollection<SmTestExecutionAssetDetail> SmTestExecutionAssetDetail { get; set; }
        public virtual ICollection<SmTestPlanAssetDetail> SmTestPlanAssetDetail { get; set; }
        public virtual ICollection<SmWeighing> SmWeighing { get; set; }
        public virtual ICollection<SmWorkDocumentEquipment> SmWorkDocumentEquipmentOriginalAssetNoDetail { get; set; }
        public virtual ICollection<SmWorkDocumentEquipment> SmWorkDocumentEquipmentReplacedAssetNoDetail { get; set; }
        public virtual ICollection<SmWorkRequest> SmWorkRequest { get; set; }
    }
}
