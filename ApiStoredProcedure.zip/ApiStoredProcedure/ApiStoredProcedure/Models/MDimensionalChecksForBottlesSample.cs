﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MDimensionalChecksForBottlesSample
    {
        public decimal Smpid { get; set; }
        public decimal? DimensionalId { get; set; }
        public decimal? BottlesId { get; set; }
        public string SampleNumber { get; set; }
        public string OverallHeight { get; set; }
        public string Width { get; set; }
        public string CapFit { get; set; }
        public string Weight { get; set; }
    }
}
