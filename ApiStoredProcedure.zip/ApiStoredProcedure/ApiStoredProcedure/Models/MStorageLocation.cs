﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MStorageLocation
    {
        public MStorageLocation()
        {
            SmPalletLocationDetails = new HashSet<SmPalletLocationDetails>();
        }

        public decimal StorageLocationId { get; set; }
        public decimal? RowId { get; set; }
        public decimal? MaterialStatusId { get; set; }
        public string LocationId { get; set; }
        public string LocationStatus { get; set; }
        public bool? CustomLocation { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MRow Row { get; set; }
        public virtual ICollection<SmPalletLocationDetails> SmPalletLocationDetails { get; set; }
    }
}
