﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeLeave
    {
        public MEmployeeLeave()
        {
            MEmployeeLeaveHistory = new HashSet<MEmployeeLeaveHistory>();
        }

        public decimal EmployeeLeaveId { get; set; }
        public decimal? ReasonLeaveId { get; set; }
        public decimal? EmployeeId { get; set; }
        public double? DaysAllowed { get; set; }
        public string EffectiveYear { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public DateTime? LapseDate { get; set; }
        public string Reason { get; set; }
        public string Remark { get; set; }
        public bool? SubmitFlag { get; set; }
        public bool? ReviewFlag { get; set; }
        public decimal? ReviewBy { get; set; }
        public string ReviewedBySign { get; set; }
        public DateTime? ReviewDate { get; set; }
        public bool? ApproveFlag { get; set; }
        public decimal? ApprovedBy { get; set; }
        public string ApprovedBySign { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string ApprovalRemark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual MReasonLeave ReasonLeave { get; set; }
        public virtual ICollection<MEmployeeLeaveHistory> MEmployeeLeaveHistory { get; set; }
    }
}
