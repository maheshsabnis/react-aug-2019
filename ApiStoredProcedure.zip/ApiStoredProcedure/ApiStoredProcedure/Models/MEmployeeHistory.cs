﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeHistory
    {
        public decimal EmployeeHistoryId { get; set; }
        public decimal? EmployeeId { get; set; }
        public string EmployeeNo { get; set; }
        public string SocialSecurityNo { get; set; }
        public decimal? TitleId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Sex { get; set; }
        public string MaritalStatus { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string OfficePhone { get; set; }
        public string OfficePhoneExt { get; set; }
        public string MobilePhone { get; set; }
        public string EmailId { get; set; }
        public decimal? DepartmentId { get; set; }
        public decimal? DesignationId { get; set; }
        public decimal? PermittedDomainId { get; set; }
        public DateTime? HiredDate { get; set; }
        public DateTime? RehireDate { get; set; }
        public DateTime? DrugTest { get; set; }
        public DateTime? BackgroundCheck { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string TerminationReason { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
