﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetRequisition
    {
        public SmAssetRequisition()
        {
            SmAssetRequisitionApproval = new HashSet<SmAssetRequisitionApproval>();
            SmAssetRequisitionDetail = new HashSet<SmAssetRequisitionDetail>();
        }

        public decimal AssetRequisitionId { get; set; }
        public string RequisitionNo { get; set; }
        public decimal? RequisitionDeptId { get; set; }
        public decimal? RequisitionBy { get; set; }
        public DateTime? RequisitionDate { get; set; }
        public string Priority { get; set; }
        public decimal? RequestTypeId { get; set; }
        public DateTime? NeedByDate { get; set; }
        public decimal? ShipToSiteId { get; set; }
        public decimal? ShipToSiteContactId { get; set; }
        public decimal? ShipToLocationId { get; set; }
        public decimal? ShipToLocationContactId { get; set; }
        public bool? PorejectedFlag { get; set; }
        public decimal? PorejectedBy { get; set; }
        public string PorejectedByRemark { get; set; }
        public DateTime? PorejectedByDateTime { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public double? Tax { get; set; }
        public double? TotalAmount { get; set; }
        public decimal? Currency { get; set; }
        public decimal? CountofZeroEstPrice { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public string Remark { get; set; }

        public virtual ICollection<SmAssetRequisitionApproval> SmAssetRequisitionApproval { get; set; }
        public virtual ICollection<SmAssetRequisitionDetail> SmAssetRequisitionDetail { get; set; }
    }
}
