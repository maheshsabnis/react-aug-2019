﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmpCertification
    {
        public MEmpCertification()
        {
            SmEmpCertificationDocument = new HashSet<SmEmpCertificationDocument>();
        }

        public decimal EmpCertificationId { get; set; }
        public decimal? EmployeeId { get; set; }
        public string Certification { get; set; }
        public DateTime? CertifiedDate { get; set; }
        public DateTime? ValidUptoDate { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public string Comment { get; set; }
        public string RequestStatus { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MEmployee Employee { get; set; }
        public virtual ICollection<SmEmpCertificationDocument> SmEmpCertificationDocument { get; set; }
    }
}
