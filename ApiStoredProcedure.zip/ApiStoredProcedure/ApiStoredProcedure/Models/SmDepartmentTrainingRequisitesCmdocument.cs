﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDepartmentTrainingRequisitesCmdocument
    {
        public decimal DepartmentTrainingRequisitesCmdocumentId { get; set; }
        public decimal? DepartmentTrainingRequisitesRevId { get; set; }
        public decimal? TrainingCourseRevId { get; set; }
        public decimal? TrainingModuleRevId { get; set; }
        public decimal? TypeId { get; set; }
        public decimal? DocumentId { get; set; }
        public decimal? ExtDocumentId { get; set; }
        public string DeactivationFlag { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? AddeBy { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmDepartmentTrainingRequisitesRevision DepartmentTrainingRequisitesRev { get; set; }
        public virtual MDocument Document { get; set; }
    }
}
