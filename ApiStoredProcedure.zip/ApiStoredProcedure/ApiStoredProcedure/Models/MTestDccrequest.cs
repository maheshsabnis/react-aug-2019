﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTestDccrequest
    {
        public decimal RequestId { get; set; }
        public string RequestNo { get; set; }
    }
}
