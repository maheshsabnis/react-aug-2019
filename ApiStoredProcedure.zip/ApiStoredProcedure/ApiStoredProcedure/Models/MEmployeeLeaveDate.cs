﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeLeaveDate
    {
        public MEmployeeLeaveDate()
        {
            SmSiteEmployeeLeave = new HashSet<SmSiteEmployeeLeave>();
        }

        public decimal EmployeeLeaveId { get; set; }
        public decimal? ReasonLeaveId { get; set; }
        public decimal EmployeeId { get; set; }
        public double? DaysAllowed { get; set; }
        public string EffectiveYear { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Reason { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MEmployee Employee { get; set; }
        public virtual MReasonLeave ReasonLeave { get; set; }
        public virtual ICollection<SmSiteEmployeeLeave> SmSiteEmployeeLeave { get; set; }
    }
}
