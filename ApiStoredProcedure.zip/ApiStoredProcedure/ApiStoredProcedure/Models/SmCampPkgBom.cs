﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmCampPkgBom
    {
        public SmCampPkgBom()
        {
            SmCampPkgBomdetail = new HashSet<SmCampPkgBomdetail>();
        }

        public decimal CampPkgBomid { get; set; }
        public string Bomcode { get; set; }
        public decimal? CampaignId { get; set; }
        public decimal? FormulaId { get; set; }
        public decimal? PackagingBomid { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MPackagingBom PackagingBom { get; set; }
        public virtual ICollection<SmCampPkgBomdetail> SmCampPkgBomdetail { get; set; }
    }
}
