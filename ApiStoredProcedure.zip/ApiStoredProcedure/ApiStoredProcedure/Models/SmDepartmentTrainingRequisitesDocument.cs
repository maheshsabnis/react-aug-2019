﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDepartmentTrainingRequisitesDocument
    {
        public decimal DepartmentTrainingRequisitesDocumentId { get; set; }
        public decimal? DepartmentTrainingRequisitesRevId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public decimal? DocTypeId { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public byte[] RecordVersion { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }

        public virtual SmDepartmentTrainingRequisitesRevision DepartmentTrainingRequisitesRev { get; set; }
    }
}
