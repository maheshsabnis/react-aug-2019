﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MPackageComp
    {
        public MPackageComp()
        {
            SmPackCompParameter = new HashSet<SmPackCompParameter>();
        }

        public decimal PackageCompId { get; set; }
        public decimal? PackageTypeId { get; set; }
        public string PackageComp { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
        public virtual MPackageType PackageType { get; set; }
        public virtual ICollection<SmPackCompParameter> SmPackCompParameter { get; set; }
    }
}
