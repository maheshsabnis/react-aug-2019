﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MTrainingEventExecution
    {
        public MTrainingEventExecution()
        {
            SmTrainingEventDocumentwiseEmployeeDetails = new HashSet<SmTrainingEventDocumentwiseEmployeeDetails>();
            SmTrainingEventExecutionApproval = new HashSet<SmTrainingEventExecutionApproval>();
            SmTrainingEventExecutionDocument = new HashSet<SmTrainingEventExecutionDocument>();
        }

        public decimal TrainingEventExecutionId { get; set; }
        public decimal? TrainingEventId { get; set; }
        public decimal? Instructor { get; set; }
        public decimal? LocationId { get; set; }
        public double? Duration { get; set; }
        public DateTime? DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public DateTime? DateRecertReq { get; set; }
        public string Comment { get; set; }
        public bool? SelfFlag { get; set; }
        public decimal? TrainingEventExecutionIdSelf { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }
        public bool? OldRecord { get; set; }

        public virtual SmTrainingEvent TrainingEvent { get; set; }
        public virtual ICollection<SmTrainingEventDocumentwiseEmployeeDetails> SmTrainingEventDocumentwiseEmployeeDetails { get; set; }
        public virtual ICollection<SmTrainingEventExecutionApproval> SmTrainingEventExecutionApproval { get; set; }
        public virtual ICollection<SmTrainingEventExecutionDocument> SmTrainingEventExecutionDocument { get; set; }
    }
}
