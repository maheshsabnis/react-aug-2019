﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDMaterialDetail
    {
        public decimal DMaterialDetailId { get; set; }
        public decimal? DMaterialId { get; set; }
        public decimal? DispositionCheckListId { get; set; }
        public bool? Yes { get; set; }
        public bool? No { get; set; }
        public bool? Na { get; set; }
        public string Comment { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual SmDMaterial DMaterial { get; set; }
    }
}
