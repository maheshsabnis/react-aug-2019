﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MMenu
    {
        public MMenu()
        {
            MSubMenu = new HashSet<MSubMenu>();
        }

        public decimal MenuId { get; set; }
        public string MenuName { get; set; }
        public decimal? SectionId { get; set; }
        public bool? ShowInAdminPanel { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OrderSrNo { get; set; }

        public virtual ICollection<MSubMenu> MSubMenu { get; set; }
    }
}
