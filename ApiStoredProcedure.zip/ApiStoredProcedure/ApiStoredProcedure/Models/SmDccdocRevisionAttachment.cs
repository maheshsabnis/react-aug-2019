﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDccdocRevisionAttachment
    {
        public decimal DccdocRevisionAttachmentId { get; set; }
        public decimal? DccdocRevId { get; set; }
        public decimal? DocTypeId { get; set; }
        public string DocName { get; set; }
        public byte[] DocFile { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
