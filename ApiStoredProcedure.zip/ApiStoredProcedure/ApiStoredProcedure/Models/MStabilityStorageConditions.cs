﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MStabilityStorageConditions
    {
        public MStabilityStorageConditions()
        {
            SmStabilityInitiationDetail = new HashSet<SmStabilityInitiationDetail>();
            SmStabilityProtocolStorageConditions = new HashSet<SmStabilityProtocolStorageConditions>();
        }

        public decimal StorageConditionId { get; set; }
        public string Temprature { get; set; }
        public string Humidity { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal AddedBy { get; set; }
        public decimal SiteId { get; set; }
        public DateTime DateTime { get; set; }
        public string StorageCondition { get; set; }

        public virtual ICollection<SmStabilityInitiationDetail> SmStabilityInitiationDetail { get; set; }
        public virtual ICollection<SmStabilityProtocolStorageConditions> SmStabilityProtocolStorageConditions { get; set; }
    }
}
