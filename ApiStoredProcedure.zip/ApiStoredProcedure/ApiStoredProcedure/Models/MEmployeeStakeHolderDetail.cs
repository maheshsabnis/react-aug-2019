﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEmployeeStakeHolderDetail
    {
        public decimal EmployeeStakeHolderDetailId { get; set; }
        public string Role { get; set; }
        public string QueryForPendingCnt { get; set; }
        public string DeactivationFlag { get; set; }
    }
}
