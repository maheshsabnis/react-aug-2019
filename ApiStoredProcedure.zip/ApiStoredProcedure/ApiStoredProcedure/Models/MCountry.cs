﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MCountry
    {
        public MCountry()
        {
            MEmpPassport = new HashSet<MEmpPassport>();
            MEmpVisa = new HashSet<MEmpVisa>();
            MEmployeeAddress = new HashSet<MEmployeeAddress>();
            MNationality = new HashSet<MNationality>();
            MPartyLocation = new HashSet<MPartyLocation>();
            MSite = new HashSet<MSite>();
            MState = new HashSet<MState>();
            MVendorLocationOld = new HashSet<MVendorLocationOld>();
            SmComplaint = new HashSet<SmComplaint>();
            SmPartyContactPhone = new HashSet<SmPartyContactPhone>();
            SmPartyLocationPhone = new HashSet<SmPartyLocationPhone>();
        }

        public decimal CountryId { get; set; }
        public string Country { get; set; }
        public string Cabbr { get; set; }
        public bool? DefaultCountry { get; set; }
        public bool? SetPhoneControl { get; set; }
        public string CountryCode { get; set; }

        public virtual ICollection<MEmpPassport> MEmpPassport { get; set; }
        public virtual ICollection<MEmpVisa> MEmpVisa { get; set; }
        public virtual ICollection<MEmployeeAddress> MEmployeeAddress { get; set; }
        public virtual ICollection<MNationality> MNationality { get; set; }
        public virtual ICollection<MPartyLocation> MPartyLocation { get; set; }
        public virtual ICollection<MSite> MSite { get; set; }
        public virtual ICollection<MState> MState { get; set; }
        public virtual ICollection<MVendorLocationOld> MVendorLocationOld { get; set; }
        public virtual ICollection<SmComplaint> SmComplaint { get; set; }
        public virtual ICollection<SmPartyContactPhone> SmPartyContactPhone { get; set; }
        public virtual ICollection<SmPartyLocationPhone> SmPartyLocationPhone { get; set; }
    }
}
