﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmAssetPoclose
    {
        public decimal PocloseId { get; set; }
        public decimal? PurchaseOrderId { get; set; }
        public bool? PocloseFlag { get; set; }
        public decimal? PoclosedBy { get; set; }
        public string PoclosedByRemark { get; set; }
        public DateTime? PoclosedByDateTime { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
    }
}
