﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MOmrprocessLink
    {
        public decimal ProcessLinkId { get; set; }
        public decimal? OmrprocessId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? SubMenuId { get; set; }
        public decimal? LevelNo { get; set; }
        public string DisplaySubProcessName { get; set; }
        public string ModuleName { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? ModuleId { get; set; }
        public string DisplayFormName { get; set; }
        public string DisplayFormMenuLinkName { get; set; }
        public string DisplayFormCaption { get; set; }
        public string ParentForm { get; set; }
        public string Margin { get; set; }
    }
}
