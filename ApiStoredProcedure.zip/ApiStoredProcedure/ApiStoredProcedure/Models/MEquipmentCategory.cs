﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MEquipmentCategory
    {
        public MEquipmentCategory()
        {
            MEquipment = new HashSet<MEquipment>();
            SmEquipmentCategoryApproval = new HashSet<SmEquipmentCategoryApproval>();
        }

        public decimal EquipmentCategoryId { get; set; }
        public string EquipmentCategory { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MEquipment> MEquipment { get; set; }
        public virtual ICollection<SmEquipmentCategoryApproval> SmEquipmentCategoryApproval { get; set; }
    }
}
