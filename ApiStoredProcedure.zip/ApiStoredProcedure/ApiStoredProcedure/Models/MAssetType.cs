﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MAssetType
    {
        public MAssetType()
        {
            MAssetCategory = new HashSet<MAssetCategory>();
            SmAssetTypeApproval = new HashSet<SmAssetTypeApproval>();
        }

        public decimal AssetTypeId { get; set; }
        public string AssetType { get; set; }
        public string Comment { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? RequestBy { get; set; }

        public virtual ICollection<MAssetCategory> MAssetCategory { get; set; }
        public virtual ICollection<SmAssetTypeApproval> SmAssetTypeApproval { get; set; }
    }
}
