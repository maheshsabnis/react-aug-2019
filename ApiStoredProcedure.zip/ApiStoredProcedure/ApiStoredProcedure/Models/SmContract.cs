﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmContract
    {
        public decimal ContractId { get; set; }
        public decimal? ContractNo { get; set; }
        public decimal? RawMaterialPartyId { get; set; }
        public decimal? ProductPartyId { get; set; }
        public double? CreditLimitUsd { get; set; }
        public decimal? CreditLimitDays { get; set; }
        public string Terms { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public double? ContractValueUsd { get; set; }
        public string Remark { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MUser AddedByNavigation { get; set; }
    }
}
