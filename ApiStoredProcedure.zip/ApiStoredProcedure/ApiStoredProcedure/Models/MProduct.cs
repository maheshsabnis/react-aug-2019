﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class MProduct
    {
        public MProduct()
        {
            MBom = new HashSet<MBom>();
            MEctdapplication = new HashSet<MEctdapplication>();
            MFormula = new HashSet<MFormula>();
            MProject = new HashSet<MProject>();
            MSku = new HashSet<MSku>();
            SmBomversionProduct = new HashSet<SmBomversionProduct>();
            SmComplaint = new HashSet<SmComplaint>();
            SmMrtoWareHouse = new HashSet<SmMrtoWareHouse>();
            SmProductApproval = new HashSet<SmProductApproval>();
            SmProductDocument = new HashSet<SmProductDocument>();
            SmProductParty = new HashSet<SmProductParty>();
            SmProductTypeHistory = new HashSet<SmProductTypeHistory>();
            SmProductionProcessVersionDetail = new HashSet<SmProductionProcessVersionDetail>();
            SmSalesInventory = new HashSet<SmSalesInventory>();
            SmSalesOrderDetail = new HashSet<SmSalesOrderDetail>();
            SmTestTemplate = new HashSet<SmTestTemplate>();
            SmThirteenDcodeReq = new HashSet<SmThirteenDcodeReq>();
        }

        public decimal ProductId { get; set; }
        public decimal? ProductFamilyId { get; set; }
        public decimal? RawMaterialCategoryId { get; set; }
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public decimal? ProductTypeId { get; set; }
        public decimal? ParentProductId { get; set; }
        public string StrengthFactor { get; set; }
        public decimal? BrandId { get; set; }
        public decimal? CategoryId { get; set; }
        public string OldProductCode { get; set; }
        public string QaOldProductCode { get; set; }
        public string Ndc { get; set; }
        public string ProductDesc { get; set; }
        public string DosageForm { get; set; }
        public decimal? DosageFormId { get; set; }
        public string ShortName { get; set; }
        public string EmbossingImprint { get; set; }
        public string Remark { get; set; }
        public decimal? PrevCategoryId { get; set; }
        public decimal? QuantityDimensionId { get; set; }
        public decimal? SiunitId { get; set; }
        public decimal? InUnitId { get; set; }
        public decimal? StateId { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }
        public decimal? Density { get; set; }
        public decimal? DensityUnitId { get; set; }
        public decimal? ProductTypeIdOld { get; set; }
        public decimal? PendingAtOmrsubProcessId { get; set; }
        public decimal? OmrsubProcessId { get; set; }
        public decimal? OmrprocessGroupId { get; set; }
        public string RequestStatus { get; set; }
        public string PendingAtUserId { get; set; }
        public string PendingAtUserName { get; set; }
        public string StatusBackColor { get; set; }
        public string StatusForeColor { get; set; }
        public DateTime? DeactivateDate { get; set; }
        public byte[] RecordVersion { get; set; }

        public virtual MBrand Brand { get; set; }
        public virtual ICollection<MBom> MBom { get; set; }
        public virtual ICollection<MEctdapplication> MEctdapplication { get; set; }
        public virtual ICollection<MFormula> MFormula { get; set; }
        public virtual ICollection<MProject> MProject { get; set; }
        public virtual ICollection<MSku> MSku { get; set; }
        public virtual ICollection<SmBomversionProduct> SmBomversionProduct { get; set; }
        public virtual ICollection<SmComplaint> SmComplaint { get; set; }
        public virtual ICollection<SmMrtoWareHouse> SmMrtoWareHouse { get; set; }
        public virtual ICollection<SmProductApproval> SmProductApproval { get; set; }
        public virtual ICollection<SmProductDocument> SmProductDocument { get; set; }
        public virtual ICollection<SmProductParty> SmProductParty { get; set; }
        public virtual ICollection<SmProductTypeHistory> SmProductTypeHistory { get; set; }
        public virtual ICollection<SmProductionProcessVersionDetail> SmProductionProcessVersionDetail { get; set; }
        public virtual ICollection<SmSalesInventory> SmSalesInventory { get; set; }
        public virtual ICollection<SmSalesOrderDetail> SmSalesOrderDetail { get; set; }
        public virtual ICollection<SmTestTemplate> SmTestTemplate { get; set; }
        public virtual ICollection<SmThirteenDcodeReq> SmThirteenDcodeReq { get; set; }
    }
}
