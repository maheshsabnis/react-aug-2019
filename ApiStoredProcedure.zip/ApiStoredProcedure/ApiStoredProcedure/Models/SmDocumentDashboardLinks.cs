﻿using System;
using System.Collections.Generic;

namespace ApiStoredProcedure.Models
{
    public partial class SmDocumentDashboardLinks
    {
        public SmDocumentDashboardLinks()
        {
            SmDocumentDashboardSearchList = new HashSet<SmDocumentDashboardSearchList>();
        }

        public decimal DocumentDashboardLinksId { get; set; }
        public decimal? DocDashboardMasterLinksId { get; set; }
        public decimal? Order { get; set; }
        public string Tag { get; set; }
        public string DisplayName { get; set; }
        public string MainLabelHeader { get; set; }
        public decimal? SubMenuId { get; set; }
        public string ImageName { get; set; }
        public byte[] Image { get; set; }
        public string DeactivationFlag { get; set; }
        public decimal? AddedBy { get; set; }
        public DateTime? DateTime { get; set; }
        public decimal? SiteId { get; set; }

        public virtual MDocDashboardMasterLinks DocDashboardMasterLinks { get; set; }
        public virtual ICollection<SmDocumentDashboardSearchList> SmDocumentDashboardSearchList { get; set; }
    }
}
